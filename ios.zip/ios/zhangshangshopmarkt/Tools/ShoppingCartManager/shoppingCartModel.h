//
//  shoppingCartModel.h
//  shoppingCartinstance
//
//  Created by 吕成翘 on 16/9/11.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface shoppingCartModel : NSObject <NSCoding>

/** 名称 */
@property (copy,nonatomic) NSString *name;
/** 数量 */
@property (assign,nonatomic) NSInteger orderCount;
/** 单价 */
@property (assign,nonatomic) float price;
/** 库存 */
@property (assign,nonatomic) NSInteger stock;

+ (instancetype)shoppingCartModelWithName:(NSString *)name orderCount:(NSInteger )orderCount price:(float)price stock:(NSInteger)stock;

@end
