//
//  shoppingCartModel.m
//  shoppingCartinstance
//
//  Created by 吕成翘 on 16/9/11.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "shoppingCartModel.h"


@implementation shoppingCartModel

+ (instancetype)shoppingCartModelWithName:(NSString *)name orderCount:(NSInteger )orderCount price:(float)price stock:(NSInteger)stock{
    shoppingCartModel *model = [[shoppingCartModel alloc] init];
    model.name = name;
    model.orderCount = orderCount;
    model.price = price;
    model.stock = stock;
    return model;
}

- (NSString *)description{
    return [NSString stringWithFormat:@"%@ --- %zd --- %f",self.name,self.orderCount,self.price];
}

- (void)encodeWithCoder:(NSCoder *)aCoder{
    [aCoder encodeObject:self.name forKey:@"name"];
    [aCoder encodeInteger:self.orderCount forKey:@"orderCount"];
    [aCoder encodeFloat:self.price forKey:@"price"];
    [aCoder encodeInteger:self.stock forKey:@"stock"];
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    if (self = [super init]) {
        self.name = [aDecoder decodeObjectForKey:@"name"];
        self.orderCount = [aDecoder decodeIntegerForKey:@"orderCount"];
        self.price = [aDecoder decodeFloatForKey:@"price"];
        self.stock = [aDecoder decodeIntegerForKey:@"stock"];
    }
    return self;
}

@end
