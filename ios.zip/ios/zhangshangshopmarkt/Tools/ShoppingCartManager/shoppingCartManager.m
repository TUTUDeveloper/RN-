//
//  shoppingCartManager.m
//  shoppingCartinstance
//
//  Created by 吕成翘 on 16/9/11.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "shoppingCartManager.h"


@interface shoppingCartManager ()

/** 名称 */
@property (copy,nonatomic) NSString *name;
/** 数量 */
@property (assign,nonatomic) NSInteger orderCount;
/** 单价 */
@property (copy,nonatomic)NSString *price;

@end


@implementation shoppingCartManager{
    NSMutableArray<shoppingCartModel *> *_shoppingCartList;
    NSString *_filePath;
}

+ (instancetype)sharedShoppingCartManager{
    static id instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

- (instancetype)init{
    if (self = [super init]) {
        NSString *tmpPath = NSTemporaryDirectory();
        _filePath = [tmpPath stringByAppendingPathComponent:@"shoppingCartList.plist"];
        _shoppingCartList = [NSKeyedUnarchiver unarchiveObjectWithFile:_filePath];
        if (!_shoppingCartList) {
            _shoppingCartList = [NSMutableArray array];
        }
    }
    return self;
}

/** 向购物车添加商品 */
- (void)addToShoppingCartWithGoodsName:(NSString *)name price:(float)price stock:(NSInteger)stock{
    if (!_shoppingCartList.count) {
        shoppingCartModel *model = [shoppingCartModel shoppingCartModelWithName:name orderCount:1 price:price stock:stock];
        [_shoppingCartList addObject:model];
    } else {
        BOOL isHas = NO;
        for (shoppingCartModel *model in _shoppingCartList) {
            if ([model.name isEqualToString:name]) {
                model.orderCount ++;
                isHas = YES;
                break;
            } else {
                isHas = NO;
            }
        }
        if (!isHas) {
            shoppingCartModel *model = [shoppingCartModel shoppingCartModelWithName:name orderCount:1 price:price stock:stock];
            [_shoppingCartList addObject:model];
        }
    }
    [NSKeyedArchiver archiveRootObject:_shoppingCartList toFile:_filePath];
    NSLog(@"add --- %@",_shoppingCartList);
}

/** 向购物车减少商品 */
- (void)reduceToShoppingCartWithGoodsName:(NSString *)name{
    if (!_shoppingCartList.count) {
        return;
    } else {
        for (shoppingCartModel *model in _shoppingCartList) {
            if ([model.name isEqualToString:name]) {
                model.orderCount --;
                if (model.orderCount < 1) {
                    [_shoppingCartList removeObject:model];
                }
                break;
            }
        }
    }
    [NSKeyedArchiver archiveRootObject:_shoppingCartList toFile:_filePath];
    NSLog(@"add --- %@",_shoppingCartList);
}

-(void)removeAll
{
    [_shoppingCartList removeAllObjects];
    
    
    [NSKeyedArchiver archiveRootObject:_shoppingCartList toFile:_filePath];
    
    

}
/** 获得购物车内商品总价 */
- (float)getShoppingCartTotalPrice{
    float totalPrice = 0.0;
    for (shoppingCartModel *model in _shoppingCartList) {
        totalPrice += (model.price * model.orderCount);
    }
    return totalPrice;
}

/** 获得购物车内商品总数量 */
- (NSInteger)getShoppingCartTotalCount{
    NSInteger totalCount = 0;
    for (shoppingCartModel *model in _shoppingCartList) {
        totalCount += model.orderCount;
    }
    return totalCount;
}

/** 获得购物车内商品总内容 */
- (NSArray<shoppingCartModel *> *)getShoppingCartTotalList{
    return [_shoppingCartList copy];
}

/** 检查购物车是否为空 */
- (BOOL)isEmpty{
    return _shoppingCartList.count ? NO : YES;
}

/** 通过商品名称获得购物车内商品内容 */
- (shoppingCartModel *)getShoppingCartGoodsWithName:(NSString *)name{
    for (shoppingCartModel *model in _shoppingCartList) {
        if ([model.name isEqualToString:name]) {
            return model;
        }
    }
    return nil;
}

@end
