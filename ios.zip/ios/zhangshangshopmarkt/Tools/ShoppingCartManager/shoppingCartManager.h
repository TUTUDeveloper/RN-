//
//  shoppingCartManager.h
//  shoppingCartinstance
//
//  Created by 吕成翘 on 16/9/11.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "shoppingCartModel.h"


@interface shoppingCartManager : NSObject

/** 获取单例类 */
+ (instancetype)sharedShoppingCartManager;

/** 向购物车添加商品 */
- (void)addToShoppingCartWithGoodsName:(NSString *)name price:(float)price stock:(NSInteger)stock;

/** 向购物车减少商品 */
- (void)reduceToShoppingCartWithGoodsName:(NSString *)name;

/** 获得购物车内商品总价 */
- (float)getShoppingCartTotalPrice;

/** 获得购物车内商品总数量 */
- (NSInteger)getShoppingCartTotalCount;

/** 获得购物车内商品总内容 */
- (NSArray<shoppingCartModel *> *)getShoppingCartTotalList;

/** 检查购物车是否为空 */
- (BOOL)isEmpty;

/** 通过商品名称获得购物车内商品内容 */
- (shoppingCartModel *)getShoppingCartGoodsWithName:(NSString *)name;
-(void)removeAll;
@end
