//
//  NSString+CZPath.m
//
//  Created by 刘凡 on 16/6/10.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import "NSString+CZPath.h"

@implementation NSString (CZPath)

- (NSString *)cz_appendDocumentDir {
    NSString *dir = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).lastObject;
    
    return [dir stringByAppendingPathComponent:self.lastPathComponent];
}

- (NSString *)cz_appendCacheDir {
    NSString *dir = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES).lastObject;
    
    return [dir stringByAppendingPathComponent:self.lastPathComponent];
}

- (NSString *)cz_appendTempDir {
    NSString *dir = NSTemporaryDirectory();
    
    return [dir stringByAppendingPathComponent:self.lastPathComponent];
}

- (NSString *)appendCachePath
{
    // 获取cache文件目录
    NSString *path = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES).lastObject;
    
    // 获取文件名字
    NSString *name = [self lastPathComponent];
    
    // 路径拼接文件名
    NSString *filePath = [path stringByAppendingPathComponent:name];
    
    return filePath;
}

- (NSString *)appendTempPath
{
    // 获取temp文件目录
    NSString *path = NSTemporaryDirectory();
    // 获取文件名字
    NSString *name = [self lastPathComponent];
    // 路径拼接文件名
    NSString *filePath = [path stringByAppendingPathComponent:name];
    
    return filePath;
}

@end
