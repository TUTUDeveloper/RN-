//
//  NSObject+Coder.h
//  通讯录
//
//  Created by HaoYoson on 16/7/10.
//  Copyright © 2016年 HaoYoson. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (Coder)

@end
