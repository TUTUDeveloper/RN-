//
//  LBWebViewController.m
//  LoveBeen
//
//  Created by 陈坤 on 16/9/8.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBWebViewController.h"
#import "SVProgressHUD.h"
@interface LBWebViewController ()<UIWebViewDelegate>

@property (weak, nonatomic) UIWebView *webView;

@end

@implementation LBWebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupUI];

    }
- (void)setupUI{
 
    
    UIWebView *webView = [[UIWebView alloc]init];
    
    webView.frame = self.view.bounds;
    
    [self.view addSubview:webView];
    
    _webView = webView;
    
      }
- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:YES];
    [SVProgressHUD show];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        // 处理耗时的操作
        
        NSURLRequest *request = [[NSURLRequest alloc]initWithURL:[NSURL URLWithString:_URLStr]];
        [_webView loadRequest:request];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [SVProgressHUD dismiss];
        });
    });


    
    
}
/// 网页加载完成之后调用的 : 可以在这个方法里面注入JS
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    // 用于拼接JS代码的字符串
    NSMutableString *stringM = [NSMutableString string];
    
    // 拼接JS代码
    
    // 拼接移除导航的JS代码
    [stringM appendString:@"var headerTag = document.getElementsByTagName('header')[0]; headerTag.parentNode.removeChild(headerTag);"];
    // 拼接移除网页底部布局的JS代码
    [stringM appendString:@"var footerTag = document.getElementsByClassName('footer')[0]; footerTag.parentNode.removeChild(footerTag);"];
    // 拼接移除悬浮按钮的JS代码
    [stringM appendString:@"var footerBtnTag = document.getElementsByClassName('footer-btn-fix')[0]; footerBtnTag.parentNode.removeChild(footerBtnTag);"];
    
    // 专门执行JS代码的(JS注入)
    [webView stringByEvaluatingJavaScriptFromString:stringM];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
