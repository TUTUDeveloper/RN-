//
//  LBHomeController.m
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/7.
//  Copyright © 2016年 Apress. All rights reserved.
//
#import "LBHomeController.h"
#import "HomeHeader.h"
@interface LBHomeController ()<UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, SDCycleScrollViewDelegate>

@property (nonatomic,weak) UICollectionView *collectionV;
@property (nonatomic,weak) RefreshControl *refreshControl;
@end

@implementation LBHomeController
{
    NSArray * _focusImagesList;
    NSArray * _iconsItemsList;
    NSArray * _activitiesList;
    NSArray *_sellList;
    
}

-(void)jumpToVC:(UIButton *)btn {
    switch (btn.tag) {
            
        case 1:
        {
            LBWebViewController *webVC = [[LBWebViewController alloc]init];
            webVC.URLStr = ((LBHomeIconsModel *)_iconsItemsList[btn.tag - 1]).customURL;
            
            
            [self.navigationController pushViewController:webVC animated:YES];
        }
            break;
        case 2:
        {
            LBWebViewController *webVC = [[LBWebViewController alloc]init];
            webVC.URLStr = ((LBHomeIconsModel *)_iconsItemsList[btn.tag - 1]).customURL;
            
            [self.navigationController pushViewController:webVC animated:YES];
        }
            break;
        case 3:
        {
            LBWebViewController *webVC = [[LBWebViewController alloc]init];
            webVC.URLStr = ((LBHomeIconsModel *)_iconsItemsList[btn.tag - 1]).customURL;
            
            [self.navigationController pushViewController:webVC animated:YES];
        }
            break;
        case 4:
        {
            LBWebViewController *webVC = [[LBWebViewController alloc]init];
            webVC.URLStr = ((LBHomeIconsModel *)_iconsItemsList[btn.tag - 1]).customURL;
            
            [self.navigationController pushViewController:webVC animated:YES];
        }
        default:
            break;
    }
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self loadData];
    [self buildtableBar];
    [self setupUI];

    NSLog(@"test");
   }

- (void) loadData {
    
    [self loadHeaderFocusData];
//    [self loadHeaderIconsData];
    [self loadHeaderActivitiesData];
    [self loadSellData];
    //4.加载数据完成以后关闭刷新的动画
    [self.refreshControl endRefreshing];
}
- (void)buildtableBar{
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.navigationController.navigationBar.barTintColor = [UIColor cz_baseColor ];
 
//    导航栏 中间的按钮添加一个自定义的导航按钮到导航栏

    CGRect searchframe = CGRectMake(0, 0, 200, 44);
    UIButton *searchBtn = [[UIButton alloc]initWithFrame:searchframe];
    
    [searchBtn setTitle:@"配送至：" forState:UIControlStateNormal];
    searchBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    [searchBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [searchBtn addTarget:self action:@selector(searchClick) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.titleView.backgroundColor = [UIColor clearColor];
    self.navigationItem.titleView = searchBtn;

    //导航栏左右按钮
 
    UIBarButtonItem *left = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"saoyisaohui"] style:UIBarButtonItemStylePlain target:self action:@selector(saomiao)];
    
    UIBarButtonItem *right = [[UIBarButtonItem alloc]initWithImage: [UIImage imageNamed:@"icon_search"] style:UIBarButtonItemStylePlain target:self action:@selector(shousuo)];
    
    self.navigationItem.leftBarButtonItem = left;
    
    self.navigationItem.rightBarButtonItem = right;
    


}
- (void)searchClick{
    [self.navigationController pushViewController:[[LBSearchAroundView alloc] init ]animated:YES];
    
    
    
}
#pragma mark - 扫一扫  和   搜索
- (void)shousuo{
    CQ_HistoryViewController *historyViewController = [[CQ_HistoryViewController alloc]init];
    [self.navigationController pushViewController:historyViewController animated:YES];}
-(void)saomiao{
    SCanQRCodeViewController *scan = [[SCanQRCodeViewController alloc] init];
    UIBarButtonItem *item = [[UIBarButtonItem alloc]init];
    item.title = @"";
    self.navigationItem.backBarButtonItem = item;
    
    [self.navigationController pushViewController:scan animated:YES];
    
}

#pragma mark - 轮播图片的数据
- (void) loadHeaderFocusData {
    NSMutableDictionary *param = [NSMutableDictionary dictionary];
    [param setValue:@"1" forKey:@"call"];
    [DSHTTPClient postUrlString:@"focus.json.php" withParam:param withSuccessBlock:^(NSDictionary* data) {
        NSArray * focusInfoArr = data[@"data"][@"focus"];
        NSMutableArray * arrM = [NSMutableArray arrayWithCapacity:focusInfoArr.count];
        [focusInfoArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            LBHomeIconsModel * model = [LBHomeIconsModel modelWithDict:obj];
            [arrM addObject:model];
        }];
        _focusImagesList = arrM.copy;
        [[NSOperationQueue mainQueue] addOperationWithBlock:^{
            
            [_collectionV reloadData];
        }];
    } withFailedBlock:^(NSError *error) {
        NSLog(@"%@",error);
    } withErrorBlock:^(NSString *message) {
        NSLog(@"%@",message);
    }];
}
//#pragma mark -  4个按钮的数据
//- (void) loadHeaderIconsData {
//    NSMutableDictionary *param = [NSMutableDictionary dictionary];
//    [param setValue:@"1" forKey:@"call"];
//    [DSHTTPClient postUrlString:@"focus.json.php" withParam:param withSuccessBlock:^(NSDictionary* data) {
//        NSArray * iconsInfoArr = data[@"data"][@"icons"];
//        NSMutableArray * arrM = [NSMutableArray arrayWithCapacity:iconsInfoArr.count];
//        [iconsInfoArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
//            LBHomeIconsModel * model = [LBHomeIconsModel modelWithDict:obj];
//            [arrM addObject:model];
//        }];
//        _iconsItemsList = arrM.copy;
//        [[NSOperationQueue mainQueue] addOperationWithBlock:^{
//            [_collectionV reloadData];
//        }];
//    } withFailedBlock:^(NSError *error) {
//        NSLog(@"%@",error);
//    } withErrorBlock:^(NSString *message) {
//        NSLog(@"%@",message);
//    }];
//}


#pragma mark -   头部广告的数据
- (void) loadHeaderActivitiesData {
    NSMutableDictionary *param = [NSMutableDictionary dictionary];
    [param setValue:@"1" forKey:@"call"];
    [DSHTTPClient postUrlString:@"focus.json.php" withParam:param withSuccessBlock:^(NSDictionary* data) {
        NSArray * activitiesArr = data[@"data"][@"activities"];
        NSMutableArray * arrM = [NSMutableArray arrayWithCapacity:activitiesArr.count];
        [activitiesArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            LBHomeActivitiesModel * model = [LBHomeActivitiesModel modelWithDict:obj];
            [arrM addObject:model];
        }];
        _activitiesList = arrM.copy;
        [_collectionV reloadData];
    } withFailedBlock:^(NSError *error) {
        NSLog(@"%@",error);
    } withErrorBlock:^(NSString *message) {
        NSLog(@"%@",message);
    }];
}
#pragma mark - detail数据
- (void) loadSellData {
    NSMutableDictionary *param = [NSMutableDictionary dictionary];
    [param setValue:@"2" forKey:@"call"];
    [DSHTTPClient postUrlString:@"firstSell.json.php" withParam:param withSuccessBlock:^(id data) {
        NSArray * sellArr = data[@"data"];
        NSMutableArray * arrM = [NSMutableArray arrayWithCapacity:sellArr.count];
        [sellArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            LBHomeSellModel * model = [LBHomeSellModel modelwithdict:obj];
          
//            [arrM addObject:model];
          [  arrM insertObject:model atIndex:0];
          
        }];
        _sellList = arrM.copy;
        [_collectionV reloadData];
    } withFailedBlock:^(NSError *error) {
        NSLog(@"%@",error);
    } withErrorBlock:^(NSString *message) {
        NSLog(@"%@",message);
    }];
}
#pragma mark - collectionV选中的代理方法
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        
        if (indexPath.row ==3) {
            LBWebViewController *webVC = [[LBWebViewController alloc]init];
            webVC.URLStr = ((LBHomeFocusModel *)_focusImagesList[indexPath.row+1]).toURL;
            
            [self.navigationController pushViewController:webVC animated:YES];
        } else {
            LBWebViewController *webVC = [[LBWebViewController alloc]init];
            webVC.URLStr = ((LBHomeFocusModel *)_focusImagesList[indexPath.row]).toURL;
            
            [self.navigationController pushViewController:webVC animated:YES];
        }
        
       
    }else{
        
         // 2.创建详情vc对象
    LBMarketProductDetailsController *detailController =[[LBMarketProductDetailsController alloc] init];
        
        // 点击商品
        // 1.获取选中的商品
        LBMarketProductsModel *selectProduct = _sellList[indexPath.row];
        
        // 2.创建详情vc对象
        
        detailController.productModel = selectProduct;
        
        // 3.跳转
        [self.navigationController pushViewController:detailController animated:YES];
        
    }
}


#pragma mark - 轮播器的代理方法
- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index {
    LBWebViewController *webVC = [[LBWebViewController alloc]init];
    webVC.URLStr = ((LBHomeFocusModel *)_focusImagesList[index]).toURL;
    [self.navigationController pushViewController:webVC animated:YES];
   
}
//返回不同cell的高度
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {  //第0组
        return CGSizeMake(collectionView.bounds.size.width - 10, 140);
    }
    
    return CGSizeMake((collectionView.bounds.size.width * 0.5 - 10) , 280);
}

#pragma mark - 数据源方法
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 2;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    if (section == 0) {
        return _activitiesList.count;
    }else {
        return _sellList.count;
    }
    
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        LBCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
        cell.activityModel = _activitiesList[indexPath.item];
        return cell;
    }
    LBCollectionViewCell2 *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell2" forIndexPath:indexPath];
    cell.sellModel = _sellList[indexPath.item];
    return cell;
}

#pragma mark - collectionVC头部视图
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath {
    UICollectionReusableView *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"cellHeader" forIndexPath:indexPath];
    headerView.backgroundColor = [UIColor whiteColor];
    
    
    NSMutableArray *arrayM = [NSMutableArray array];
    for (NSInteger i = 0; i < _focusImagesList.count; i++) {
        NSString *url = ((LBHomeFocusModel *)_focusImagesList[i]).img;
        [arrayM addObject:url];
    }
    //添加轮播器
    SDCycleScrollView *cycleScrollView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 140) delegate:self placeholderImage:[UIImage imageNamed:@"beentishiSV"]];
    cycleScrollView.imageURLStringsGroup = arrayM.copy;
    [headerView addSubview:cycleScrollView];
    

    
    return headerView;
}


//返回不同组的组头高度
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        return CGSizeMake(self.view.frame.size.width, 140);
    }else {
        return CGSizeMake(0, 0);
    }
}

#pragma mark - 实现增加、减少产品的通知方法
- (void)increaseProductsNotification:(NSNotification *)notifi {
    
    UITabBarItem *tabBarItem = [[[self.tabBarController tabBar] items] objectAtIndex:2];
    [tabBarItem setBadgeValue:[NSString stringWithFormat:@"%zd", [[shoppingCartManager sharedShoppingCartManager] getShoppingCartTotalCount]]];
}

- (void)reduceProductsNotification:(NSNotification *)notifi {
    
    UITabBarItem *tabBarItem = [[[self.tabBarController tabBar] items] objectAtIndex:2];
    [tabBarItem setBadgeValue:[NSString stringWithFormat:@"%zd", [[shoppingCartManager sharedShoppingCartManager] getShoppingCartTotalCount]]];
    if ([[shoppingCartManager sharedShoppingCartManager] getShoppingCartTotalCount] == 0) {
        tabBarItem.badgeValue = nil;
    }
}

#pragma makr -搭建界面
- (void)setupUI {
    
    //监听增加产品通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(increaseProductsNotification:) name:@"increaseProducts" object:nil];
    
    //监听减少产品通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reduceProductsNotification:) name:@"reduceProducts " object:nil];
    
    //发送通知
    UITabBarItem *tabBarItem = [[[self.tabBarController tabBar] items] objectAtIndex:2];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"increaseProducts" object:@([[shoppingCartManager sharedShoppingCartManager] getShoppingCartTotalCount]) userInfo:nil];
    if ([[shoppingCartManager sharedShoppingCartManager] getShoppingCartTotalCount] == 0) {
        tabBarItem.badgeValue = nil;
    }
    
    LBCollectionViewFlowLayout *layout = [[LBCollectionViewFlowLayout alloc]init];
    
    UICollectionView *collectionV = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height - 44 - 22) collectionViewLayout:layout];
    layout.headerReferenceSize = CGSizeMake(0, 220);
    
    [self.view addSubview:collectionV];
    
    collectionV.showsVerticalScrollIndicator = NO;
    
    collectionV.dataSource = self;
    collectionV.delegate = self;
    
    collectionV.backgroundColor = [UIColor colorWithWhite:.9 alpha:1];
    //注册
    [collectionV registerClass:[LBCollectionViewCell class] forCellWithReuseIdentifier:@"cell"];
    [collectionV registerClass:[LBCollectionViewCell2 class] forCellWithReuseIdentifier:@"cell2"];
    //注册头视图
    [collectionV registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"cellHeader"];
    
    self.collectionV = collectionV;
    //添加下拉刷新的视图
    RefreshControl *refreshControl = [[RefreshControl alloc] init];
    [self.collectionV addSubview:refreshControl];
    self.refreshControl = refreshControl;
     //3.給下拉控件添加执行事件
    [refreshControl addTarget:self action:@selector(loadData) forControlEvents:UIControlEventValueChanged];
    // 上拉刷新
    self.collectionV.mj_footer = [MJRefreshAutoNormalFooter  footerWithRefreshingBlock:^{
        [self.collectionV.mj_footer  beginRefreshing];
        //网络请求
        // 结束刷新
        [self.collectionV.mj_footer  endRefreshing];
        
    }];

}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat offSetY = self.collectionV.contentOffset.y;
    if (offSetY > 0) {
        if (offSetY >= 44) {
            [self setNavigationBarTransformProgress:1];
        } else {
            [self setNavigationBarTransformProgress:(offSetY / 44)];
        }
    } else {
        [self setNavigationBarTransformProgress:0];
        self.navigationController.navigationBar.backIndicatorImage = [UIImage new];
    }

}

- (void)setNavigationBarTransformProgress:(CGFloat)progress{
}

@end

