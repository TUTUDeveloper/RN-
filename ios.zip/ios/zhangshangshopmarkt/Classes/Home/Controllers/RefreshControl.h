

#import <UIKit/UIKit.h>

@interface RefreshControl : UIControl

- (void)endRefreshing;


@end
