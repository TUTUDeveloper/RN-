//
//  LBHomeSellModel.h
//  LoveBeen
//
//  Created by 陈坤 on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LBHomeSellModel : NSObject
/// 商品ID
@property (nonatomic,copy) NSString *gid;
/// 商品姓名 *
@property (nonatomic,copy) NSString *name;
@property (nonatomic,copy) NSString *brand_id;
//数量

@property (nonatomic,assign) NSInteger orderCount;
/// 超市价格 *
@property (nonatomic,copy) NSString *market_price;
@property (nonatomic,copy) NSString *cid;
@property (nonatomic,copy) NSString *category_id;

@property (nonatomic,copy) NSString *partner_price;
@property (nonatomic,copy) NSString *brand_name;
@property (nonatomic,copy) NSString *pre_img;
@property (nonatomic,copy) NSString *pre_imgs;
/// 规格*
@property (nonatomic,copy) NSString *specifics;
@property (nonatomic,copy) NSString *product_id;
@property (nonatomic,copy) NSString *dealer_id;
/// 当前价格*
@property (nonatomic,assign) CGFloat price;
/// 库存
@property (nonatomic,assign) NSInteger number;
/// 判断 买一赠一 *(数据内容有或者无)
@property (nonatomic,copy) NSString *pm_desc;
@property (nonatomic,assign) NSInteger had_pm;
//图片地址*
@property (nonatomic,copy) NSString *img;
/// 是不是精选 0 : 不是, 1 : 是 (判断是否有精选label)
@property (nonatomic,assign) NSInteger is_xf;
// 记录用户对商品添加次数
@property (nonatomic,assign) NSInteger userBuyNumber;

@property (assign, nonatomic)NSInteger count;

+ (instancetype) modelwithdict:(NSDictionary *)dict;
@end
