//
//  LBHomeIconsModel.h
//  LoveBeen
//
//  Created by 陈坤 on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <Foundation/Foundation.h>

//头部四个图标
@interface LBHomeIconsModel : NSObject
//图标名字
@property (copy, nonatomic) NSString * name;
//图像
@property (copy, nonatomic) NSString * img;
//图标图片的URLString
@property (nonatomic,copy) NSString *toURL;
//点击跳转的web的URKString
@property (copy, nonatomic) NSString * customURL;

+ (instancetype) modelWithDict:(NSDictionary *) dict;

@end
