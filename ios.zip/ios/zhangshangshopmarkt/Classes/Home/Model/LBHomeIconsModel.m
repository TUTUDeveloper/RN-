//
//  LBHomeIconsModel.m
//  LoveBeen
//
//  Created by 陈坤 on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBHomeIconsModel.h"

@implementation LBHomeIconsModel
+ (instancetype) modelWithDict:(NSDictionary *) dict {
    LBHomeIconsModel * model = [[LBHomeIconsModel alloc] init];
    [model setValuesForKeysWithDictionary:dict];
    return model;
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
}

- (NSString *)description {
    return [NSString stringWithFormat:@"%@--%@--%@", self.name, self.img, self.customURL];
}
@end
