//
//  LBHomeFocusModel.h
//  LoveBeen
//
//  Created by 陈坤 on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <Foundation/Foundation.h>
//轮播器图片
@interface LBHomeFocusModel : NSObject
//图片的URLString
@property (copy, nonatomic) NSString * img;
//点击跳转的web的URKString
@property (copy, nonatomic) NSString * toURL;

+ (instancetype) modelWithDict:(NSDictionary *)dict;

@end
