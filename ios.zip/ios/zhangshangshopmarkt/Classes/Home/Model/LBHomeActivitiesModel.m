//
//  LBHomeActivitiesModel.m
//  LoveBeen
//
//  Created by 陈坤 on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBHomeActivitiesModel.h"

@implementation LBHomeActivitiesModel

+ (instancetype) modelWithDict:(NSDictionary *) dict {
    LBHomeActivitiesModel * model = [[LBHomeActivitiesModel alloc] init];
    [model setValuesForKeysWithDictionary:dict];
    return model;
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
}

- (NSString *)description {
    return [NSString stringWithFormat:@"%@--%@--%@", self.name, self.img, self.customURL];
}

@end
