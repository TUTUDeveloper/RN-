//
//  LBHomeFocusModel.m
//  LoveBeen
//
//  Created by 陈坤 on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBHomeFocusModel.h"

@implementation LBHomeFocusModel
+ (instancetype) modelWithDict:(NSDictionary *)dict {
    LBHomeFocusModel * model = [[LBHomeFocusModel alloc] init];
    [model setValuesForKeysWithDictionary:dict];
    return model;
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
}

- (NSString *)description {
    return [NSString stringWithFormat:@"%@--%@", self.img, self.toURL];
}
@end
