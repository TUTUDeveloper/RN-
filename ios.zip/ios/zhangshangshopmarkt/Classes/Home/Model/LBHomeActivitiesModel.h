//
//  LBHomeActivitiesModel.h
//  LoveBeen
//
//  Created by 陈坤 on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LBHomeActivitiesModel : NSObject
//图标名字
@property (copy, nonatomic) NSString * name;
//图标图片的URLString
@property (copy, nonatomic) NSString * img;
//点击跳转的web的URKString
@property (copy, nonatomic) NSString * customURL;

+ (instancetype) modelWithDict:(NSDictionary *) dict;

@end
