//
//  LBSearchAroundView.m
//  LoveBeen
//
//  Created by 陈坤 on 16/9/12.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBSearchAroundView.h"

@implementation LBSearchAroundView

- (void)viewDidLoad {
    
    [self searchAround];
    
}

- (void)searchAround{
    
    UIImageView *imav = [[UIImageView alloc]initWithFrame:self.view.bounds];
    imav.image = [UIImage imageNamed:@"wnxBG"];
    
    [self.view addSubview:imav];
    
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"fanhuiback"] style:UIBarButtonItemStylePlain target:self action:@selector(popControllerClick:)];
    [leftItem setTintColor:[UIColor lightGrayColor]];
    self.navigationItem.leftBarButtonItem = leftItem;
    
}

- (void)popControllerClick:(UIBarButtonItem *)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

@end
