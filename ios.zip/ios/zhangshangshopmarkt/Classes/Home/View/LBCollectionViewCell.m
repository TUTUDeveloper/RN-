//
//  LBCollectionView.m
//  LoveBeen
//
//  Created by 陈坤 on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBCollectionViewCell.h"
#import "CZAdditions.h"
#import "UIImageView+WebCache.h"
#import "LBHomeActivitiesModel.h"

@implementation LBCollectionViewCell
{
    UIImageView *_imgView;
}
- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.contentView.backgroundColor = [UIColor cz_randomColor];
        [self setupUI];
    }
    return self;
}
- (void)setupUI {
    
    UIImageView *imgView = [[UIImageView alloc]init];
    
    imgView.frame = self.contentView.bounds;
    [self.contentView addSubview:imgView];
    _imgView = imgView;
    
}
- (void)setActivityModel:(LBHomeActivitiesModel *)activityModel {
    _activityModel = activityModel;
    [_imgView sd_setImageWithURL:[NSURL URLWithString:_activityModel.img] placeholderImage:[UIImage imageNamed:@"h1"]];
}

@end
