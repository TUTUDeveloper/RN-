//
//  LBDetailView.h
//  LoveBeen
//
//  Created by 陈坤 on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LBHomeSellModel.h"
@class LBDetailView;
@protocol LBDetailViewDelegate <NSObject>
//代理方法 将数量传给cell
- (void)PushToCell2:(LBDetailView *) detailView;



@end

@interface LBDetailView : UIView
@property (weak, nonatomic) IBOutlet UIImageView *iconImageView;

@property (nonatomic,assign) NSInteger count;
@property (nonatomic,weak) id <LBDetailViewDelegate> delegate;
@property (strong, nonatomic) LBHomeSellModel *sellModel;

//动画的起始点
@property (assign, nonatomic) CGPoint startPoint;

+(instancetype)detailView;
@end
