//
//  LBCollectionViewFlowLayout.h
//  LoveBeen
//
//  Created by 陈坤 on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LBCollectionViewFlowLayout : UICollectionViewFlowLayout

@end
