//
//  LBCollectionViewFlowLayout.m
//  LoveBeen
//
//  Created by 陈坤 on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBCollectionViewFlowLayout.h"
#import "CZAdditions.h"

@implementation LBCollectionViewFlowLayout
- (instancetype)init {
    if (self = [super init]) {
        [self setupUI];
    }
    return self;
}
- (void)setupUI {
    self.scrollDirection = UICollectionViewScrollDirectionVertical;
    self.sectionInset = UIEdgeInsetsMake(5, 5, 5, 5);
}
- (void)prepareLayout {
    [super prepareLayout];
    self.itemSize = CGSizeMake(self.collectionView.bounds.size.width, 140);
    
}
@end
