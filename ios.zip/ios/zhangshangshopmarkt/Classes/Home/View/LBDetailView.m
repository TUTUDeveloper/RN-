//
//  LBDetailView.m
//  LoveBeen
//
//  Created by 陈坤 on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBDetailView.h"
#import "UIImageView+WebCache.h"
#import "shoppingCartManager.h"
@interface  LBDetailView ()

@property (weak, nonatomic) IBOutlet UILabel *nameLabel;

@property (weak, nonatomic) IBOutlet UIImageView *ZengsongImageView;
@property (weak, nonatomic) IBOutlet UIImageView *buyoneImageView;
@property (weak, nonatomic) IBOutlet UILabel *guigeLabel;
@property (weak, nonatomic) IBOutlet UILabel *priceLabel;

@property (weak, nonatomic) IBOutlet UILabel *originalLabel;
@property (weak, nonatomic) IBOutlet UIButton *reduceBtn;
@property (weak, nonatomic) IBOutlet UIButton *addBtn;

@property (weak, nonatomic) IBOutlet UILabel *countLable;
@end

@implementation LBDetailView

+(instancetype)detailView {
    return [[NSBundle mainBundle] loadNibNamed:@"LBDetailView" owner:nil options:nil].lastObject;
}
#pragma mark - 核心动画的代理方法
- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag {
    //1. 取出图片框
    UIImageView *imgV = [anim valueForKey:@"imgV"];
    //2. 移除核心动画
    [imgV.layer removeAllAnimations];
    //3. 移除图片框
    [imgV removeFromSuperview];
}
- (void)setSellModel:(LBHomeSellModel *)sellModel {
    _sellModel = sellModel;
    
    
    
    if([_sellModel.name hasPrefix:@"爱鲜蜂·"])
    {
        _nameLabel.text = [_sellModel.name substringFromIndex:4];
    }else
    {
    _nameLabel.text = _sellModel.name;
    
    }
    
    
    _guigeLabel.text = _sellModel.specifics;
    _originalLabel.text = _sellModel.market_price;
    _priceLabel.text = [NSString stringWithFormat:@"%.2f", _sellModel.price];
    
    //原价设置划线
    NSInteger length = [_originalLabel.text length];
    NSMutableAttributedString *attri = [[NSMutableAttributedString alloc] initWithString:_originalLabel.text];
    [attri addAttribute:NSStrikethroughStyleAttributeName value:@(NSUnderlinePatternSolid | NSUnderlineStyleSingle) range:NSMakeRange(1, length-2)];//gai
    [attri addAttribute:NSStrikethroughColorAttributeName value:[UIColor lightGrayColor]range:NSMakeRange(0, length-2)];
    [_originalLabel setAttributedText:attri];
    
    [_iconImageView sd_setImageWithURL:[NSURL URLWithString:_sellModel.img] placeholderImage:[UIImage imageNamed:@"author"]];
    
    if(![_sellModel.pm_desc isEqualToString:@"买一赠一"]) {
        _buyoneImageView.image = nil;
    }else{
        self.buyoneImageView .image =[UIImage imageNamed:@"buyOne.png"];
    
    }
    
    if (_sellModel.is_xf == 0) {
        _ZengsongImageView.image = nil;
       
    }else{
    
        self.ZengsongImageView.image = [UIImage imageNamed:@"jingxuan.png"];
    }
    
    self.count= _sellModel.count;
}
- (IBAction)reduce:(UIButton *)sender {
    // 减少商品
    [[NSNotificationCenter defaultCenter] postNotificationName:@"reduceProducts" object:@(self.count) userInfo:nil];
    
}
- (IBAction)addAction:(UIButton *)sender {
    self.count++;
    [[shoppingCartManager sharedShoppingCartManager] addToShoppingCartWithGoodsName:_sellModel.name price:_sellModel.price stock:_sellModel.number];
    if ([_delegate respondsToSelector:@selector(PushToCell2:)]) {
        [_delegate PushToCell2:self];
    }
    //发个通知
    [[NSNotificationCenter defaultCenter] postNotificationName:@"marketDecrease" object:nil userInfo:@{@"market_info" : _sellModel , @"isIncrease" : @"1"}];
        
    UIImageView *imgView = [[UIImageView alloc] initWithImage:_iconImageView.image];
    imgView.bounds = _iconImageView.bounds;
    
    UIWindow *keyW = [UIApplication sharedApplication].keyWindow;
    _startPoint = [self convertPoint:_iconImageView.center toView:keyW];
    [keyW addSubview:imgView];
    
    CAKeyframeAnimation *anim = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    [anim setValue:imgView forKey:@"imgV"];
    //设置动画
    [UIView animateWithDuration:1.5 animations:^{
        UIBezierPath *path = [UIBezierPath bezierPath];
        [path moveToPoint:_startPoint];
        
        CGPoint endP = CGPointMake(250, keyW.bounds.size.height - 45);
        [path addQuadCurveToPoint:endP controlPoint:sender.center];
        anim.path = path.CGPath;
        
        imgView.bounds = CGRectZero;
        
    }];
    
    anim.removedOnCompletion = NO;
    anim.fillMode = kCAFillModeForwards;
    // 设置动画时间
    anim.duration = 1;
    anim.delegate = self;
    [imgView.layer addAnimation:anim forKey:nil];
    
    // 增加商品
    [[NSNotificationCenter defaultCenter] postNotificationName:@"increaseProducts" object:@(self.count) userInfo:nil];
    
}

- (void)setCount:(NSInteger)count {
    _count = count;
    if (count > 0) {
        _reduceBtn.hidden = YES;
        _countLable.hidden = YES;
    } else {
        _reduceBtn.hidden = YES;
        _countLable.hidden = YES;
    }
    _countLable.text = @(count).description;
}



@end
