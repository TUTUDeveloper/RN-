//
//  LBCollectionViewCell2.m
//  LoveBeen
//
//  Created by 陈坤 on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBCollectionViewCell2.h"
#import "CZAdditions.h"
#import "LBDetailView.h"
@interface LBCollectionViewCell2 ()
@property (nonatomic,weak) LBDetailView *detaliView;
@end
@implementation LBCollectionViewCell2
- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.contentView.backgroundColor = [UIColor cz_randomColor];
        [self setupUI];
    }
    return self;
}
- (void)setupUI {
    
    LBDetailView *detaliView = [LBDetailView detailView];
    [self.contentView addSubview:detaliView];
    _detaliView = detaliView;
    CGFloat cellH = self.bounds.size.height;
    CGFloat cellW = self.bounds.size.width;
    
    detaliView.frame = CGRectMake(0, 0, cellW, cellH);
}
- (void)setSellModel:(LBHomeSellModel *)sellModel {
    _sellModel = sellModel;
    _detaliView.sellModel = _sellModel;
}
@end
