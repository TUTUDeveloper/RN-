//
//  LBMarketOrderViewController.m
//  LoveBeen
//
//  Created by administrator on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBMarketOrderViewController.h"
#import "SVProgressHUD.h"

@interface LBMarketOrderViewController ()

/**
 *  减少的按钮
 */
@property(weak, nonatomic) IBOutlet UIButton *decreaseButton;
/**
 *  显示数量的label
 */
@property(weak, nonatomic) IBOutlet UILabel *numberLabel;
/**
 *  增加的按钮
 */
@property(weak, nonatomic) IBOutlet UIButton *increaseButton;
@end
@implementation LBMarketOrderViewController

#pragma mark - 加载视图
+ (instancetype)MarketOrderViewController {
    
    return [[NSBundle mainBundle] loadNibNamed:@"LBMarketOrderViewController" owner:nil options:nil].lastObject;
    
}

#pragma mark - 初始化设置
- (void)awakeFromNib {
    
    // 初始化
    self.productsModel.orderCount = 0;
}

#pragma mark - 按钮事件
/**
 *  减少数量
 */
- (IBAction)decreaseButtonClick:(UIButton *)sender
{
    // 通过self. 点语法,调用count的set方法
    self.productsModel.orderCount--;
    
    if (self.productsModel.orderCount < self.productsModel.number) {
        self.increaseButton.enabled = YES;
    }
    
    // 减少
    _isIncrease = NO;
    
    [self butttonType];
    // 数量减少,发送事件
    [self sendActionsForControlEvents:UIControlEventValueChanged];
    
    // 减少商品
    [[NSNotificationCenter defaultCenter] postNotificationName:@"reduceProducts" object:@(self.productsModel.orderCount) userInfo:nil];
    
}
/**
 *  增加数量
 */
- (IBAction)increaseButtonClick:(UIButton *)sender
{
    // 通过self. 点语法,调用count的set方法
    self.productsModel.orderCount++;
    
    if (self.productsModel.orderCount >= self.productsModel.number) {
        [SVProgressHUD showImage:[UIImage imageNamed:@"beentishiSV"] status:@"亲,%@. 库存不足了,睡一觉在来吧~~~"];
        [self performSelector:@selector(dismiss) withObject:nil afterDelay:2];
        self.increaseButton.enabled = NO;
    }
    
    // 增加
    _isIncrease = YES;
    
    // 起始点 -> 相对于窗口!
    // 转换坐标
    //    NSLog(@"-> 前  %@", NSStringFromCGPoint(sender.center));
    UIWindow *keyW = [UIApplication sharedApplication].keyWindow;
    _startP = [self convertPoint:sender.center toView:keyW];

    [self butttonType];
    // 数量增加,发送事件
    [self sendActionsForControlEvents:UIControlEventValueChanged];
    
    // 增加商品
    [[NSNotificationCenter defaultCenter] postNotificationName:@"increaseProducts" object:@(self.productsModel.orderCount) userInfo:nil];
}

-(void)dismiss
{
    [SVProgressHUD  dismiss];
}

#pragma mark - 重写set方法,实现数量控制
- (void)setProductsModel:(LBMarketProductsModel *)productsModel {
    
    _productsModel = productsModel;
    
    [self butttonType];
}

- (void)butttonType {
    
    // 判断数量,控制控件是否隐藏
    if (self.productsModel.orderCount > 0) {
        // 数量有值,可以进行减少的功能
        _decreaseButton.hidden = NO;
        _numberLabel.hidden = NO;
    } else {
        
        // 数量为0,隐藏控件
        _decreaseButton.hidden = YES;
        _numberLabel.hidden = YES;
    }
    // 将数量信息显示到label上
    _numberLabel.text = @(self.productsModel.orderCount).description;
}


@end
