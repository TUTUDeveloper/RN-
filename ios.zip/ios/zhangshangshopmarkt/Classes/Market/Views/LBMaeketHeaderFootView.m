//
//  LBMaeketHeaderFootView.m
//  LoveBeen
//
//  Created by administrator on 16/9/8.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBMaeketHeaderFootView.h"

@interface LBMaeketHeaderFootView ()

/**
 *  显示组标题的label
 */
@property (weak, nonatomic) UILabel *headerLabel;

@end
@implementation LBMaeketHeaderFootView

#pragma mark - 设置数据
- (void)setHeaderTitle:(NSString *)headerTitle {
    
    _headerTitle = headerTitle;
    
    _headerLabel.text = headerTitle;
}

#pragma mark - 初始化的方法!
- (instancetype)initWithReuseIdentifier:(nullable NSString *)reuseIdentifier {
    
    if (self = [super initWithReuseIdentifier:reuseIdentifier]) {
        [self setupUI];
    }
    return self;
    
}
-(void)setupUI
{
    
    self.contentView.backgroundColor = [UIColor cz_colorWithHex:0xf8f8f8];
    
    // 添加label展示文字
    UILabel *headerLabel = [UILabel cz_labelWithText:@"优选水果" fontSize:12 color:[UIColor cz_colorWithHex:0x404040]];
    
    [self.contentView addSubview:headerLabel];
    
    [headerLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(self.contentView).offset(10);
        make.centerY.equalTo(self.contentView);
        
    }];
    
    // 记录
    _headerLabel = headerLabel;
}
@end
