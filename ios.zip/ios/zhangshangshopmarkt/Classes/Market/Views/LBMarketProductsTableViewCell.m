//
//  LBMarketProductsTableViewCell.m
//  LoveBeen
//
//  Created by Angel-xin on 2016/09/08.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBMarketProductsTableViewCell.h"
#import "UIImageView+WebCache.h"
#import "LBMarketOrderViewController.h"

@interface LBMarketProductsTableViewCell ()
/**
 *  图片
 */
@property (weak, nonatomic) UIImageView *imgView;
/**
 *  名称
 */
@property (weak, nonatomic) UILabel *nameLabel;
/**
 *  规格
 */
@property (weak, nonatomic) UILabel *specificsLabel;
/**
 *  价格
 */
@property (weak, nonatomic) UILabel *priceLabel;
/**
 *  市场价格
 */
@property (weak, nonatomic) UILabel *marketPriceLabel;
/**
 *  负责显示商品数量的控件
 */
@property (weak, nonatomic) LBMarketOrderViewController *orderViewControler;
/**
 *  补货中
 */
@property (weak, nonatomic) UILabel *replenishmentLabel;
/**
 *  买一赠送
 */
@property (weak, nonatomic) UIImageView *maiyizengsongImage;

@end

@implementation LBMarketProductsTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        [self setupUI];
    }
    return self;
}

#pragma mark - 监听数量改变的事件
- (void)orderControlValueChanged:(LBMarketOrderViewController *)sender
{
    // 1.将接收的数量信息,设置给自己的模型
    _productsModel.orderCount = sender.productsModel.orderCount;
    
    // 2.搞清楚,是增加还是减少
    if (sender.isIncrease) {
        if ([_delegate respondsToSelector:@selector(ProductsTableViewCell:didFinishIncreseFood: andStartPoint:)]) {
            
            [_delegate ProductsTableViewCell:self didFinishIncreseFood:_productsModel andStartPoint:sender.startP];
        }
    } else {
        if ([_delegate respondsToSelector:@selector(ProductsTableViewCell:didFinishDecreseFood:)]) {
            [_delegate ProductsTableViewCell:self didFinishDecreseFood:_productsModel];
        }
    }
}
#pragma mark - 搭建界面
- (void)setupUI {
    
    // - 间距
    CGFloat maxMargin = 10;
    CGFloat minMargin = 5;
    
    // MARK: - 0.选中 cell 的时候,没有任何颜色变化!也没有取消选中的动画
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    
    // MARK: - 1.图片框
    UIImageView *imgView = [[UIImageView alloc] init];
    
    // 设置圆角
    imgView.layer.cornerRadius = 10;
    imgView.layer.masksToBounds = YES;
    
    // 设置填充颜色
    imgView.contentMode = UIViewContentModeScaleAspectFill;
    [self.contentView addSubview:imgView];
    [imgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(maxMargin);
        make.left.mas_equalTo(8);
        make.size.mas_equalTo(CGSizeMake(70, 70));
    }];
    
    // MARK: - 2.精选图片
    UIImageView *jingxuanImage = [[UIImageView alloc] init];
    jingxuanImage.image = [UIImage imageNamed:@"jingxuan.png"];
    [self.contentView addSubview:jingxuanImage];
    [jingxuanImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(imgView.mas_right).offset(maxMargin);
        make.top.equalTo(imgView);
        make.size.mas_equalTo(CGSizeMake(40, 15));
    }];
    
    // MARK: - 3.名称
    UILabel *nameLabel = [UILabel cz_labelWithText:@"掌上采购超市" fontSize:13 color:[UIColor cz_colorWithHex:0x000000]];
    nameLabel.numberOfLines = 1;
    [self.contentView addSubview:nameLabel];
    [nameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(imgView);
        make.left.equalTo(jingxuanImage.mas_right).offset(maxMargin);
        make.right.mas_equalTo(-8);
    }];
    
    // MARK: - 4.买一赠送
    UIImageView *maiyizengsongImage = [[UIImageView alloc] init];
    maiyizengsongImage.image = [UIImage imageNamed:@"buyOne.png"];
    [self.contentView addSubview:maiyizengsongImage];
    [maiyizengsongImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(jingxuanImage.mas_bottom).offset(minMargin);
        make.left.equalTo(jingxuanImage.mas_left);
        make.size.mas_equalTo(CGSizeMake(40, 15));
    }];
    
    // MARK: - 4.规格
    UILabel *specificsLabel = [UILabel cz_labelWithText:@"400g/盒" fontSize:13 color:[UIColor cz_colorWithHex:0x7e7e7e]];
    specificsLabel.numberOfLines = 1;
    [self.contentView addSubview:specificsLabel];
    [specificsLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(maiyizengsongImage.mas_bottom).offset(minMargin);
        make.left.equalTo(maiyizengsongImage);
    }];
    
    // MARK: - 6.价格
    UILabel *priceLabel = [UILabel cz_labelWithText:@"$999" fontSize:14 color:[UIColor cz_colorWithHex:0xfa2a09]];
    [self.contentView addSubview:priceLabel];
    [priceLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(specificsLabel.mas_bottom).offset(minMargin);
        make.left.equalTo(specificsLabel);
    }];
    
    // MARK: - 7.市场价格
//    market_price
    UILabel *marketPriceLabel = [UILabel cz_labelWithText:@"$999" fontSize:14 color:[UIColor cz_colorWithHex:0x505050]];
    [self.contentView addSubview:marketPriceLabel];
    [marketPriceLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(priceLabel.mas_top);
        make.left.equalTo(priceLabel.mas_right).offset(minMargin);
    }];
    
    // MARK: - 8.市场价格删除线
    UIView *deleteLine = [[UIView alloc] init];
    deleteLine.backgroundColor = [UIColor cz_colorWithHex:0x505050];
    [self.contentView addSubview:deleteLine];
    [deleteLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(marketPriceLabel.mas_top).offset(8);
        make.left.equalTo(marketPriceLabel.mas_left);
        make.right.equalTo(marketPriceLabel.mas_right);
        make.height.mas_equalTo(1);
    }];
    
    // MARK: - 9.控制商品的数量的界面
    LBMarketOrderViewController *orderViewControler = [LBMarketOrderViewController MarketOrderViewController];
    //监听数量控件的值改变事件
    [orderViewControler addTarget:self action:@selector(orderControlValueChanged:) forControlEvents:UIControlEventValueChanged];
    [self.contentView addSubview:orderViewControler];
    [orderViewControler mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(specificsLabel.mas_right);
        make.right.equalTo(self.contentView);
        make.bottom.equalTo(specificsLabel);
        make.size.mas_equalTo(CGSizeMake(96, 27));
    }];
    
    // MARK: - 10.补货中
    UILabel *replenishmentLabel = [UILabel cz_labelWithText:@"补货中" fontSize:13 color:[UIColor cz_colorWithHex:0xfa2a09]];
    [self.contentView addSubview:replenishmentLabel];
    [replenishmentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.contentView);
        make.bottom.equalTo(specificsLabel);
        make.size.mas_equalTo(CGSizeMake(96, 27));
    }];
    
    // MARK: - 9.添加自己的分割线
    UIView *separatorLine = [[UIView alloc] init];
    separatorLine.backgroundColor = [UIColor cz_colorWithHex:0xf3f3f3];
    [self.contentView addSubview:separatorLine];
    [separatorLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.bottom.right.equalTo(self.contentView);
        make.height.mas_equalTo(1);
    }];
    
    _imgView = imgView;
    _nameLabel = nameLabel;
    _specificsLabel = specificsLabel;
    _priceLabel = priceLabel;
    _marketPriceLabel = marketPriceLabel;
    _orderViewControler = orderViewControler;
    _replenishmentLabel =replenishmentLabel;
    _maiyizengsongImage = maiyizengsongImage;
}

#pragma mark -设置数据
- (void)setProductsModel:(LBMarketProductsModel *)productsModel {
    
    _productsModel = productsModel;
    
    // 商品图片
    [_imgView sd_setImageWithURL:[NSURL URLWithString:productsModel.img] placeholderImage:[UIImage imageNamed:@"beentishiSV"]];
    // 商品名称
  
    
    if([productsModel.name hasPrefix:@"爱鲜蜂·"])
    {
        _nameLabel.text = [productsModel.name substringFromIndex:4];
    }else
    {
         _nameLabel.text = productsModel.name;
        
    }
    
    
    // 商品规格
    _specificsLabel.text = productsModel.specifics;
    // 商品价格
    _priceLabel.text = [NSString stringWithFormat:@"￥ %.2f", productsModel.price];
    // 市场价格
    _marketPriceLabel.text = [NSString stringWithFormat:@"￥ %.2f", productsModel.market_price];
    // 买一赠送(当买一赠送数据为空时,不显示)
    if ([productsModel.pm_desc isEqual:@""]) {
        _maiyizengsongImage.hidden = YES;
    }
    // 判断库存(当库存为0时,隐藏添加减少xib,显示补货中label,否则相反)
//    productsModel.store_nums = 0;
    if (productsModel.number == 0) {
        _orderViewControler.hidden = YES;
        _replenishmentLabel.hidden = NO;
    } else {
        _orderViewControler.hidden = NO;
        _replenishmentLabel.hidden = YES;
    }
    
    // 设置数量信息
    _orderViewControler.productsModel = productsModel;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
