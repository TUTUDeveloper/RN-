//
//  LBMarketCategorysTableViewCell.h
//  LoveBeen
//
//  Created by Angel-xin on 2016/09/08.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LBMarketCategorysModel.h"

@interface LBMarketCategorysTableViewCell : UITableViewCell

@property (strong, nonatomic) LBMarketCategorysModel *categorysModel;

@end
