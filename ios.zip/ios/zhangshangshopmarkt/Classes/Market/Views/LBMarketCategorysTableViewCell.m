//
//  LBMarketCategorysTableViewCell.m
//  LoveBeen
//
//  Created by Angel-xin on 2016/09/08.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBMarketCategorysTableViewCell.h"

@implementation LBMarketCategorysTableViewCell

#pragma mark - 设置基本信息
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        [self setupUI];
    }
    return  self;
}

#pragma mark - 搭建界面
- (void)setupUI {
    
    // MARK: - 1.设置默认的背景颜色
    self.contentView.backgroundColor = [UIColor cz_colorWithHex:0xf8f8f8];
    
    self.textLabel.backgroundColor = [UIColor clearColor];
    
    // MARK: - 2.设置标题的颜色,大小,行数
    self.textLabel.textColor = [UIColor cz_colorWithHex:0x464646];
    self.textLabel.font = [UIFont systemFontOfSize:13];
    self.textLabel.numberOfLines = 2;
    
    // MARK: - 3.设置选中的背景
    UIView *selectBg = [[UIView alloc] init];
    selectBg.backgroundColor = [UIColor cz_colorWithHex:0xffffff];
    self.selectedBackgroundView = selectBg;
    
    // MARK: - 4.黄色的竖线
    UIView *lineView = [[UIView alloc] init];
    lineView.backgroundColor = [UIColor cz_colorWithHex:0xffd900];
    
    [selectBg addSubview:lineView];
    
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(4);
        make.left.centerY.equalTo(selectBg);
        make.height.mas_equalTo(30);
    }];
    
    // MARK: - 5.添加自己的分割线
    UIView *separatorLine = [[UIView alloc] init];
    separatorLine.backgroundColor = [UIColor cz_colorWithHex:0xf3f3f3];
    
    [self.contentView addSubview:separatorLine];
    
    [separatorLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.bottom.right.equalTo(self.contentView);
        make.height.mas_equalTo(1);
    }];

}

- (void)setCategorysModel:(LBMarketCategorysModel *)categorysModel {
    
    _categorysModel = categorysModel;
    
    self.textLabel.text = categorysModel.name;
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
