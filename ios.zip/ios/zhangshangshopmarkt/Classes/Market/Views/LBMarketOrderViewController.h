//
//  LBMarketOrderViewController.h
//  LoveBeen
//
//  Created by administrator on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LBMarketProductsModel.h"

@interface LBMarketOrderViewController : UIControl


/**
 *  快速创建视图的方法
 */
+ (instancetype)MarketOrderViewController;
/**
 *  增加还是减少
 */
@property (assign, nonatomic) BOOL isIncrease;

/**
 *  动画的起始点
 */
@property (assign, nonatomic) CGPoint startP;
/**
 *  商品模型数据
 */
@property (strong, nonatomic) LBMarketProductsModel *productsModel;
@end
