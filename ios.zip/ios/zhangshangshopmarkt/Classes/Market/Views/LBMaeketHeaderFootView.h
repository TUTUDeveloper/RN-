//
//  LBMaeketHeaderFootView.h
//  LoveBeen
//
//  Created by administrator on 16/9/8.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LBMaeketHeaderFootView : UITableViewHeaderFooterView


/**
 *  需要显示的组标题的内容
 */
@property (copy, nonatomic) NSString *headerTitle;

@end
