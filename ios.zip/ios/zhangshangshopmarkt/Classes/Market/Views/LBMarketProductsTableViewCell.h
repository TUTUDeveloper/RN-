//
//  LBMarketProductsTableViewCell.h
//  LoveBeen
//
//  Created by administrator on 16/9/8.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LBMarketProductsModel.h"

// 协议
@class LBMarketProductsModel,LBMarketProductsTableViewCell;
@protocol LBMarketProductsTableViewCellDelegate <NSObject>

@optional
/**
 *  cell里面要增加的商品
 *  要有商品,还需要起始点
 */
- (void)ProductsTableViewCell:(LBMarketProductsTableViewCell *)ProductsTableViewCell didFinishIncreseFood:(LBMarketProductsModel *)ProductsModel andStartPoint:(CGPoint)startPoint;;

/**
 *  cell里面减少的商品
 */
- (void)ProductsTableViewCell:(LBMarketProductsTableViewCell *)ProductsTableViewCell didFinishDecreseFood:(LBMarketProductsModel *)ProductsModel;

@end
@interface LBMarketProductsTableViewCell : UITableViewCell
/**
 *  该行cell负责显示的商品模型数据
 */
@property(strong ,nonatomic) LBMarketProductsModel *productsModel;

/**
 *  代理属性
 */
@property (weak, nonatomic) id<LBMarketProductsTableViewCellDelegate> delegate;
@end
