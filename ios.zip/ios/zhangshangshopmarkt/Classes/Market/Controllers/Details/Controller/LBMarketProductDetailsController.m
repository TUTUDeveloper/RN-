//
//  LBMarketProductDetailsController.m
//  LoveBeen
//
//  Created by administrator on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBMarketProductDetailsController.h"
#import "LBProductsDetailsHeaderView.h"
#import "UIImageView+WebCache.h"
#import "LBMarketProductsModel.h"
#import "LBBottomCarView.h"
#import "shoppingCartManager.h"
#import "LBCartController.h"
#import "LBNavigationController.h"

#define kTopImageHeight 380

static NSString *cellID = @"cellID";
@interface LBMarketProductDetailsController ()<UITableViewDelegate,LBBottomCarViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tableView;

/**
 *  图片框高度
 */
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *imageHeight;
/**
 *  图片
 */
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@end

@implementation LBMarketProductDetailsController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    UIBarButtonItem *rightitem = [[UIBarButtonItem alloc]initWithTitle:@"分享" style:UIBarButtonItemStylePlain target:self action:@selector(shareClick:)];
    self.navigationItem.rightBarButtonItem = rightitem;
    
    [self setupUI];
}

-(void)shareClick:(id)sender
{
    UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:@"分享到" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    UIAlertAction *action1 = [UIAlertAction actionWithTitle:@"微信好友" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    UIAlertAction *action2 = [UIAlertAction actionWithTitle:@"微信朋友圈" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    UIAlertAction *action3 = [UIAlertAction actionWithTitle:@"新浪微博" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    UIAlertAction *action4 = [UIAlertAction actionWithTitle:@"QQ空间" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    UIAlertAction *action5 = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    [actionSheet addAction:action1];
    [actionSheet addAction:action2];
    [actionSheet addAction:action3];
    [actionSheet addAction:action4];
    [actionSheet addAction:action5];
    
    [self presentViewController:actionSheet animated:YES completion:nil];
}
#pragma mark - 搭建界面
- (void)setupUI
{
    // 1.设置基本属性,实现偏移
    _tableView.contentInset = UIEdgeInsetsMake(kTopImageHeight, 0, 0, 0);
    _tableView.backgroundColor = [UIColor clearColor];
    // 隐藏内侧的竖条
    _tableView.showsVerticalScrollIndicator = NO;
    
    _tableView.tableFooterView = [[UIView alloc] init];

    [_tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:cellID];
    
    // 设置数据
    // 设置图片框的图片
    NSString *urlStr = [_productModel.img stringByDeletingPathExtension];
    
    
    
   
    
    if([_productModel.name hasPrefix:@"爱鲜蜂·"])
    {
        
        
        
         self.navigationItem.title = [_productModel.name substringFromIndex:4];
    }else
    {
         self.navigationItem.title = _productModel.name;
        
    }
    
    
    
    
    NSURL *url = [NSURL URLWithString:[urlStr substringToIndex:[urlStr rangeOfString:@"@"].location]];
    // - 设置图片
    [_imageView sd_setImageWithURL:url];
    
    // 2.设置headerView
    LBProductsDetailsHeaderView *headerView = [LBProductsDetailsHeaderView productsDetailHeaderView];
    
    headerView.bounds = CGRectMake(0, 0, 0, 200);
    
    _tableView.tableHeaderView = headerView;
    
    // 3.底部的购物车视图
    LBBottomCarView *footView = [LBBottomCarView bottomCarView];
    _tableView.tableFooterView = footView;
    footView.delegate = self;
    [footView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.equalTo(self.view);
        make.height.mas_equalTo(50);
    }];
    
    shoppingCartModel *shoppingCart = [[shoppingCartManager sharedShoppingCartManager] getShoppingCartGoodsWithName:self.productModel.name];
    
    if (shoppingCart) {
        self.productModel.orderCount = shoppingCart.orderCount;
    }
    
    footView.productsModel = self.productModel;
    
    // 设置商品详情
    headerView.productsModel = _productModel;
}

/** 获得当前正在显示的控制器 */
- (UIViewController *)getCurrentVC
{
    UIViewController *result = nil;
    
    UIWindow * window = [[UIApplication sharedApplication] keyWindow];
    if (window.windowLevel != UIWindowLevelNormal)
    {
        NSArray *windows = [[UIApplication sharedApplication] windows];
        for(UIWindow * tmpWin in windows){
            if (tmpWin.windowLevel == UIWindowLevelNormal){
                window = tmpWin;
                break;
            }
        }
    }
    
    UIView *frontView = [[window subviews] objectAtIndex:0];
    id nextResponder = [frontView nextResponder];
    
    if ([nextResponder isKindOfClass:[UIViewController class]])
        result = nextResponder;
    else
        result = window.rootViewController;
    
    return result;
}
-(void)bottomCarView:(LBBottomCarView *)carView selectCar:(LBMarketProductsModel *)selectCar
{
    LBCartController *cartControler = [[LBCartController alloc] init];
    
    cartControler.view.backgroundColor = [UIColor lightGrayColor];
    
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:cartControler];
    navigationController.navigationBar.translucent = NO;
    navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    
    
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"fanhuiback"] style:UIBarButtonItemStylePlain target:self action:@selector(clickToDismiss:)];
    [leftItem setTintColor:[UIColor lightGrayColor]];
    
    cartControler.navigationItem.leftBarButtonItem = leftItem;
    
    [[self getCurrentVC] presentViewController:navigationController animated:YES completion:nil];
}

- (void)clickToDismiss:(UITabBarItem *)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark - 代理方法
// 只要内容发生偏移就会调用
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    // 1.获取内容的偏移量y
    CGFloat offsetY = scrollView.contentOffset.y;

    // 2.修改图片框的高度的约束(计算目标的高度)
    CGFloat height = - offsetY;
    
    // 如果高度 < 0, 就直接 = 0;
    if (height < 0) {
        height = 0;
    }
    
    // 修改约束
    _imageHeight.constant = height;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
