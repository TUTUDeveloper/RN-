//
//  LBMarketProductDetailsController.h
//  LoveBeen
//
//  Created by administrator on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LBMarketProductsModel;
@interface LBMarketProductDetailsController : UIViewController


/**
 *  要显示详情的商品
 */
@property (strong, nonatomic) LBMarketProductsModel *productModel;
@end
