//
//  LBProductsDetailsHeaderView.h
//  LoveBeen
//
//  Created by administrator on 16/9/10.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LBMarketProductsModel;
@interface LBProductsDetailsHeaderView : UIView


+ (instancetype)productsDetailHeaderView;
/**
 *  显示详情的菜品模型
 */
@property (strong, nonatomic) LBMarketProductsModel *productsModel;
@end
