//
//  LBBottomCarView.h
//  LoveBeen
//
//  Created by administrator on 16/9/11.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LBMarketProductsModel,LBBottomCarView;
@protocol LBBottomCarViewDelegate <NSObject>
@optional
- (void)bottomCarView:(LBBottomCarView *)carView selectCar:(LBMarketProductsModel *)selectCar;

@end
@interface LBBottomCarView : UIControl

/**
 *  负责创建视图的类方法
 */
+ (instancetype)bottomCarView;



/**
 *  接收到的菜品数据
 */
@property (strong, nonatomic) LBMarketProductsModel *productsModel;

@property (weak, nonatomic) id<LBBottomCarViewDelegate> delegate;
@end
