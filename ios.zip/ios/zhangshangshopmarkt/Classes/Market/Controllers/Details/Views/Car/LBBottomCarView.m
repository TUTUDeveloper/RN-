//
//  LBBottomCarView.m
//  LoveBeen
//
//  Created by administrator on 16/9/11.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBBottomCarView.h"
#import "LBMarketProductsModel.h"
#import "shoppingCartManager.h"

@interface LBBottomCarView ()
/**
 *  购物车
 */
@property (weak, nonatomic) IBOutlet UIButton *shoppingCarButton;
/**
 *  购物车右上角的label
 */
@property (weak, nonatomic) IBOutlet UILabel *numLabel;
/**
 *  添加商品
 */
@property (weak, nonatomic) IBOutlet UILabel *addProductLabel;
/**
 *  减号按钮
 */
@property(weak, nonatomic) IBOutlet UIButton *decreaseButton;
/**
 *  显示数量的按钮
 */
@property(weak, nonatomic) IBOutlet UILabel *numberLabel;
/**
 *  增加按钮
 */
@property(weak, nonatomic) IBOutlet UIButton *increaseButton;
/**
 *  补货 label
 */
@property (weak, nonatomic) IBOutlet UILabel *replenishmentLabel;

/**
 *  记录之前的数量
 */
@property (assign, nonatomic) NSInteger count;
/**
 *  增加还是减少
 */
@property (assign, nonatomic) BOOL isIncrease;
@end
@implementation LBBottomCarView

+ (instancetype)bottomCarView {
    
    return [[NSBundle mainBundle] loadNibNamed:@"LBBottomCarView" owner:nil options:nil].lastObject;
    
}
- (void)awakeFromNib {
    [super awakeFromNib];
}

#pragma marl -点击按钮
// 购物车按钮
- (IBAction)shoppingCarBtnClick:(UIButton *)sender
{
    if ([_delegate respondsToSelector:@selector(bottomCarView:selectCar:)]) {
        [_delegate bottomCarView:self selectCar:_productsModel];
    }
}
// 减少按钮
- (IBAction)decreaseButtonClick:(UIButton *)sender
{
    self.count--;
    
    [[shoppingCartManager sharedShoppingCartManager] reduceToShoppingCartWithGoodsName:_productsModel.name];
    
    // 减少
    _isIncrease = NO;
    
    // 数量减少,发送事件
    [self sendActionsForControlEvents:UIControlEventValueChanged];
    
    // 减少商品
    [[NSNotificationCenter defaultCenter] postNotificationName:@"reduceProducts" object:@(self.productsModel.orderCount) userInfo:nil];
}
// 增加按钮
- (IBAction)increaseButtonClick:(UIButton *)sender
{
    self.count++;
    
    [[shoppingCartManager sharedShoppingCartManager] addToShoppingCartWithGoodsName:_productsModel.name price:_productsModel.price stock:_productsModel.number];
    // 增加
    _isIncrease = YES;
    
    // 数量增加,发送事件
    [self sendActionsForControlEvents:UIControlEventValueChanged];
    
    // 增加商品
    [[NSNotificationCenter defaultCenter] postNotificationName:@"increaseProducts" object:@(self.productsModel.orderCount) userInfo:nil];
}

#pragma mark - 重写set方法,实现数量控制
-(void)setCount:(NSInteger)count
{
    _count = count;
    
    [self buttonType];
    
    // 将数量信息显示到label上
    _numberLabel.text = @(count).description;
    _numLabel.text = @(count).description;
    
}

- (void)setProductsModel:(LBMarketProductsModel *)productsModel {
    
    _productsModel = productsModel;
    
    self.count = productsModel.orderCount;
    
    // 购物车右上角的label设成圆角
    _numLabel.layer.cornerRadius = 10;
    _numLabel.layer.masksToBounds = YES;
    
    [self buttonType];
}

- (void)buttonType {
    
    if (self.count <= 0) {
        self.numLabel.text = 0;
        _numLabel.hidden = YES;
        self.decreaseButton.enabled = NO;
    } else {
        self.numLabel.text = [NSString stringWithFormat:@"%zd", self.count];
        _numLabel.hidden = NO;
        self.decreaseButton.enabled = YES;
    }
    if (self.count >= self.productsModel.number) {
        self.increaseButton.enabled = NO;
        self.replenishmentLabel.hidden = NO;
    } else {
        self.increaseButton.enabled = YES;
        self.replenishmentLabel.hidden = YES;
    }
}

@end
