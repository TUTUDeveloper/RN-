//
//  LBProductsDetailsHeaderView.m
//  LoveBeen
//
//  Created by administrator on 16/9/10.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBProductsDetailsHeaderView.h"
#import "LBMarketProductsModel.h"

@interface LBProductsDetailsHeaderView ()
/**
 *  商品名称
 */
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
/**
 *  商品价格
 */
@property (weak, nonatomic) IBOutlet UILabel *priceLabel;
/**
 *  市场价格
 */
@property (weak, nonatomic) IBOutlet UILabel *market_priceLabel;
/**
 *  品牌名称
 */
@property (weak, nonatomic) IBOutlet UILabel *brand_nameLabel;
/**
 *  规格
 */
@property (weak, nonatomic) IBOutlet UILabel *specificsLabel;
/**
 *  期限日期
 */
@property (weak, nonatomic) IBOutlet UILabel *sortLabel;



@end
@implementation LBProductsDetailsHeaderView

//- (void)awakeFromNib
//{
//    
//    self.productsModel = nil;
//}

#pragma mark - 创建视图的类方法
+ (instancetype)productsDetailHeaderView {
    
    return [[NSBundle mainBundle] loadNibNamed:@"LBProductsDetailsHeaderView" owner:nil options:nil].lastObject;
}
#pragma mark - 设置数据
-(void)setProductsModel:(LBMarketProductsModel *)productsModel
{
    _productsModel = productsModel;
    
    
    if([productsModel.name hasPrefix:@"爱鲜蜂·"])
    {
        
        
        
       _nameLabel.text = [productsModel.name substringFromIndex:4];
    }else
    {
         _nameLabel.text = productsModel.name;
        
    }
    
    
   
    
    _priceLabel.text = [NSString stringWithFormat:@"￥ %.2f", productsModel.price];
    
    _market_priceLabel.text = [NSString stringWithFormat:@"￥ %.2f", productsModel.market_price];
    
    
    if([productsModel.brand_name hasPrefix:@"爱鲜蜂"])
    {
        
        
        
        _brand_nameLabel.text = @"掌上彩购超市";
    }else
    {
        _brand_nameLabel.text = productsModel.brand_name;
        
    }
    
    
    
    _specificsLabel.text = productsModel.specifics;

}


@end
