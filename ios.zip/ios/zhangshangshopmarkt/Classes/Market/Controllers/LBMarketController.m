//
//  LBMarketController.m
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/7.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBMarketController.h"
#import "YYModel.h"
#import "LBMarketCategorysModel.h"
#import "LBMarketProductsModel.h"
#import "LBMarketCategorysTableViewCell.h"
#import "LBMarketProductsTableViewCell.h"
#import "LBMaeketHeaderFootView.h"
#import "LBMarketProductDetailsController.h"
#import "SVProgressHUD.h"
#import "SCanQRCodeViewController.h"
#import "shoppingCartManager.h"
#import "AJAnimationRefreshHeader.h"
#import "CQ_HistoryViewController.h"

static NSString *categoryCellID = @"categoryCellID";
static NSString *productsCellID = @"productsCellID";
static NSString *headerCellID = @"headerCellID";

@interface LBMarketController () <UITableViewDataSource, UITableViewDelegate,LBMarketProductsTableViewCellDelegate>

/**
 *  分类列表
 */
@property (weak, nonatomic) UITableView *categorysTableView;
/**
 *  商品列表
 */
@property (weak, nonatomic) UITableView *productsTableView;

@end

@implementation LBMarketController {
    /**
     *  分类列表
     */
    NSArray<LBMarketCategorysModel *> *_categorysList;
    /**
     *  商品列表
     */
    NSMutableArray<LBMarketProductsModel *> *_productsList;
    /**
     *  所有商品
     */
    NSDictionary *_dictProducts;
    /**
     *  保存所选的商品分类索引
     */
    NSInteger sectionNum;
    /**
     *  保存所有已经被用户选择商品的模型
     */
    NSMutableArray<LBMarketProductsModel *> *_carProductsList;
    /**
     *  商品存储模型字典(解决 cell 复用)
     */
//    NSMutableDictionary *_productsModelDict;
    UIImageView *_imgView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 加载数据是页面出现菊花
    [SVProgressHUD  showWithStatus:@"正在加载网络数据"];
    
    // 实例化商品列表
    _productsList = [NSMutableArray array];
    
    // 实例化所有商品
    _dictProducts = [NSDictionary dictionary];
    
    // 实例化商品存储模型字典
//    _productsModelDict = [NSMutableDictionary dictionary];
    
    // 标题
    self.navigationItem.title = @"掌上超市";
    
    
    // 左侧的扫一扫按钮
    UIBarButtonItem *saoYiSaoItem = [[UIBarButtonItem alloc] initWithImage:[[UIImage imageNamed:@"saoyisaohui"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] style:UIBarButtonItemStylePlain target:self action:@selector(saoYiSao)];
    
    // 右侧的搜索按钮
    UIBarButtonItem *souSuoItem = [[UIBarButtonItem alloc] initWithImage:[[UIImage imageNamed:@"icon_search"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] style:UIBarButtonItemStylePlain target:self action:@selector(souSuo)];
    
    // 把按钮添加到控制器上
    self.navigationItem.leftBarButtonItem = saoYiSaoItem;
    self.navigationItem.rightBarButtonItem = souSuoItem;
    
    // 加载数据
    [self loadData];
}

/// MARK: - 扫一扫
- (void)saoYiSao {
    SCanQRCodeViewController *scan = [[SCanQRCodeViewController alloc] init];
    [self.navigationController pushViewController:scan animated:YES];
}

/// MARK: - 搜索(暂未实现)
- (void)souSuo
{
    CQ_HistoryViewController *historyViewController = [[CQ_HistoryViewController alloc]init];
    [self.navigationController pushViewController:historyViewController animated:YES];
}

#pragma mark -cell的代理方法
/// 增加的方法
-(void)ProductsTableViewCell:(LBMarketProductsTableViewCell *)ProductsTableViewCell didFinishIncreseFood:(LBMarketProductsModel *)ProductsModel andStartPoint:(CGPoint)startPoint {
    
    [[shoppingCartManager sharedShoppingCartManager] addToShoppingCartWithGoodsName:ProductsModel.name price:ProductsModel.price stock:ProductsModel.number];
    
//    [_productsModelDict setObject:ProductsModel forKey:[NSString stringWithFormat:@"%@-%@", ProductsModel.product_id, ProductsModel.name]];
    
    // MARK: - 0.保存商品到集合中 -> 如果没有包含再进行添加
    // [_carList containsObject:food] -> 判断数组集合中是否包含一个对象
    if (![_carProductsList containsObject:ProductsModel]) {
        [_carProductsList addObject:ProductsModel];
    }
    
    // MARK: - 动画!
    // - 1.添加图片框
    _imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 150,150)];
    
    NSData * imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",ProductsModel.img]]];
    _imgView.image = [UIImage imageWithData:imageData];
    _imgView.center = startPoint;
    
    [UIView animateWithDuration:1.0 animations:^{
        _imgView.transform = CGAffineTransformScale(_imgView.transform, .5, .5);
    } completion:nil];
    _imgView.layer.cornerRadius = 75;
    _imgView.layer.masksToBounds = YES;
    
    // - 将图片框添加给窗口
    UIWindow *keyW = [UIApplication sharedApplication].keyWindow;
    [keyW addSubview:_imgView];
    
    // - 2.开启核心动画,让图片框运动
    // 1.创建对象
    CAKeyframeAnimation *anim = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    
    // 2.设置属性
    // - 路径对象
    UIBezierPath *path = [UIBezierPath bezierPath];
    // - 移动到起点
    startPoint.x -= (313 - self.categorysTableView.frame.size.width);
    startPoint.y -= 5;
    [path moveToPoint:startPoint];
    
    // 结束点
    CGPoint endP = CGPointMake(240, keyW.bounds.size.height - 45);
    
    // 控制点
    CGPoint controlP = CGPointMake(startPoint.x + 130, startPoint.y - 120);

    // 添加完美路径
    [path addQuadCurveToPoint:endP controlPoint:controlP];
    
    anim.path = path.CGPath;
    
    // 不让闪回去
    anim.removedOnCompletion = NO;
    anim.fillMode = kCAFillModeForwards;
    
    anim.duration = 1;
    
    // 设置动画的代理
    anim.delegate = self;
    [anim setValue:_imgView forKey:@"imgV"];
    
    // 3.添加
    [_imgView.layer addAnimation:anim forKey:nil];
}

/// 移除图片框
- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag {
    
    // 1.移除图片框
    // - 取出图片框
    UIImageView *imgV = [anim valueForKey:@"imgV"];
    // - 移除核心动画
    [imgV.layer removeAllAnimations];
    
    // - 移除
    [imgV removeFromSuperview];

}

/// 减少的方法
-(void)ProductsTableViewCell:(LBMarketProductsTableViewCell *)ProductsTableViewCell didFinishDecreseFood:(LBMarketProductsModel *)ProductsModel {
    
    [[shoppingCartManager sharedShoppingCartManager] reduceToShoppingCartWithGoodsName:ProductsModel.name];
    
    [_productsTableView reloadData];
}

#pragma mark - 实现增加、减少产品的通知方法
- (void)increaseProductsNotification:(NSNotification *)notifi {
    
    UITabBarItem *tabBarItem = [[[self.tabBarController tabBar] items] objectAtIndex:2];
    [tabBarItem setBadgeValue:[NSString stringWithFormat:@"%zd", [[shoppingCartManager sharedShoppingCartManager] getShoppingCartTotalCount]]];
}

- (void)reduceProductsNotification:(NSNotification *)notifi {

    UITabBarItem *tabBarItem = [[[self.tabBarController tabBar] items] objectAtIndex:2];
    [tabBarItem setBadgeValue:[NSString stringWithFormat:@"%zd", [[shoppingCartManager sharedShoppingCartManager] getShoppingCartTotalCount]]];
    if ([[shoppingCartManager sharedShoppingCartManager] getShoppingCartTotalCount] == 0) {
        tabBarItem.badgeValue = nil;
    }
}

#pragma mark - tableView的代理方法
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    // 选中了分类里面的cell!
    if (tableView == _categorysTableView) {
        
        NSString *productsID = _categorysList[indexPath.row].id;
        
        NSArray *arrProducts = [_dictProducts objectForKeyedSubscript:productsID];
        
        // 商品数据数组
        _productsList = [NSArray yy_modelArrayWithClass:[LBMarketProductsModel class] json:arrProducts].copy;
        sectionNum = indexPath.row;
        // 选中后刷新右面商品 tableView
        [_productsTableView reloadData];
        
        // 让商品视图,选中第一行!
        NSIndexPath *path = [NSIndexPath indexPathForRow:0 inSection:0];
        [_productsTableView selectRowAtIndexPath:path animated:NO scrollPosition:UITableViewScrollPositionTop];
        
        return;
    }
    
    // 点击商品
    // 1.获取选中的商品
    LBMarketProductsModel *selectProduct = _productsList[indexPath.row];
    
    // 2.创建详情vc对象
    LBMarketProductDetailsController *detailController = [[LBMarketProductDetailsController alloc] init];

    detailController.productModel = selectProduct;
    
    UIBarButtonItem *item = [[UIBarButtonItem alloc]init];
    item.title = @"";
    self.navigationItem.backBarButtonItem = item;
    
    // 3.跳转
    [self.navigationController pushViewController:detailController animated:YES];
}

- (void)viewWillAppear:(BOOL)animated {
    
    [_productsTableView reloadData];
}

// 一定要设置组标题的高度,才会调用这个代理方法!
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    
    // 0.如果是分类列表,直接返回
    if (tableView == _categorysTableView) {
        return nil;
    }
    
    // 1.创建headerView
    LBMaeketHeaderFootView *headerView = [tableView dequeueReusableHeaderFooterViewWithIdentifier:headerCellID];
    
    // 2.设置数据
   // NSLog(@"header");
    headerView.headerTitle = _categorysList[sectionNum].name;
    
    // 3.返回
    return headerView;
}

#pragma mark - 数据源方法
// 组
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    // 判断列表是谁
    // 分类列表
    if (tableView == _categorysTableView) {
        return 1;
    }
    
    // 商品列表 -> 和分类模型的数量一样

    return 1;
}

// 行
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    // 分类列表
    if (tableView == _categorysTableView) {
        return _categorysList.count;
    }
    
    // 商品列表
    return _productsList.count;
}

// cell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    // 1.创建 cell
    NSString *cellId = ((tableView == _categorysTableView) ? categoryCellID : productsCellID);
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId forIndexPath:indexPath];
    
    // 1.1 分类的 cell
    if (tableView == _categorysTableView) {
        
        // 1.1.1 设置分类的数据
        ((LBMarketCategorysTableViewCell *)cell).categorysModel = _categorysList[indexPath.row];
        
        // 1.1.2 返回 cell
        return cell;
    }
    // 1.2 商品的 cell
    // 2.设置商品数据
    LBMarketProductsModel *productsModel = _productsList[indexPath.row];
    
    shoppingCartModel *shoppingCart = [[shoppingCartManager sharedShoppingCartManager] getShoppingCartGoodsWithName:productsModel.name];
    
    if (shoppingCart) {
        productsModel.orderCount = shoppingCart.orderCount;
    } else {
        productsModel.orderCount = 0;
    }
    
    

//    LBMarketProductsModel *products = [_productsModelDict objectForKey:[NSString stringWithFormat:@"%@-%@", productsModel.product_id, productsModel.name]];
//    if (products.orderCount == 0) {
//        products = productsModel;
//    }
    ((LBMarketProductsTableViewCell *)cell).productsModel = productsModel;
    
    //  设置商品cell的代理
    ((LBMarketProductsTableViewCell *)cell).delegate = self;
    
    // 3.返回 cell
    return cell;
}

#pragma mark - 加载数据
- (void)loadData {
    
    // 获取tmp路径
    NSString *tmpPath = NSTemporaryDirectory();
    
    // 获取文件路径
    NSString *fileCategorysPath = [tmpPath stringByAppendingPathComponent:@"categorys.plist"];
    NSString *fileProductsPath = [tmpPath stringByAppendingPathComponent:@"products.plist"];
    
    // 解档
    _categorysList = [NSKeyedUnarchiver unarchiveObjectWithFile:fileCategorysPath];
    _dictProducts = [NSKeyedUnarchiver unarchiveObjectWithFile:fileProductsPath];
    
    // 判断沙盒中商品分类 和 商品是否已经存储
    if (_categorysList && _dictProducts) {
        NSArray *arrProducts = _dictProducts[@"a106"];
      
      
        _productsList = [NSArray yy_modelArrayWithClass:[LBMarketProductsModel class] json:arrProducts].copy;
      

//      _productsList=(NSMutableArray *)[[_productsList reverseObjectEnumerator] allObjects];
      
      
        [[NSOperationQueue mainQueue] addOperationWithBlock:^{
            [SVProgressHUD  dismiss];
            [self setupUI];
        }];
    }
    
    NSMutableDictionary *param = [NSMutableDictionary dictionary];
    // type = 0/1
    [param setValue:@"5" forKey:@"call"];
    
    // 获取数据
    [DSHTTPClient postUrlString:@"supermarket.json.php" withParam:param withSuccessBlock:^(id data) {
//        NSLog(@"%@",data);
        
        // 根据节点查找相应的数据
        // 商品分类数据
        NSArray<NSDictionary *> *arrCategorys = data[@"data"][@"categories"];
        
        // 把获得到得数据赋值给全局变量
        // 商品分类数据
        _categorysList = [NSArray yy_modelArrayWithClass:[LBMarketCategorysModel class] json:arrCategorys];
            
        // 商品数据(根据分类ID获取到每种分类的数据)
        _dictProducts = data[@"data"][@"products"];
      

      
      
    
      
      
      
      
        // 归档
        [NSKeyedArchiver archiveRootObject:_categorysList toFile:fileCategorysPath];
        [NSKeyedArchiver archiveRootObject:_dictProducts toFile:fileProductsPath];
        
        // 遍历商品数据数组,得到所有商品数据
        NSArray *arrProducts = data[@"data"][@"products"][@"a106"];
        _productsList = [NSArray yy_modelArrayWithClass:[LBMarketProductsModel class] json:arrProducts].copy;
      
//       _productsList=(NSMutableArray *)[[_productsList reverseObjectEnumerator] allObjects];
      
        // 刷新一下页面
        [[NSOperationQueue mainQueue] addOperationWithBlock:^{
            // 菊花消失
            [SVProgressHUD  dismiss];
            [self setupUI];
        }];
        
    } withFailedBlock:^(NSError *error) {
        NSLog(@"%@",error);
    } withErrorBlock:^(NSString *message) {
        NSLog(@"%@",message);
    }];
}

#pragma mark - 搭建界面
- (void)setupUI {
//        self.view.backgroundColor = [UIColor yellowColor];

    //监听增加产品通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(increaseProductsNotification:) name:@"increaseProducts" object:nil];
    
    //监听减少产品通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reduceProductsNotification:) name:@"reduceProducts" object:nil];
    
    //发送通知
    UITabBarItem *tabBarItem = [[[self.tabBarController tabBar] items] objectAtIndex:2];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"increaseProducts" object:@([[shoppingCartManager sharedShoppingCartManager] getShoppingCartTotalCount]) userInfo:nil];
    if ([[shoppingCartManager sharedShoppingCartManager] getShoppingCartTotalCount] == 0) {
        tabBarItem.badgeValue = nil;
    }
    
    // MARK: - 1.左侧的分类列表视图
    UITableView *categorysTableView = [[UITableView alloc] init];
    
    [self.view addSubview:categorysTableView];
    
    [categorysTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.equalTo(self.view);
        make.width.mas_equalTo(86);
        make.bottom.equalTo(self.view).offset(-46);
    }];
    
    // MARK: - 2.右侧的商品列表视图
    UITableView *productsTableView = [[UITableView alloc] init];
    
    [self.view addSubview:productsTableView];
    
    [productsTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.bottom.equalTo(categorysTableView);
        make.right.equalTo(self.view);
        make.left.equalTo(categorysTableView.mas_right);
    }];
    
    // MARK: --------设置列表的属性--------
    // 1.设置数据源和代理对象
    categorysTableView.dataSource = self;
    categorysTableView.delegate = self;
    
    productsTableView.dataSource = self;
    productsTableView.delegate = self;
    
    // 2.注册 cell
    [categorysTableView registerClass:[LBMarketCategorysTableViewCell class] forCellReuseIdentifier:categoryCellID];
    [productsTableView registerClass:[LBMarketProductsTableViewCell class] forCellReuseIdentifier:productsCellID];
    [productsTableView registerClass:[LBMaeketHeaderFootView class] forHeaderFooterViewReuseIdentifier:headerCellID];
    
    // 一定要设置这个属性才会调用对应的代理方法
    productsTableView.sectionHeaderHeight = 23;
    
    // 3.不显示多余的行
    categorysTableView.tableFooterView = [[UIView alloc] init];
    productsTableView.tableFooterView = [[UIView alloc] init];
    
    // 4.隐藏指示条
    categorysTableView.showsVerticalScrollIndicator = NO;
    productsTableView.showsVerticalScrollIndicator = NO;
    
    // 5.设置行高
    categorysTableView.rowHeight = 40;
    
    //    productsTableView.estimatedRowHeight = 120;
    productsTableView.rowHeight = 90;
    
    // 6.取消分割线
    categorysTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    productsTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    // MARK: - 3.记录成员变量
    _categorysTableView = categorysTableView;
    _productsTableView = productsTableView;
    
    // 让分类视图,选中第一行
    NSIndexPath *path = [NSIndexPath indexPathForRow:0 inSection:0];
    [_categorysTableView selectRowAtIndexPath:path animated:YES scrollPosition:UITableViewScrollPositionTop];
    
    // 下拉刷新
    AJAnimationRefreshHeader *header = [AJAnimationRefreshHeader headerWithRefreshingTarget:self refreshingAction:@selector(headerRefeshData)];
    _productsTableView.mj_header = header;
}
#pragma mark - 实现下拉刷新方法
- (void)headerRefeshData{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self.productsTableView.mj_header endRefreshing];
    });
}
@end
