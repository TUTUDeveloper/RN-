//
//  LBMarketCategorysModel.h
//  LoveBeen
//
//  Created by Angel-xin on 2016/09/08.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LBMarketCategorysModel : NSObject

/**
 *  类别名称
 */
@property (copy, nonatomic) NSString *name;
/**
 *  类别排序
 */
@property (assign, nonatomic) NSInteger sort;
/**
 *  类别标识
 */
@property (copy, nonatomic) NSString *id;

@end

/*
 categories = (
	{
	visibility = 1;
	sort = 1;
	pcid = 55;
	id = a106;
	disabled_show = 0;
	name = 优选水果;
	icon = /upload/activity/2015071416553788.png;
 }
 */


