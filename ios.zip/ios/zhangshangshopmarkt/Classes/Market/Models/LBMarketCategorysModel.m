//
//  LBMarketCategorysModel.m
//  LoveBeen
//
//  Created by Angel-xin on 2016/09/08.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBMarketCategorysModel.h"

@implementation LBMarketCategorysModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

@end

