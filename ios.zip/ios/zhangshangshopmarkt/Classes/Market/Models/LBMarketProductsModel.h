//
//  LBMarketProductsModel.h
//  LoveBeen
//
//  Created by Angel-xin on 2016/09/08.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LBMarketProductsModel : NSObject

/**
 *  商品价格
 */
@property (assign, nonatomic) CGFloat price;
/**
 *  规格
 */
@property (copy, nonatomic) NSString *specifics;
/**
 *  买一赠一
 */
@property (copy, nonatomic) NSString *pm_desc;
/**
 *  市场价格
 */
@property (assign, nonatomic) CGFloat market_price;
/**
 *  商品图片
 */
@property (copy, nonatomic) NSString *img;
/**
 *  商品名称
 */
@property (copy, nonatomic) NSString *name;
/**
 *  商品分类ID
 */
@property (copy, nonatomic) NSString *category_id;
/**
 *  负责记录自己的数量
 */
@property (assign, nonatomic) NSInteger orderCount;
/**
 *  库存
 */
@property (assign, nonatomic) NSInteger number;
/**
 *  品牌名称
 */
@property (copy, nonatomic) NSString *brand_name;
/**
 *  期限日期
 */
@property (copy, nonatomic) NSString *sort;
/**
 *  商品ID
 */
@property (copy, nonatomic) NSString *product_id;
@end

/*
    partner_price = 9.90;
	tag_ids = 5;
	specifics = 400g/盒;
	pm_desc = ;     买一赠送
	dealer_id = 7951;      经销商
	market_price = 15.00;
	sort = 0;  分类
	safe_day = 0;    安全
	cart_group_id = 0;
	hot_degree = 0;
	img = http://img01.bqstatic.com/upload/goods/000/001/0229/0000010229.jpg@200w_200h_90Q.jpg;
	attribute = ;
	store_nums = 50;
	name = 泰国龙眼;
	brand_id = 128;
	is_xf = 1;     // 精选
	source_id = 1;
	cid = 106;
	id = 10229;
//	number = 7; 补货中
	ismix = 0;
	product_id = 10229;
	had_pm = 0;
	pre_img = 0000010229.jpg;
	pre_imgs = 0000010229_18468.jpg,;
	brand_name = ;
	pcid = 55;
	category_id = 106;
	price = 9.90;
 */

/*
 products={
 a106=({
 attribute="";
 "brand_id"=128;
 "brand_name"="\U7231\U9c9c\U8702";
 "cart_group_id"=0;
 "category_id"=106;
 cid=106;
 "dealer_id"=7951;
 "had_pm"=0;
 "hot_degree"=0;
 id=10229;
 img="http://img01.bqstatic.com/upload/goods/000/001/0229/0000010229.jpg@200w_200h_90Q.jpg";
 "is_xf"=1;
 ismix=0;
 "market_price"="15.00";
 name="\U7231\U9c9c\U8702\U00b7\U6cf0\U56fd\U9f99\U773c";
 number=7;
 "partner_price"="9.90";
 pcid=55;
 "pm_desc"="";
 "pre_img"="0000010229.jpg";
 "pre_imgs"="0000010229_18468.jpg,";
 price="9.90";
 "product_id"=10229;
 "safe_day"=0;sort=0;
 "source_id"=1;
 specifics="400g/\U76d2";
 "store_nums"=50;
 "tag_ids"=5;
 }
 
 */
