//
//  LBIderBackController.m
//  LoveBeen
//
//  Created by ITdongZi on 16/9/8.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBIderBackController.h"
#import "Masonry.h"
#import "UIColor+CZAddition.h"
#import "SVProgressHUD.h"



@interface LBIderBackController ()<UITextViewDelegate>

@property (weak,nonatomic) UILabel *labelPlaceHoder;
@property (strong,nonatomic) UITextView *textView;

@end

@implementation LBIderBackController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"意见反馈";
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc]initWithTitle:@"发送" style:UIBarButtonItemStylePlain target:self action:@selector(clickSender:)];
       self.navigationItem.rightBarButtonItem = rightItem;
    [rightItem setTintColor:[UIColor yellowColor]];
    
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"fanhuiback"] style:UIBarButtonItemStylePlain target:self action:@selector(popControllerClick:)];
    [leftItem setTintColor:[UIColor yellowColor]];
    self.navigationItem.leftBarButtonItem = leftItem;

    
    [self setupUI];
    
}
#pragma mark-setupUI
- (void)setupUI{
    self.view.backgroundColor = [UIColor whiteColor];
    
    UILabel *labelIder = [[UILabel alloc]init];
    labelIder.text = @"您的批评和建议能帮助我们更好的完善产品,请留下您的宝贵意见!";
    labelIder.textColor = [UIColor blackColor];
    labelIder.numberOfLines = 0;
    [self.view addSubview:labelIder];
    
    [labelIder mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).offset(15);
        make.left.equalTo(self.view).offset(10);
        make.right.equalTo(self.view).offset(-10);
    }];
    _textView = [[UITextView alloc]init];
    _textView.delegate = self;
    [self.view addSubview:_textView];
    [_textView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view).offset(10);
        make.right.equalTo(self.view).offset(-10);
        make.top.equalTo(labelIder.mas_bottom).offset(15);
        make.height.mas_equalTo(200);
    }];
    
    UILabel *labelPlaceHoder = [[UILabel alloc]initWithFrame:CGRectMake(3, 3, 200, 20)];
    labelPlaceHoder.text = @"请输入您的宝贵意见(300字以内)";
    labelPlaceHoder.textColor = [UIColor cz_colorWithHex:0xCCCCCC];
    self.labelPlaceHoder = labelPlaceHoder;
    labelIder.enabled = NO;
    [_textView addSubview:labelPlaceHoder];
}

#pragma mark-navbar点击事件
- (void)clickSender:(UIBarButtonItem *)sender{
    
    [SVProgressHUD showWithStatus:@"发送中"];
    [self.navigationController popViewControllerAnimated:YES];
}
//点击返回
- (void)popControllerClick:(UIBarButtonItem *)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma UITextViewDelegate
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    
    if (text.length == 0){
        _labelPlaceHoder.hidden = NO;
    }
    else{
        _labelPlaceHoder.hidden = YES;
    }
    return YES;

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc{
   
    [SVProgressHUD dismiss];
}


@end
