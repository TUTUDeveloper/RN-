//
//  LBCommonQuestionVC.m
//  LoveBeen
//
//  Created by ITdongZi on 16/9/8.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBCommonQuestionVC.h"

#import "Masonry.h"

@interface LBCommonQuestionVC ()

@end

@implementation LBCommonQuestionVC

- (void)viewDidLoad {
    [super viewDidLoad];


       [self setupUI];
}
- (void)setupUI{
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
