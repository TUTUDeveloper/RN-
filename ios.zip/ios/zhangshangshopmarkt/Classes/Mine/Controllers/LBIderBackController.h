//
//  LBIderBackController.h
//  LoveBeen
//
//  Created by ITdongZi on 16/9/8.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LBIderBackController : UIViewController
@end
