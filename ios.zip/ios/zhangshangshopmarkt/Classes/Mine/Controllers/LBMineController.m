//
//  LBMineController.m
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/7.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBMineController.h"
#import "LBMineTopCell.h"
#import "LBMineModel.h"
#import "LBCustomerServiceController.h"
#import "LBIderBackController.h"
#import "LBMyOrederViewController.h"
#import "LBCouponViewController.h"
#import "LBMessageViewController.h"
#import "LBMineHeaderView.h"
#import "LBSettingController.h"
#import "LBMyAddressViewController.h"
#import "LBViewController.h"


typedef NS_ENUM(NSInteger, LBMineTopCellButtonStyle) {
    LBMineTopCellButtonStyleOrder = 1,
    LBMineTopCellButtonStyleCoupon = 2,
    LBMineTopCellButtonStyleMessage = 3
};


static NSString *cellID = @"cellID";
static NSString *topCellID = @"topCellID";


@interface LBMineController () <UITableViewDataSource,UITableViewDelegate,LBMineTopCellDelegate,LBMineHeaderViewDelegate>

@end


@implementation LBMineController{
    NSArray<LBMineModel *> *_mineList;
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    [self.navigationController setNavigationBarHidden:YES animated:YES];
//    self.navigationController.navigationBar.alpha = 0;
//    self.navigationController.navigationBar.translucent = NO;
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    [self.navigationController setNavigationBarHidden:NO animated:YES];
//    self.navigationController.navigationBar.alpha = 1;
//    self.navigationController.navigationBar.translucent = NO;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self loadData];
    [self setupUI];
}

#pragma mark - Load data
- (void)loadData{
    NSURL *URL = [[NSBundle mainBundle] URLForResource:@"mine.plist" withExtension:nil];
    NSArray<NSDictionary *> *array = [NSArray arrayWithContentsOfURL:URL];
    
    NSMutableArray<LBMineModel *> *arrayM = [NSMutableArray arrayWithCapacity:array.count];
    
    [array enumerateObjectsUsingBlock:^(NSDictionary * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        LBMineModel *mineModel = [LBMineModel mineModelWithDictionary:obj];
        [arrayM addObject:mineModel];
    }];
    
    _mineList = [arrayM copy];
}

#pragma mark - Set up user interface
- (void)setupUI{
    self.view.backgroundColor = [UIColor lightGrayColor];
    
    //tableView
    UITableView *tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    tableView.dataSource = self;
    tableView.delegate = self;
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    tableView.tableFooterView = [[UIView alloc] init];
    [self.view addSubview:tableView];
    [tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:cellID];
    [tableView registerNib:[UINib nibWithNibName:@"LBMineTopCell" bundle:nil] forCellReuseIdentifier:topCellID];
    
    //headerView
    LBMineHeaderView *headerView = [[NSBundle mainBundle] loadNibNamed:@"LBMineHeaderView" owner:nil options:nil].lastObject;
    headerView.delegate = self;
    headerView.frame = CGRectMake(0, 0, tableView.bounds.size.width, 150);
    tableView.tableHeaderView = headerView;
}

#pragma mark - Mine header view delegate
- (void)mineHeaderView:(LBMineHeaderView *)mineHeaderView settingButtonClick:(UIButton *)sender{
    LBSettingController *settingController = [[LBSettingController alloc] init];
    [self.navigationController pushViewController:settingController animated:YES];
}

#pragma mark - Mine top cell delegate
- (void)mineTopCell:(LBMineTopCell *)mineTopCell didClickButton:(UIButton *)sender{
    switch (sender.tag) {
        case LBMineTopCellButtonStyleOrder:{
            LBMyOrederViewController *myOrederViewController = [[LBMyOrederViewController alloc] init];
            
            [self.navigationController pushViewController:myOrederViewController animated:YES];
        }
            break;
        case LBMineTopCellButtonStyleCoupon:{
            LBCouponViewController *myOrederViewController = [[LBCouponViewController alloc] init];
            [self.navigationController pushViewController:myOrederViewController animated:YES];
        }
            break;
        case LBMineTopCellButtonStyleMessage:{
            LBMessageViewController *myOrederViewController = [[LBMessageViewController alloc] init];
            [self.navigationController pushViewController:myOrederViewController animated:YES];
        }
            break;
        default:
            break;
    }
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 4;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    switch (section) {
        case 0:
            return 1;
        case 1:
            return 2;
        case 2:
            return 1;
        case 3:
            return 2;
        default:
            return 0;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        LBMineTopCell *cell = [tableView dequeueReusableCellWithIdentifier:topCellID forIndexPath:indexPath];
        cell.frame = CGRectMake(0, 0, self.view.bounds.size.width, 80);
        cell.delegate = self;
        return cell;
    }
    LBMineModel *mineModel;
    switch (indexPath.section) {
        case 1:
            mineModel = _mineList[indexPath.row];
            break;
        case 2:
            mineModel = _mineList[2 + indexPath.row];
            break;
        case 3:
            mineModel = _mineList[3 + indexPath.row];
            break;
    }
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID forIndexPath:indexPath];
    cell.imageView.image = [UIImage imageNamed:mineModel.icon];
    cell.textLabel.text = mineModel.title;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    //separatorLine
    UIView *separatorView = [[UIView alloc] initWithFrame:CGRectMake(0, cell.frame.size.height, cell.frame.size.width, 1)];
    separatorView.backgroundColor = [UIColor lightGrayColor];
    [cell.contentView addSubview:separatorView];
    
    return cell;
}

#pragma mark - Table view delegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        return 80;
    }
    return 44;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return 0;
    }
    return 10;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section != 0) {
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
    }
    
    if (indexPath.section == 3 && indexPath.row == 0) {
        LBCustomerServiceController *customerServiceController = [[LBCustomerServiceController alloc] init];
        [self.navigationController pushViewController:customerServiceController animated:YES];
    } else if (indexPath.section == 3 && indexPath.row == 1) {
        LBIderBackController *iderBackController = [[LBIderBackController alloc] init];
        [self.navigationController pushViewController:iderBackController animated:YES];
    }
    else if (indexPath.section == 1 & indexPath.row == 0){
        LBMyAddressViewController *myAddressVC = [[LBMyAddressViewController alloc]init];
        [self.navigationController pushViewController:myAddressVC animated:YES];
    }else if (indexPath.section == 1 & indexPath.row == 1){
        LBViewController *myShopVC = [[LBViewController alloc]init];
        [self.navigationController pushViewController:myShopVC animated:YES];
        
    }else if (indexPath.section == 2 && indexPath.row == 0){
        UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:@"分享到" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        UIAlertAction *action1 = [UIAlertAction actionWithTitle:@"微信好友" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        UIAlertAction *action2 = [UIAlertAction actionWithTitle:@"微信朋友圈" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
           
        }];
        UIAlertAction *action3 = [UIAlertAction actionWithTitle:@"新浪微博" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
           
        }];
        UIAlertAction *action4 = [UIAlertAction actionWithTitle:@"QQ空间" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        UIAlertAction *action5 = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        [actionSheet addAction:action1];
        [actionSheet addAction:action2];
        [actionSheet addAction:action3];
        [actionSheet addAction:action4];
        [actionSheet addAction:action5];
        
        [self presentViewController:actionSheet animated:YES completion:nil];
        
    }
    


}

@end
