//
//  shopCell.h
//  MineShop
//
//  Created by XJ on 16/9/11.
//  Copyright © 2016年 XJ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ShopModel.h"

@interface shopCell : UITableViewCell

@property (strong, nonatomic) ShopModel *model;

@end
