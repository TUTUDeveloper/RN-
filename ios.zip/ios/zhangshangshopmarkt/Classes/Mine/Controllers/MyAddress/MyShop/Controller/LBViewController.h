//
//  ViewController.h
//  MineShop
//
//  Created by XJ on 16/9/11.
//  Copyright © 2016年 XJ. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface LBViewController : UIViewController


@end

