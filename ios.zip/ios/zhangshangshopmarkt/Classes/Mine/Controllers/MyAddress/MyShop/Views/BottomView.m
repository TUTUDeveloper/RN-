//
//  BottomView.m
//  MineShop
//
//  Created by XJ on 16/9/11.
//  Copyright © 2016年 XJ. All rights reserved.
//

#import "BottomView.h"
#import "Masonry.h"

@interface BottomView ()

@property (weak, nonatomic) UIButton *btn;

@end

@implementation BottomView

- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        [self setupUI];
    }
    return self;
}
- (void)clickTopButton
{
    [self.delegate jumpToController];
}
- (void)setupUI
{

    self.backgroundColor = [UIColor whiteColor];
    
    UIButton *btn = [[UIButton alloc]init];
    
    btn.backgroundColor = [UIColor yellowColor];
    [btn setTitle:@"+ 新增店铺" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    btn.titleLabel.textAlignment = NSTextAlignmentCenter;
    btn.layer.cornerRadius = 10;
    [btn addTarget:self action:@selector(clickTopButton) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:btn];
    
    self.btn = btn;

}
- (void)layoutSubviews
{
    CGFloat width = self.bounds.size.width - 100;
    CGFloat height = self.bounds.size.height - 10;
    [self.btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(width, height));
        make.centerX.centerY.equalTo(self);
    }];
}
@end
