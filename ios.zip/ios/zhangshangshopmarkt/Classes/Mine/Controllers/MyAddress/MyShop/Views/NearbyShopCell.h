//
//  NearbyShopCell.h
//  MineShop
//
//  Created by XJ on 16/9/12.
//  Copyright © 2016年 XJ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ShopModel.h"

@interface NearbyShopCell : UITableViewCell

@property(strong, nonatomic) ShopModel *model;

@end
