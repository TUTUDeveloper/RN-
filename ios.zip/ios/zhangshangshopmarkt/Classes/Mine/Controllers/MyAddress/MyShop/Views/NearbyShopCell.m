//
//  NearbyShopCell.m
//  MineShop
//
//  Created by XJ on 16/9/12.
//  Copyright © 2016年 XJ. All rights reserved.
//

#import "NearbyShopCell.h"

@interface NearbyShopCell ()

@property (weak, nonatomic) IBOutlet UILabel *addressLabel;


@end

@implementation NearbyShopCell

- (void)setModel:(ShopModel *)model
{
    _model = model;
    self.addressLabel.text = model.address;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
