//
//  shopCell.m
//  MineShop
//
//  Created by XJ on 16/9/11.
//  Copyright © 2016年 XJ. All rights reserved.
//

#import "shopCell.h"
#import "CZAdditions.h"
#import "Masonry.h"

@interface shopCell ()

@property (weak, nonatomic) UILabel *titleLabel;
@property (weak, nonatomic) UILabel *timeLabel;
@property (weak, nonatomic) UILabel *addressLabel;

@end

@implementation shopCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if(self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])
    {
        [self setupUI];
    }
    return self;
}
//- (void)awakeFromNib {
//    [super awakeFromNib];
//
//    [self setupUI];
//}
- (void)setModel:(ShopModel *)model
{
   
        _model = model;
        self.timeLabel.text = model.timeText;
        self.titleLabel.text = model.titleText;
        self.addressLabel.text = model.addressText;
    
}
- (void)setupUI
{
    UILabel *titleLabel = [[UILabel alloc]init];
    titleLabel.font = [UIFont systemFontOfSize:14];
    [self.contentView addSubview:titleLabel];
    self.titleLabel = titleLabel;
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.equalTo(self.contentView).offset(10);
        make.left.equalTo(self.contentView).offset(5);
    }];
    
    UILabel *timeLabel = [[UILabel alloc]init];
    timeLabel.font = [UIFont systemFontOfSize:10];
    timeLabel.textColor = [UIColor lightGrayColor];
    [self.contentView addSubview:timeLabel];
    self.timeLabel = timeLabel;
    [timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.equalTo(titleLabel.mas_bottom).offset(5);
        make.leading.equalTo(titleLabel);
    }];
    
    UILabel *addressLabel = [UILabel cz_labelWithText:_model.addressText fontSize:12 color:[UIColor blackColor]];
    addressLabel.font = [UIFont systemFontOfSize:10];
    addressLabel.textColor = [UIColor lightGrayColor];
    [self.contentView addSubview:addressLabel];
    self.addressLabel = addressLabel;
    [addressLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.equalTo(timeLabel.mas_bottom).offset(5);
        make.leading.equalTo(timeLabel);
    }];
    
    [self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.equalTo(self.contentView);
        make.bottom.equalTo(addressLabel.mas_bottom).offset(8);
    }];
    
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
