//
//  NearCell.h
//  MineShop
//
//  Created by XJ on 16/9/12.
//  Copyright © 2016年 XJ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ShopModel.h"

@protocol NearCellDelegate <NSObject>

- (void)savenetData;
- (void)deletenetData;

@end

@interface NearCell : UITableViewCell

@property (strong, nonatomic) ShopModel *model;

@property (weak, nonatomic)id<NearCellDelegate> delegate;

@end
