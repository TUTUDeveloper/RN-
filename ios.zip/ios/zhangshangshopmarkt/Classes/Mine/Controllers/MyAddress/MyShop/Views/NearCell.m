//
//  NearCell.m
//  MineShop
//
//  Created by XJ on 16/9/12.
//  Copyright © 2016年 XJ. All rights reserved.
//

#import "NearCell.h"
#import "CZAdditions.h"

@interface NearCell ()

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@property (weak, nonatomic) IBOutlet UILabel *timeLabel;

@property (weak, nonatomic) IBOutlet UILabel *addressLabel;

@property (weak, nonatomic) IBOutlet UIButton *addressBtn;

@property (weak, nonatomic) IBOutlet UILabel *awayLabel;


@end
@implementation NearCell

- (void)setModel:(ShopModel *)model
{
    _model = model;
    self.titleLabel.text = model.titleText;
    self.timeLabel.text = model.timeText;
    self.addressLabel.text = model.addressText;
    self.awayLabel.text = model.away;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.addressBtn.layer.cornerRadius = 10;
    
    
    
}
- (IBAction)addressAdd:(UIButton *)sender {
    
    if(self.addressBtn.selected == NO){
        self.addressBtn.tintColor = [UIColor clearColor]; 
        [self.addressBtn setTitle:@"已收藏" forState:UIControlStateSelected];
        [self.addressBtn setBackgroundColor:[UIColor lightGrayColor]];
        self.addressBtn.selected = YES;
        
        [self.delegate savenetData];
        
    }else
    {
        self.addressBtn.selected = NO;
        self.addressBtn.backgroundColor = [UIColor yellowColor];
        [self.delegate deletenetData];
        
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
