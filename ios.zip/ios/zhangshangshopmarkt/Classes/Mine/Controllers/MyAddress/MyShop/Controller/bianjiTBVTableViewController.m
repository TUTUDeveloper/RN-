//
//  bianjiTBVTableViewController.m
//  MineShop
//
//  Created by XJ on 16/9/11.
//  Copyright © 2016年 XJ. All rights reserved.
//

#import "bianjiTBVTableViewController.h"
#import "NearCell.h"
#import "NearbyShopCell.h"
#import "ShopModel.h"
#import "SVProgressHUD.h"

@interface bianjiTBVTableViewController ()<NearCellDelegate>

@end

@implementation bianjiTBVTableViewController
{
    NSArray<ShopModel *> *_selfList;

}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"新增店铺";
    self.tableView.backgroundColor = [UIColor lightGrayColor];
    self.tableView = [[UITableView alloc]initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
    [self.tableView registerNib:[UINib nibWithNibName:@"NearbyShopCell" bundle:nil] forCellReuseIdentifier:@"nearByCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"NearCell" bundle:nil] forCellReuseIdentifier:@"nearCell"];
    self.tableView.estimatedRowHeight =400;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    [self loadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if(section == 1)
    {
        NSString *title = @"附近的店铺";
        return title;
    }
    return nil;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 1.0f;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if(section == 0)
    {
        return 10.0f;
    }else
    {
        return 40.0f;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(section == 0)
    {
        return 1;
    }else if(section == 1)
    {
        return _selfList.count;
    }
    return 0;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section == 0)
    {
        NearbyShopCell *cell = [tableView dequeueReusableCellWithIdentifier:@"nearByCell" forIndexPath:indexPath];
        
        ShopModel *model = [[ShopModel alloc]init];
        model.address = @"北京北京北京北京北京";
        cell.model = model;
        
        return cell;
        
    }else if(indexPath.section == 1)
    {
        NearCell *cell = [tableView dequeueReusableCellWithIdentifier:@"nearCell" forIndexPath:indexPath];
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        
        ShopModel *model = [[ShopModel alloc]init];
        
        model = _selfList[indexPath.row];
        
        cell.model = model;
        
        cell.delegate = self;
        return cell;
    }else
    {
        return nil;
    }
 
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section == 0){
         NSLog(@"返回主页");
    }else
    {

    }

}
- (void)deletenetData
{
    [SVProgressHUD showWithStatus:@"取消收藏~"];
    [self.navigationController popViewControllerAnimated:YES];
    [self performSelector:@selector(dismissClick) withObject:nil afterDelay:2];
}

- (void)savenetData
{
    NSString *filePath = [NSSearchPathForDirectoriesInDomains (NSDocumentDirectory, NSUserDomainMask, YES).lastObject stringByAppendingPathComponent:@"hmpersons.db"];
    
    [NSKeyedArchiver archiveRootObject:_selfList toFile:filePath];
    [SVProgressHUD showWithStatus:@"已收藏~"];
    
    [self performSelector:@selector(dismissClick) withObject:nil afterDelay:2];
}
- (void)dismissClick{
    [SVProgressHUD dismiss];
}

- (void)loadData
{
    ShopModel *model = [[ShopModel alloc]init];
    
    model.address = @"北京天安门";
    model.titleText = @"东哥的情趣用品店";
    model.timeText = @"营业时间24小时";
    model.away = @"0.1km";
    model.addressText = @"中特建华大厦旁边的下水道";
    
    ShopModel *model1 = [[ShopModel alloc]init];
    
    model1.address = @"北京天安门";
    model1.titleText = @"东哥的情趣用品店";
    model1.timeText = @"营业时间24小时";
    model1.away = @"0.1km";
    model1.addressText = @"中特建华大厦旁边的下水道";
    
    ShopModel *model2 = [[ShopModel alloc]init];
    
    model2.address = @"北京天安门";
    model2.titleText = @"东哥的情趣用品店";
    model2.timeText = @"营业时间24小时";
    model2.away = @"0.1km";
    model2.addressText = @"中特建华大厦旁边的下水道";
    
    ShopModel *model3 = [[ShopModel alloc]init];
    
    model3.address = @"北京天安门";
    model3.titleText = @"东哥的情趣用品店";
    model3.timeText = @"营业时间24小时";
    model3.away = @"0.1km";
    model3.addressText = @"中特建华大厦旁边的下水道";
    
    _selfList = @[model,model1,model2,model3].copy;
}
/*
*titleText;
*timeText;
*addressText;
*away;
*address;

 */
/*
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:<#@"reuseIdentifier"#> forIndexPath:indexPath];
    
    // Configure the cell...
    
    return cell;
}
*/

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
