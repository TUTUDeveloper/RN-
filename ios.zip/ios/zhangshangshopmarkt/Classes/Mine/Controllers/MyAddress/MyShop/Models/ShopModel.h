//
//  ShopModel.h
//  MineShop
//
//  Created by XJ on 16/9/11.
//  Copyright © 2016年 XJ. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ShopModel : NSObject <NSCoding>

@property (copy, nonatomic)NSString *titleText;
@property (copy, nonatomic)NSString *timeText;
@property (copy, nonatomic)NSString *addressText;
@property (copy, nonatomic)NSString *away;
@property (copy, nonatomic)NSString *address;

@end
