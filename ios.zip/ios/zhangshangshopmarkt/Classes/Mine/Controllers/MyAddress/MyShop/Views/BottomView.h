//
//  BottomView.h
//  MineShop
//
//  Created by XJ on 16/9/11.
//  Copyright © 2016年 XJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol BottomViewDelegate <NSObject>

- (void)jumpToController;

@end
@interface BottomView : UIView
@property (weak, nonatomic) id<BottomViewDelegate> delegate;
@end
