//
//  ViewController.m
//  MineShop
//
//  Created by XJ on 16/9/11.
//  Copyright © 2016年 XJ. All rights reserved.
//

#import "LBViewController.h"
#import "BottomView.h"
#import "Masonry.h"
#import "bianjiTBVTableViewController.h"
#import "shopCell.h"
#import "ShopModel.h"
#import "LBHomeController.h"

@interface LBViewController ()<UITableViewDelegate,UITableViewDataSource,BottomViewDelegate>

@property (weak, nonatomic) UITableView *tvb;

@end

@implementation LBViewController
{
    NSMutableArray<ShopModel *> *_contactList;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor grayColor];
    
    UIBarButtonItem *saveItem = [[UIBarButtonItem alloc] initWithTitle:@"编辑" style:UIBarButtonItemStylePlain target:self action:@selector(saveItemClick:)];
    [saveItem setTintColor:[UIColor yellowColor]];
    self.navigationItem.rightBarButtonItem = saveItem;

    self.navigationItem.title = @"店铺收藏";
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"fanhuiback"] style:UIBarButtonItemStylePlain target:self action:@selector(popControllerClick:)];
    [leftItem setTintColor:[UIColor yellowColor]];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    [self setupUI];
}
- (void)saveItemClick:(UIBarButtonItem *)sender
{
    
}

- (void)setupUI
{
    UITableView *tbV = [[UITableView alloc]initWithFrame:self.view.bounds];
    [self.view addSubview:tbV];
    self.tvb = tbV;
    tbV.delegate = self;
    tbV.dataSource = self;
    self.tvb.estimatedRowHeight = 200;
    //设置行高自动计算
    self.tvb.rowHeight = UITableViewAutomaticDimension;
    
    [tbV setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [tbV registerClass:[shopCell class] forCellReuseIdentifier:@"shopCell"];
    
//    [tbV mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.left.right.equalTo(self.view);
//    }];
//
    
    BottomView *bottomV = [[BottomView alloc]init];
    [self.view addSubview:bottomV];
    bottomV.delegate = self;
    
    [bottomV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.right.left.equalTo(self.view);
        make.height.mas_equalTo(40);
    }];
    
    [self loadData];
}
- (void)jumpToController
{
    
    
    
    bianjiTBVTableViewController *tb = [[bianjiTBVTableViewController alloc]init];
    
    [self.navigationController pushViewController:tb animated:YES];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _contactList.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    shopCell *cell = [tableView dequeueReusableCellWithIdentifier:@"shopCell" forIndexPath:indexPath];
    
        cell.model = _contactList[indexPath.row];

    return cell;
}

- (void)loadData {
    
    // 1.先从文件中读取数据
    // 1.1 获取文件路径
    NSString *filePath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).lastObject stringByAppendingPathComponent:@"hmpersons.db"];
    
    // 1.2 读取数据
    _contactList = [NSKeyedUnarchiver unarchiveObjectWithFile:filePath];
    
    // 2.如果集合没有值,需要实例化,保证以后可以添加数据!
    if (_contactList == nil) {
        _contactList = [NSMutableArray array];
    }
    
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction *action1 = [UIAlertAction actionWithTitle:@"门店自提" style:UIAlertActionStyleDefault handler:^(UIAlertAction *_Nonnull action) {
        
        [self.navigationController popViewControllerAnimated:YES];
        
    }];
    
    UIAlertAction *action2 = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *_Nonnull action) {
         [self.navigationController popViewControllerAnimated:YES];
    }];
    
    UIAlertAction *action3 = [UIAlertAction actionWithTitle:@"送货上门" style:UIAlertActionStyleDefault handler:^(UIAlertAction *_Nonnull action) {
        
        LBHomeController *homeController = [[LBHomeController alloc]init];
        [self.navigationController pushViewController:homeController animated:YES];
    }];
    [_tvb deselectRowAtIndexPath:indexPath animated:NO];
    
    // 添加action
    [actionSheet addAction:action1];
    [actionSheet addAction:action2];
    [actionSheet addAction:action3];
    
    [self presentViewController:actionSheet animated:YES completion:nil];

}

- (void)popControllerClick:(UIBarButtonItem *)sender{
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
