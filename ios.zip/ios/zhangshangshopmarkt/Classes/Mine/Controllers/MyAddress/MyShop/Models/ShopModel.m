//
//  ShopModel.m
//  MineShop
//
//  Created by XJ on 16/9/11.
//  Copyright © 2016年 XJ. All rights reserved.
//

#import "ShopModel.h"
/*
 @property (copy, nonatomic)NSString *titleText;
 @property (copy, nonatomic)NSString *timeText;
 @property (copy, nonatomic)NSString *addressText;
 @property (copy, nonatomic)NSString *away;
 @property (copy, nonatomic)NSString *address;
 */
@implementation ShopModel
- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:_titleText forKey:@"title"];
    [aCoder encodeObject:_timeText forKey:@"time"];
    [aCoder encodeObject:_addressText forKey:@"address"];
    [aCoder encodeObject:_away forKey:@"away"];
    [aCoder encodeObject:_address forKey:@"addressd"];
}
- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super init]) {
        _titleText = [aDecoder decodeObjectForKey:@"title"];
        _timeText = [aDecoder decodeObjectForKey:@"time"];
        _addressText = [aDecoder decodeObjectForKey:@"address"];
        _away = [aDecoder decodeObjectForKey:@"away"];
        _address = [aDecoder decodeObjectForKey:@"addressd"];
    }
    return self;
}
@end
