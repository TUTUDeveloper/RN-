//
//  LBDetailAddressVC.h
//  MyTop
//
//  Created by ITdongZi on 16/9/11.
//  Copyright © 2016年 IOS-yangxudong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LBAddressModel.h"

@class LBDetailAddressVC;

@protocol LBDetailAddressVCDelegate <NSObject>

//新增地址
- (void)addNewAddress:(LBDetailAddressVC *)newAddress newAddressModel:(LBAddressModel *)newModel;
//修改地址
- (void)changeFinishAddress:(LBDetailAddressVC *)changeAddress;

@end

@interface LBDetailAddressVC : UITableViewController

@property (strong,nonatomic) LBAddressModel *model;
@property (weak,nonatomic) id<LBDetailAddressVCDelegate>delegate;


@end
