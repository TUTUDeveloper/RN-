//
//  LBDetailAddressVC.m
//  MyTop
//
//  Created by ITdongZi on 16/9/11.
//  Copyright © 2016年 IOS-yangxudong. All rights reserved.
//

#import "LBDetailAddressVC.h"

@interface LBDetailAddressVC ()
@property (weak, nonatomic) IBOutlet UITextField *contactName;
@property (weak, nonatomic) IBOutlet UITextField *phoneNum;
@property (weak, nonatomic) IBOutlet UITextField *city;
@property (weak, nonatomic) IBOutlet UITextField *location;
@property (weak, nonatomic) IBOutlet UITextField *detailAddress;

@property (weak, nonatomic) IBOutlet UIButton *selectedBtnMan;
@property (weak, nonatomic) IBOutlet UIButton *selectedBtnWenmen;


@property (weak,nonatomic) UIButton *selectedBtn;
@end

@implementation LBDetailAddressVC
{
    NSArray <UIButton *> *_selectedBtnArr;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor cz_colorWithHex:0xEEEEEE];
    self.navigationController.navigationBar.barTintColor = [UIColor cz_colorWithHex:0xEFEFEF];
    
    self.contactName.text = _model.contactsName;
    self.phoneNum.text = _model.phoneNum;
    self.location.text = _model.location;
    self.detailAddress.text = _model.detailAddress;
    self.city.text = _model.city;
    
    [self.tableView registerNib:[UINib nibWithNibName:@"LBDetailAddressVC" bundle:nil] forCellReuseIdentifier:@"cellSex"];
    [self setupUI];
    }
#pragma mark-setupUI
- (void)setupUI{
    
    if (_model != nil) {
        self.navigationItem.title = @"修改地址";
        UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"fanhuiback"] style:UIBarButtonItemStylePlain target:self action:@selector(popControllerClick:)];
        [leftItem setTintColor:[UIColor lightGrayColor]];
        UIBarButtonItem *rightItem = [[UIBarButtonItem alloc]initWithTitle:@"保存" style:UIBarButtonItemStylePlain target:self action:@selector(changeAddressclickSender:)];
        self.navigationItem.rightBarButtonItem = rightItem;
        [rightItem setTintColor:[UIColor lightGrayColor]];
        
        self.navigationItem.leftBarButtonItem = leftItem;
        
        UIButton *delete = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 40)];
        [delete setTitle:@"删除当前地址" forState:UIControlStateNormal];
        [delete setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [delete setBackgroundColor:[UIColor whiteColor]];
        [delete addTarget:self action:@selector(delegateAddress:) forControlEvents:UIControlEventTouchUpInside];
        self.tableView.tableFooterView = delete;

    }
    else{
        self.navigationItem.title = @"添加地址";
        UIBarButtonItem *rightItem = [[UIBarButtonItem alloc]initWithTitle:@"保存" style:UIBarButtonItemStylePlain target:self action:@selector(addAddressclickSender:)];
        self.navigationItem.rightBarButtonItem = rightItem;
        [rightItem setTintColor:[UIColor lightGrayColor]];
        UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"fanhuiback"] style:UIBarButtonItemStylePlain target:self action:@selector(popControllerClick:)];
        [leftItem setTintColor:[UIColor lightGrayColor]];
        self.navigationItem.leftBarButtonItem = leftItem;
        
        
        
    }
    

}

#pragma mark-点击事件
//保存新建的地址
- (void)addAddressclickSender:(UIButton *)sender{
    
    LBAddressModel *newAddressModel = [[LBAddressModel alloc]init];
    
    newAddressModel.phoneNum = self.phoneNum.text;
    newAddressModel.contactsName = self.contactName.text;
    newAddressModel.location = self.location.text;
    newAddressModel.detailAddress = self.detailAddress.text;
    
    if ([self.delegate respondsToSelector:@selector(addNewAddress:newAddressModel:)]) {
        [self.delegate addNewAddress:self newAddressModel:newAddressModel];
    }
    [self.navigationController popViewControllerAnimated:YES];


}

//保存修改的地址
- (void)changeAddressclickSender:(UIButton *)sender{
    
    _model.phoneNum = self.phoneNum.text;
    _model.contactsName = self.contactName.text;
    _model.location = self.location.text;
    _model.detailAddress = self.detailAddress.text;
    
    if ([self.delegate respondsToSelector:@selector(changeFinishAddress:)]) {
        [self.delegate changeFinishAddress:self];
    }
    
    [self.navigationController popViewControllerAnimated:YES];
}


- (IBAction)selectedBtnMan:(UIButton *)sender {
    [self clickbutton:sender];
}

- (IBAction)SelectedBtnWenmen:(UIButton *)sender {
    [self clickbutton:sender];
}

//选择性别
-(void)clickbutton:(UIButton*)sender
{
    
    
    
    _selectedBtn .selected = NO;
    
    
    sender.selected =YES;
    _selectedBtn = sender;
    
    
    
}

//删除当前地址
- (void)delegateAddress:(UIButton *)sender{
    NSLog(@"ff");
    
    
}

#pragma mark-设置头部视图不高度
- (CGFloat )tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    
    return 0.1;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)popControllerClick:(UIBarButtonItem *)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark-代理方法
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section == 1 && indexPath.row == 0) {
        
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"就这样删除了么" message:nil delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
        [alertView show];
        
        
    }
    
}




@end
