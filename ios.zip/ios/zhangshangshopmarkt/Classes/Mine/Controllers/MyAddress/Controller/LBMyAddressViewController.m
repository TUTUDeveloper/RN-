//
//  LBMyAddressViewController.m
//  MyTop
//
//  Created by ITdongZi on 16/9/10.
//  Copyright © 2016年 IOS-yangxudong. All rights reserved.
//

#import "LBMyAddressViewController.h"
#import "Masonry.h"
#import "LBDetailAddressVC.h"
#import "LBAddressModel.h"
#import "LBAddressCell.h"
#import "UIColor+CZAddition.h"

static NSString *addressCell = @"addressCell";

@interface LBMyAddressViewController ()<UITableViewDelegate,UITableViewDataSource,LBDetailAddressVCDelegate,LBAddressCellDelegate>

@property (weak,nonatomic) UITableView *addressTB;
@property (strong,nonatomic) LBDetailAddressVC *detailVC;
@end

@implementation LBMyAddressViewController
{
    NSMutableArray <LBAddressModel *> *_addressList;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupUI];
    
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    self.view.backgroundColor = [UIColor lightGrayColor];
    self.navigationItem.title = @"我的收获地址";
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"fanhuiback"] style:UIBarButtonItemStylePlain target:self action:@selector(popControllerClick:)];
    [leftItem setTintColor:[UIColor lightGrayColor]];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    
    [self loadData];
}

#pragma mark-界面搭建
- (void)setupUI{
    
    UITableView *addressList = [[UITableView alloc]initWithFrame:self.view.bounds];
    addressList.delegate = self;
    addressList.dataSource = self;
    addressList.rowHeight = 100;
    
    self.addressTB = addressList;
    addressList.tableFooterView  = [[UIView alloc]init];
//    UIView *view = [[UIView alloc]init];
//    view.backgroundColor = [UIColor redColor];
//    addressList.tableFooterView = view;
    addressList.backgroundColor = [UIColor cz_colorWithHex:0xEFEFEF];
    [self.view addSubview:addressList];
    [addressList registerNib:[UINib nibWithNibName:@"LBAddressCell" bundle:nil] forCellReuseIdentifier:addressCell];
    
    
    UIView *addAddressView = [[UIView alloc]init];
    addAddressView.backgroundColor = [UIColor groupTableViewBackgroundColor];
    [self.view addSubview:addAddressView];
    [addAddressView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.equalTo(self.view);
        make.height.mas_equalTo(60);
    }];
    
    
    UIButton *addAddressBtn = [[UIButton alloc]init];
//    [addAddressBtn setBackgroundImage:[UIImage imageNamed:@"icon_sendcoupon"] forState:UIControlStateNormal];
    addAddressBtn.backgroundColor = [UIColor cz_colorWithHex:0xEFC82E];
    [addAddressBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [addAddressBtn setTitle:@"+ 新增地址" forState:UIControlStateNormal];
    addAddressBtn.layer.cornerRadius = 10;
    [addAddressView addSubview:addAddressBtn];
    [addAddressBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(addAddressView.mas_top).offset(12);
        make.bottom.equalTo(addAddressView.mas_bottom).offset(-12);
        make.centerX.equalTo(addAddressView.mas_centerX);
        make.width.mas_equalTo(270);
    }];
    [addAddressBtn addTarget:self action:@selector(addAddressClick:) forControlEvents:UIControlEventTouchUpInside];
}

#pragma mark-添加地址
-(void)addAddressClick:(UIButton *)sender{
    UIStoryboard *SB = [UIStoryboard storyboardWithName:@"LBDetailAddressVC" bundle:nil];
    LBDetailAddressVC *detailVC = [SB instantiateViewControllerWithIdentifier:@"detailAddress"];
    
    //代理
    detailVC.delegate = self;
    [self.navigationController pushViewController:detailVC animated:YES];
}
#pragma mark-UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _addressList.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    LBAddressCell *cell = [tableView dequeueReusableCellWithIdentifier:addressCell forIndexPath:indexPath];
    
    LBAddressModel *model = _addressList[indexPath.row];
    cell.delegate = self;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.model = model;
    return cell;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)popControllerClick:(UIBarButtonItem *)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark-默认数据
- (void)loadData{
    LBAddressModel *model1 = [[LBAddressModel alloc]init];
    model1.phoneNum = @"10086-95588";
    model1.contactsName = @"巨魔";
    model1.location = @"上单";
    model1.detailAddress = @"三楼306";
    model1.city = @"德玛西亚";
    
    LBAddressModel *model2 = [[LBAddressModel alloc]init];
    model2.phoneNum = @"10086-95599";
    model2.contactsName = @"乐芙兰";
    model2.location = @"中单";
    model2.detailAddress = @"三楼306";
    model2.city = @"诺克萨斯";
    
    LBAddressModel *model3 = [[LBAddressModel alloc]init];
    model3.phoneNum = @"10086-95533";
    model3.contactsName = @"卡兹克";
    model3.location = @"打野";
    model3.detailAddress = @"三楼306";
    model3.city = @"战争学院";
    
    LBAddressModel *model4 = [[LBAddressModel alloc]init];
    model4.phoneNum = @"10086-95555";
    model4.contactsName = @"凯瑟琳";
    model4.location = @"ADC";
    model4.detailAddress = @"三楼306";
    model4.city = @"艾欧尼亚";
    
    LBAddressModel *model5 = [[LBAddressModel alloc]init];
    model5.phoneNum = @"10086-945445";
    model5.contactsName = @"迦娜";
    model5.location = @"辅助";
    model5.detailAddress = @"三楼306";
    model5.city = @"暗影岛";
    
    _addressList = [NSMutableArray arrayWithObjects:model1,model2,model3,model4,model5, nil];
}

#pragma mark-代理方法

//详情控制器的代理方法
- (void)addNewAddress:(LBDetailAddressVC *)newAddress newAddressModel:(LBAddressModel *)newModel{
    
    //添加地址
    [_addressList insertObject:newModel atIndex:0];
    
    NSIndexPath *path = [NSIndexPath indexPathForRow:0 inSection:0];
    [self.addressTB insertRowsAtIndexPaths:@[path] withRowAnimation:UITableViewRowAnimationBottom];
}

//接收cell中传递的点击方法
- (void)addressCell:(LBAddressCell *)addressCell clickBtn:(UIButton *)sender{
    
    NSIndexPath *indexPath = [self.addressTB indexPathForCell:addressCell];
    LBAddressModel *model = _addressList[indexPath.row];
    UIStoryboard *SB = [UIStoryboard storyboardWithName:@"LBDetailAddressVC" bundle:nil];
    LBDetailAddressVC *detailVC = [SB instantiateViewControllerWithIdentifier:@"detailAddress"];
    
    detailVC.delegate = self;
    detailVC.model = model;
    [self.navigationController pushViewController:detailVC animated:YES];
}

- (void)changeFinishAddress:(LBDetailAddressVC *)changeAddress{
    
    [self.addressTB reloadData];
}

@end
