//
//  LBAddressModel.h
//  MyTop
//
//  Created by ITdongZi on 16/9/11.
//  Copyright © 2016年 IOS-yangxudong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LBAddressModel : NSObject

@property (copy,nonatomic) NSString *contactsName;
@property (copy,nonatomic) NSString *phoneNum;
@property (copy,nonatomic) NSString *city;
@property (copy,nonatomic) NSString *location;
@property (copy,nonatomic) NSString *detailAddress;

@end
