//
//  LBAddressCell.h
//  MyTop
//
//  Created by ITdongZi on 16/9/11.
//  Copyright © 2016年 IOS-yangxudong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LBAddressModel.h"

@class LBAddressCell;
@protocol LBAddressCellDelegate <NSObject>

//传递按钮点击方法
- (void)addressCell:(LBAddressCell *)addressCell clickBtn:(UIButton *)sender;

@end

@interface LBAddressCell : UITableViewCell

@property (strong,nonatomic) LBAddressModel *model;
@property (weak,nonatomic) id<LBAddressCellDelegate> delegate;

@end
