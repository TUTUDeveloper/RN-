//
//  LBDetailAddressCell.m
//  LoveBeen
//
//  Created by ITdongZi on 16/9/11.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBDetailAddressCell.h"

@implementation LBDetailAddressCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
   
    if (self = [super initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:reuseIdentifier]) {
        
        self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    return self;
}

@end
