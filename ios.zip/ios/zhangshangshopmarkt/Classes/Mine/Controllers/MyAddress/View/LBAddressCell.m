//
//  LBAddressCell.m
//  MyTop
//
//  Created by ITdongZi on 16/9/11.
//  Copyright © 2016年 IOS-yangxudong. All rights reserved.
//

#import "LBAddressCell.h"

@interface LBAddressCell ()

@property (weak, nonatomic) IBOutlet UILabel *contactsName;
@property (weak, nonatomic) IBOutlet UILabel *phoneNum;
@property (weak, nonatomic) IBOutlet UILabel *location;
@property (weak, nonatomic) IBOutlet UILabel *detailAddress;

@end

@implementation LBAddressCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
}

- (void)setModel:(LBAddressModel *)model{
    _model = model;
    self.contactsName.text = model.contactsName;
    self.phoneNum.text = model.phoneNum;
    self.location.text = model.location;
    self.detailAddress.text = model.detailAddress;
    
}

- (IBAction)clickBtn:(UIButton *)sender {
    
    if ([self.delegate respondsToSelector:@selector(addressCell:clickBtn:)]) {
        
        [self.delegate addressCell:self clickBtn:sender];
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    
}

@end
