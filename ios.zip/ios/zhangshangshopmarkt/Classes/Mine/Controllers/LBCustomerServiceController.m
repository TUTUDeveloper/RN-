//
//  LBCustomerServiceController.m
//  LoveBeen
//
//  Created by ITdongZi on 16/9/8.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBCustomerServiceController.h"
#import "LBCommonQuestionVC.h"
#import "Masonry.h"
#define K_iderBackID @"iderBackID"

@interface LBCustomerServiceController ()

@end

@implementation LBCustomerServiceController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"客户帮助";
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"fanhuiback"] style:UIBarButtonItemStylePlain target:self action:@selector(popControllerClick:)];
    [leftItem setTintColor:[UIColor yellowColor]];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    [self setupUI];

    //不显示多余的cell
    self.tableView.tableFooterView = [[UIView alloc]init];
}

#pragma mark-界面
- (void)setupUI{
    
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:K_iderBackID];
}

#pragma mark-UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 2;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:K_iderBackID forIndexPath:indexPath];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    if (indexPath.row == 0) {
        cell.textLabel.text = @"客服电话:400-8484-842";
    }
    else{
        cell.textLabel.text = @"常见问题";
    }
    return cell;
}
//点击返回
- (void)popControllerClick:(UIBarButtonItem *)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark-点击cell拨打电话和常见问题
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row == 0) {
        NSString *allString = [NSString stringWithFormat:@"tel:400-8484-842"];
        
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:allString]];
        
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"拨打电话" message:@"400-8484-842" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
        
        [alertView show];
        
    }
    else{
        LBCommonQuestionVC *commonQuestion = [[LBCommonQuestionVC alloc]init];
        
        [self.navigationController pushViewController:commonQuestion animated:YES];
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
