//
//  LBSettingController.m
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/11.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBSettingController.h"
#import "Masonry.h"
#import "LBClearCacheTool.h"
#import "SVProgressHUD.h"
#import "LBSettingAboutUsView.h"
#import "LoginViewController.h"

static NSString *normalCellID = @"normalCellID";


@interface LBSettingController () <UITableViewDataSource,UITableViewDelegate>

@end


@implementation LBSettingController{
    NSString *_path;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _path = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES).lastObject;
    
    [self setupUI];
}

#pragma mark - Set up user interface
- (void)setupUI{
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"设置";
    
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"fanhuiback"] style:UIBarButtonItemStylePlain target:self action:@selector(popControllerClick:)];
    [leftItem setTintColor:[UIColor lightGrayColor]];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
    [self.view addSubview:tableView];
    tableView.dataSource = self;
    tableView.delegate = self;
    
    [tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:normalCellID];
}

- (void)popControllerClick:(UIBarButtonItem *)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Tabel view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section == 0) {
        return 2;
    }
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:normalCellID forIndexPath:indexPath];
    
    [cell.contentView.subviews enumerateObjectsUsingBlock:^(__kindof UIView * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [obj removeFromSuperview];
    }];
    
    if (indexPath.section == 0 && indexPath.row == 0) {
        cell.textLabel.text = @"关于我们";
        cell.textLabel.font = [UIFont systemFontOfSize:15];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    } else if (indexPath.section == 0 && indexPath.row == 1) {
        
        UILabel *titleLabel = [UILabel cz_labelWithText:@"清除缓存" fontSize:15 color:[UIColor blackColor]];
        [cell.contentView addSubview:titleLabel];
        [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(cell.contentView);
            make.left.equalTo(cell.contentView).offset(14);
        }];
        
        NSString *fileSize = [LBClearCacheTool getCacheSizeWithFilePath:_path];
        UILabel *countLabel = [UILabel cz_labelWithText:fileSize fontSize:13 color:[UIColor lightGrayColor]];
        [cell.contentView addSubview:countLabel];
        [countLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(cell.contentView);
            make.right.equalTo(cell.contentView).offset(-16);
        }];
    } else if (indexPath.section == 1 && indexPath.row == 0) {
        UILabel *titleLabel = [UILabel cz_labelWithText:@"退出当前账号" fontSize:15 color:[UIColor blackColor]];
        [titleLabel sizeToFit];
        titleLabel.center = cell.contentView.center;
        [cell.contentView addSubview:titleLabel];
    }
    return cell;
}

#pragma mark - Tabel view delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0 && indexPath.row == 1) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"确定清除吗？" message:nil preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *cancleAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
        UIAlertAction *OKAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
            if ([LBClearCacheTool clearCacheWithFilePath:_path]) {
                [tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
                [SVProgressHUD setDefaultStyle:SVProgressHUDStyleDark];
                [SVProgressHUD showSuccessWithStatus:@"清除成功"];
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [SVProgressHUD dismiss];
                });
            }
        }];
        
        [alert addAction:cancleAction];
        [alert addAction:OKAction];
        
        [self presentViewController:alert animated:YES completion:nil];
    } else if (indexPath.section == 0 && indexPath.row == 0) {
        LBSettingAboutUsView *settingAboutUsView = [[NSBundle mainBundle] loadNibNamed:@"LBSettingAboutUsView" owner:nil options:nil].lastObject;
        
        UIViewController *viewController = [[UIViewController alloc] init];
        
        UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"fanhuiback"] style:UIBarButtonItemStylePlain target:self action:@selector(popControllerClick:)];
        [leftItem setTintColor:[UIColor lightGrayColor]];
        viewController.navigationItem.leftBarButtonItem = leftItem;
        
        viewController.title = @"关于我们";
        viewController.view.backgroundColor = [UIColor whiteColor];
        settingAboutUsView.frame = viewController.view.bounds;
        [viewController.view addSubview:settingAboutUsView];
        [self.navigationController pushViewController:viewController animated:YES];
    }
    
    if (indexPath.section == 1)
        {
            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
            
            //移除UserDefaults中存储的用户信息
//            [userDefaults removeObjectForKey:@"user"];
//            [userDefaults removeObjectForKey:@"password"];
             [userDefaults removeObjectForKey:@"islogin"];
            
            [userDefaults synchronize];
            
            LoginViewController *vc = [[LoginViewController alloc]initWithNibName:@"LoginViewController" bundle:nil] ;
            //模态展示出登陆页面
            [self presentViewController:vc animated:YES completion:^{
            }];

        
        
        }
    
    
    
}

@end
