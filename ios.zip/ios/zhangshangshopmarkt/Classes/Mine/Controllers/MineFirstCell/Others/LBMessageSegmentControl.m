//
//  LBMessageSegmentControl.m
//  MyTop
//
//  Created by ITdongZi on 16/9/10.
//  Copyright © 2016年 IOS-yangxudong. All rights reserved.
//

#import "LBMessageSegmentControl.h"

@implementation LBMessageSegmentControl

- (void)awakeFromNib{
    [self setupUI];
}

- (void)setupUI{
    
    NSArray *segmentArray = @[@"系统消息",@"用户消息"];
    UISegmentedControl *segmentControl = [[UISegmentedControl alloc]initWithItems:segmentArray];
    segmentControl.selectedSegmentIndex = 0;
    segmentControl.segmentedControlStyle = UISegmentedControlStyleBordered;
    segmentControl.momentary = YES;
    segmentControl.tintColor = [UIColor yellowColor];

}
@end
