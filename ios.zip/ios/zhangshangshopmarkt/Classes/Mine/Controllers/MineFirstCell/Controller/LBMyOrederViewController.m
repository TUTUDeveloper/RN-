//
//  LBMyOrederViewController.m
//  LoveBeen
//
//  Created by ITdongZi on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBMyOrederViewController.h"
#import "LBMainMyOrderCell.h"
#import "LBMyOrderModel.h"
#import "LBAboutOrderController.h"


static NSString *cellID = @"cellID";


@interface LBMyOrederViewController () <LBMainMyOrderCellDelegate>

@end


@implementation LBMyOrederViewController{
    NSArray<LBMyOrderModel *> *_myOrderList;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    
    [self loadData];
    [self setupUI];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
//    self.navigationController.navigationBar.alpha = 1;
//    self.navigationController.navigationBar.translucent = NO;
    
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
}

#pragma mark - Load data
- (void)loadData{
    NSURL *URL = [[NSBundle mainBundle] URLForResource:@"MyOrder.plist" withExtension:nil];
    NSArray<NSDictionary *> *array = [NSArray arrayWithContentsOfURL:URL];
    
    NSMutableArray<LBMyOrderModel *> *arrayM = [NSMutableArray arrayWithCapacity:array.count];
    
    [array enumerateObjectsUsingBlock:^(NSDictionary * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        LBMyOrderModel *myOrderModel = [LBMyOrderModel myOrderModelWithDictionary:obj];
        [arrayM addObject:myOrderModel];
    }];
    
    _myOrderList = [arrayM copy];
}

#pragma mark - Set up user interface
- (void)setupUI{
    self.view.backgroundColor = [UIColor cz_colorWithHex:0XEBEBEB];
    self.tableView.backgroundColor = self.view.backgroundColor;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    self.navigationItem.title = @"我的订单";
    
    //back bar button item
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"fanhuiback"] style:UIBarButtonItemStylePlain target:self action:@selector(popControllerClick:)];
    [leftItem setTintColor:[UIColor lightGrayColor]];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    [self.tableView registerNib:[UINib nibWithNibName:@"LBMainMyOrderCell" bundle:nil] forCellReuseIdentifier:cellID];
}

- (void)popControllerClick:(UIBarButtonItem *)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 7;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    LBMainMyOrderCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID forIndexPath:indexPath];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.myOrderModel = _myOrderList[indexPath.row];
    cell.delegate = self;
    return cell;
}

#pragma mark - Table view delegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 203;
}

#pragma mark - Main my order cell delegate
- (void)mainMyOrderCell:(LBMainMyOrderCell *)mainMyOrderCell didSelectedButton:(UIButton *)sender{
    LBAboutOrderController *aboutOrderController = [[LBAboutOrderController alloc] init];
    [self.navigationController pushViewController:aboutOrderController animated:YES];
}

@end
