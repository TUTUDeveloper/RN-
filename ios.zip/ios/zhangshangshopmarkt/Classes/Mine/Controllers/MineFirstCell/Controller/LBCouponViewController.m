//
//  LBCouponViewController.m
//  LoveBeen
//
//  Created by ITdongZi on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBCouponViewController.h"
#import "Masonry.h"
#import "LBCouponTableViewCell.h"
static NSString *couponCellID = @"couponCellID";

@interface LBCouponViewController ()<UITableViewDelegate,UITableViewDataSource>

@end

@implementation LBCouponViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor greenColor];
    self.navigationItem.title = @"优惠券";
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc]initWithTitle:@"使用规则" style:UIBarButtonItemStylePlain target:self action:@selector(clickSender:)];
    self.navigationItem.rightBarButtonItem = rightItem;
    [rightItem setTintColor:[UIColor lightGrayColor]];
    
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"fanhuiback"] style:UIBarButtonItemStylePlain target:self action:@selector(popControllerClick:)];
    [leftItem setTintColor:[UIColor lightGrayColor]];
    self.navigationItem.leftBarButtonItem = leftItem;

    [self setupUI];
    
}

- (void)setupUI{
    UIView *topView = [[UIView alloc]init];
    topView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:topView];
    [topView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.view);
        make.left.right.equalTo(self.view);
        make.height.mas_equalTo(50);
    }];
    
    UITextField *textFiled = [[UITextField alloc]init];
    textFiled.borderStyle = UITextBorderStyleRoundedRect;
    textFiled.placeholder = @"请输入优惠券号码";
    [topView addSubview:textFiled];
    [textFiled mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(topView).offset(10);
        make.left.equalTo(topView).offset(20);
        make.bottom.equalTo(topView).offset(-10);
        make.width.mas_equalTo(245);
    }];
    
    UIButton *button = [[UIButton alloc]init];
    [button setTitle:@"绑定" forState:UIControlStateNormal];
    [button setBackgroundImage:[UIImage imageNamed:@"fulinormal"] forState:UIControlStateNormal];
    [topView addSubview:button];
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(topView).offset(10);
        make.right.equalTo(topView).offset(-20);
        make.bottom.equalTo(topView).offset(-10);
    }];
    [button addTarget:self action:@selector(promptClick) forControlEvents:UIControlEventTouchUpInside];
    
    UITableView *tableView = [[UITableView alloc]init];
    tableView.delegate = self;
    tableView.dataSource = self;
    [tableView registerNib:[UINib nibWithNibName:@"LBCouponTableViewCell" bundle:nil] forCellReuseIdentifier:couponCellID];
    tableView.rowHeight = 120;
    [self.view addSubview:tableView];
    [tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(topView.mas_bottom);
        make.left.right.equalTo(self.view);
        make.bottom.equalTo(self.view);
    }];
    
}
#pragma mark-绑定按钮点击

//点击绑定按钮提示 输入优惠券号码
- (void)promptClick{
    UIAlertController *alertSheet = [UIAlertController alertControllerWithTitle:@"请输入优惠号码" message:nil preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    
    [alertSheet addAction:action];
    [self presentViewController:alertSheet animated:YES completion:nil];
}
#pragma mark-navbar点击
//使用说明
- (void)clickSender:(UIBarButtonItem *)sender{
    NSLog(@"点击跳转到webVeiw");
}
- (void)popControllerClick:(UIBarButtonItem *)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark-UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 20;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    LBCouponTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:couponCellID forIndexPath:indexPath];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
