//
//  LBMyOrederViewController.h
//  LoveBeen
//
//  Created by ITdongZi on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface LBMyOrederViewController : UITableViewController

@end
