//
//  LBMessageViewController.m
//  LoveBeen
//
//  Created by ITdongZi on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBMessageViewController.h"
#import "LBUserMessageView.h"
#import "LBSystemMessageView.h"

#define SCREEN_W [[UIScreen mainScreen]bounds].size.width
#define SCREEN_H [[UIScreen mainScreen]bounds].size.height
@interface LBMessageViewController ()
@property (strong,nonatomic) LBUserMessageView *userMesView;
@property (strong,nonatomic) LBSystemMessageView *systemMesView;
@end

@implementation LBMessageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    self.view.backgroundColor = [UIColor lightGrayColor];
    [self setupUI];
}
- (void)setupUI{
    
    _systemMesView = [[LBSystemMessageView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_W, SCREEN_H)];
    _userMesView = [[LBUserMessageView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_W, SCREEN_H)];
    _systemMesView.backgroundColor = [UIColor redColor];
    _userMesView.backgroundColor = [UIColor orangeColor];
    _userMesView.hidden = YES;
    [self.view addSubview:_systemMesView];
    [self.view addSubview:self.userMesView];

    
    
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"fanhuiback"] style:UIBarButtonItemStylePlain target:self action:@selector(popControllerClick:)];
    [leftItem setTintColor:[UIColor lightGrayColor]];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    
    UISegmentedControl *segmentControl=[[UISegmentedControl alloc] initWithFrame:CGRectMake(80.0f, 8.0f, 200.0f, 30.0f) ];
    segmentControl.backgroundColor = [UIColor cz_colorWithHex:0xEDC728];
    [segmentControl insertSegmentWithTitle:@"系统消息" atIndex:0 animated:YES];
    [segmentControl insertSegmentWithTitle:@"用户消息" atIndex:1 animated:YES];
    segmentControl.multipleTouchEnabled=NO;
    segmentControl.selectedSegmentIndex = 0;
    segmentControl.momentary = NO;
    
    UIColor *black = [UIColor blackColor];
    NSDictionary *colorAttr = [NSDictionary dictionaryWithObject:black forKey:UITextAttributeTextColor];
    [segmentControl setTitleTextAttributes:colorAttr forState:UIControlStateNormal];
    //    segmentControl.tintColor = [UIColor yellowColor];
    
    [segmentControl addTarget:self action:@selector(respondsToSegemnt:) forControlEvents:UIControlEventValueChanged];
    
    self.navigationItem.titleView = segmentControl;


}
#pragma mark-pop当前控制器
- (void)popControllerClick:(UIBarButtonItem *)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark-点击事件
//分段控制器的点击事件
- (void)respondsToSegemnt:(UISegmentedControl*)sender{
    
    switch (sender.selectedSegmentIndex) {
        case 0:{
            _userMesView.hidden = YES;
            
        }
            break;
        case 1:{
            _userMesView.hidden = NO;
            
        }
        default:
            break;
    }
    
}



@end
