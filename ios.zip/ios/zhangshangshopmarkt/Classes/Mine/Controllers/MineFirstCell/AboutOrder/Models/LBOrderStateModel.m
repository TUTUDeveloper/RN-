//
//  LBOrderStateModel.m
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/10.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBOrderStateModel.h"


@implementation LBOrderStateModel

+ (instancetype)orderStateModelWithDictionary:(NSDictionary *)dictionary{
    LBOrderStateModel *orderStateModel = [[LBOrderStateModel alloc] init];
    [orderStateModel setValuesForKeysWithDictionary:dictionary];
    return orderStateModel;
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}

@end
