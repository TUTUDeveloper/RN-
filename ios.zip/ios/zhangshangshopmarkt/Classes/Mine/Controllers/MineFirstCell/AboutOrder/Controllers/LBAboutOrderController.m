//
//  LBAboutOrderController.m
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/10.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBAboutOrderController.h"
#import "LBOrderStatusView.h"
#import "LBOrderDetailView.h"


@interface LBAboutOrderController ()

@property (weak,nonatomic) LBOrderStatusView *orderStatusView;
@property (weak,nonatomic) LBOrderDetailView *orderDetailView;

@end


@implementation LBAboutOrderController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setupUI];
    self.tabBarController.tabBar.hidden = YES;
}

#pragma mark - Set up user interface
- (void)setupUI{
    self.view.backgroundColor = [UIColor whiteColor];
    
    //back bar button item
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"fanhuiback"] style:UIBarButtonItemStylePlain target:self action:@selector(popControllerClick:)];
    [leftItem setTintColor:[UIColor lightGrayColor]];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    //complain bar button item
    UIBarButtonItem *complainItem = [[UIBarButtonItem alloc] initWithTitle:@"投诉" style:UIBarButtonItemStylePlain target:nil action:nil];
    [complainItem setTitleTextAttributes:@{NSFontAttributeName : [UIFont systemFontOfSize:15]} forState:UIControlStateNormal];
    [complainItem setTintColor:[UIColor lightGrayColor]];
    self.navigationItem.rightBarButtonItem = complainItem;
    
    //segmented control
    UISegmentedControl *segmentedControl = [[UISegmentedControl alloc] initWithItems:@[@"订单状态",@"订单详情"]];
    [segmentedControl setTintColor:[UIColor cz_baseColor]];
    [segmentedControl setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor blackColor]} forState:UIControlStateSelected];
    [segmentedControl setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor grayColor]} forState:UIControlStateNormal];
    segmentedControl.selectedSegmentIndex = 0;
    self.navigationItem.titleView = segmentedControl;
    [segmentedControl addTarget:self action:@selector(segmentedControlValueChange:) forControlEvents:UIControlEventValueChanged];
    
    //order status view
    LBOrderStatusView *orderStatusView = [[LBOrderStatusView alloc] initWithFrame:self.view.bounds];
    orderStatusView.hidden = NO;
    [self.view addSubview:orderStatusView];
    self.orderStatusView = orderStatusView;
    
    //order detail view
    LBOrderDetailView *orderDetailView = [[LBOrderDetailView alloc] initWithFrame:self.view.bounds];
    orderDetailView.hidden = YES;
    [self.view addSubview:orderDetailView];
    self.orderDetailView = orderDetailView;
    
//    buttom view
    UIView *buttomDeleteView = [[UIView alloc] init];
    [self.view addSubview:buttomDeleteView];
    buttomDeleteView.backgroundColor = [UIColor whiteColor];
    
    UIView *lineView = [[UIView alloc] init];
    [buttomDeleteView addSubview:lineView];
    lineView.backgroundColor = [UIColor blackColor];
    
    UIButton *deleteButton = [[UIButton alloc] init];
    [buttomDeleteView addSubview:deleteButton];
    [deleteButton setTitle:@"删除订单" forState:UIControlStateNormal];
    [deleteButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    deleteButton.titleLabel.font = [UIFont systemFontOfSize:13];
    [deleteButton setBackgroundImage:[UIImage imageNamed:@"fulinormal"] forState:UIControlStateNormal];
    
    [buttomDeleteView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.bottom.right.equalTo(self.view);
        make.height.mas_equalTo(49);
    }];
    
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.right.equalTo(buttomDeleteView);
        make.height.mas_equalTo(1);
    }];
    
    [deleteButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(buttomDeleteView).offset(-8);
        make.top.equalTo(buttomDeleteView).offset(8);
        make.bottom.equalTo(buttomDeleteView).offset(-8);
        make.width.mas_equalTo(100);
    }];
}

- (void)popControllerClick:(UIBarButtonItem *)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)segmentedControlValueChange:(UISegmentedControl *)sender{
    self.orderDetailView.hidden = !self.orderDetailView.hidden;
    self.orderStatusView.hidden = !self.orderStatusView.hidden;
}

@end
