//
//  LBOrderDetailFourthCell.h
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/11.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LBOrderDetailFourthCell : UITableViewCell

@end
