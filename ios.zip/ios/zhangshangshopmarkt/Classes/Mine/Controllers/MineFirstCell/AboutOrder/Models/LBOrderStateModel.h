//
//  LBOrderStateModel.h
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/10.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface LBOrderStateModel : NSObject

@property (copy,nonatomic) NSString *time;
@property (assign,nonatomic) BOOL circulerMark;
@property (copy,nonatomic) NSString *des;
@property (copy,nonatomic) NSString *status;

+ (instancetype)orderStateModelWithDictionary:(NSDictionary *)dictionary;

@end
