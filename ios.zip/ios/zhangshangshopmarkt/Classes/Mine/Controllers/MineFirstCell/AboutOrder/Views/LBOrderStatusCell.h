//
//  LBOrderStatusCell.h
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/10.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>


@class LBOrderStateModel;


@interface LBOrderStatusCell : UITableViewCell

@property (strong,nonatomic) LBOrderStateModel *orderStateModel;
@property (assign,nonatomic) NSInteger curretnRowNum;
@property (assign,nonatomic) NSInteger totalRowNum;

@end
