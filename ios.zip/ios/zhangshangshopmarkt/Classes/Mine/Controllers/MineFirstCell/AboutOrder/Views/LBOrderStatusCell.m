//
//  LBOrderStatusCell.m
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/10.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBOrderStatusCell.h"
#import "LBOrderStateModel.h"
#import "Masonry.h"


@interface LBOrderStatusCell ()

@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UIButton *circulerMarkButton;
@property (weak, nonatomic) IBOutlet UILabel *desLabel;
@property (weak, nonatomic) IBOutlet UIView *verticalLine;
@property (weak, nonatomic) IBOutlet UILabel *statusLabel;
@property (weak, nonatomic) IBOutlet UIView *bottomLineView;

@end

@implementation LBOrderStatusCell

- (void)setOrderStateModel:(LBOrderStateModel *)orderStateModel{
    _orderStateModel = orderStateModel;
    
    self.timeLabel.text = orderStateModel.time;
    self.desLabel.text = orderStateModel.des;
    self.statusLabel.text = orderStateModel.status;
    
    if (orderStateModel.circulerMark) {
        self.circulerMarkButton.selected = YES;
    } else {
        self.circulerMarkButton.selected = NO;
    }
}

- (void)setCurretnRowNum:(NSInteger)curretnRowNum{
    _curretnRowNum = curretnRowNum;
    
    if (curretnRowNum == 0) {
        [self.verticalLine removeFromSuperview];
        
        UIView *verticalView = [[UIView alloc] init];
        verticalView.backgroundColor = [UIColor lightGrayColor];
        [self.contentView addSubview:verticalView];
        
        [verticalView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.mas_equalTo(2);
            make.centerX.equalTo(self.circulerMarkButton);
            make.top.equalTo(self.circulerMarkButton.mas_bottom);
            make.bottom.equalTo(self.contentView);
        }];
    } else if (curretnRowNum == self.totalRowNum - 1) {
        [self.verticalLine removeFromSuperview];
        
        UIView *verticalView = [[UIView alloc] init];
        verticalView.backgroundColor = [UIColor lightGrayColor];
        [self.contentView addSubview:verticalView];
        
        [verticalView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.mas_equalTo(2);
            make.centerX.equalTo(self.circulerMarkButton);
            make.top.equalTo(self.contentView);
            make.bottom.equalTo(self.circulerMarkButton.mas_top);
        }];
        
        [self.bottomLineView removeFromSuperview];
    }
}

@end
