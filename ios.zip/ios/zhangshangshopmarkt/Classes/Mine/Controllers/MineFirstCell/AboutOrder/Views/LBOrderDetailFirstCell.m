//
//  LBOrderDetailFirstCell.m
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/10.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBOrderDetailFirstCell.h"


@interface LBOrderDetailFirstCell ()
@property (weak, nonatomic) IBOutlet UILabel *orderNumLabel;
@property (weak, nonatomic) IBOutlet UILabel *goodsNumLabel;
@property (weak, nonatomic) IBOutlet UILabel *orderTimeLabel;
@property (weak, nonatomic) IBOutlet UILabel *distributeTimeLabel;
@property (weak, nonatomic) IBOutlet UILabel *distributeModeLabel;
@property (weak, nonatomic) IBOutlet UILabel *payModelLabel;
@property (weak, nonatomic) IBOutlet UILabel *remarksLabel;


@end


@implementation LBOrderDetailFirstCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
