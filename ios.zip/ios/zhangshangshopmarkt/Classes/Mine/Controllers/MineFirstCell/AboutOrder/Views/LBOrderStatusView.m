//
//  LBOrderStatusView.m
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/10.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBOrderStatusView.h"
#import "LBOrderStatusCell.h"
#import "LBOrderStateModel.h"


static NSString *cellID = @"cellID";


@interface LBOrderStatusView () <UITableViewDataSource,UITableViewDelegate>

@end


@implementation LBOrderStatusView{
    NSArray<LBOrderStateModel *> *_orderStateList;
}

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self loadData];
        [self setupUI];
    }
    return self;
}

#pragma mark - Load data
- (void)loadData{
    NSURL *URL = [[NSBundle mainBundle] URLForResource:@"orderStatus.plist" withExtension:nil];
    NSArray<NSDictionary *> *array = [NSArray arrayWithContentsOfURL:URL];
    
    NSMutableArray<LBOrderStateModel *> *arrayM = [NSMutableArray arrayWithCapacity:array.count];
    
    [array enumerateObjectsUsingBlock:^(NSDictionary * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        LBOrderStateModel *orderStateModel = [LBOrderStateModel orderStateModelWithDictionary:obj];
        [arrayM addObject:orderStateModel];
    }];
    
    _orderStateList = [arrayM copy];
}

#pragma mark - Set up user interface
- (void)setupUI{
    self.backgroundColor = [UIColor whiteColor];
    
    UITableView *tabelView = [[UITableView alloc] initWithFrame:self.bounds style:UITableViewStylePlain];
    [self addSubview:tabelView];
    tabelView.dataSource = self;
    tabelView.delegate = self;
    tabelView.estimatedRowHeight = 74;
    tabelView.rowHeight = UITableViewAutomaticDimension;
    tabelView.tableFooterView = [[UIView alloc] init];
    [tabelView registerNib:[UINib nibWithNibName:@"LBOrderStatusCell" bundle:nil] forCellReuseIdentifier:cellID];
}

#pragma mark - Tabel view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 5;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    LBOrderStatusCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID forIndexPath:indexPath];
    cell.orderStateModel = _orderStateList[indexPath.row];
    cell.totalRowNum = _orderStateList.count;
    cell.curretnRowNum = indexPath.row;
    return cell;
}

#pragma mark - Tabel view delegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 74;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

@end
