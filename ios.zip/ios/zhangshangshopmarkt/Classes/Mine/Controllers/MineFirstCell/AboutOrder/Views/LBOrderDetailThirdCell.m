//
//  LBOrderDetailThirdCell.m
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/11.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBOrderDetailThirdCell.h"


@interface LBOrderDetailThirdCell ()
@property (weak, nonatomic) IBOutlet UILabel *productNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *productCountLabel;
@property (weak, nonatomic) IBOutlet UILabel *productPriceLabel;

@end


@implementation LBOrderDetailThirdCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
