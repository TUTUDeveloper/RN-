//
//  LBOrderDetailView.m
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/10.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBOrderDetailView.h"
#import "LBOrderDetailFirstCell.h"
#import "LBOrderDetailSecondCell.h"
#import "LBOrderDetailThirdCell.h"
#import "LBOrderDetailFourthCell.h"
#import "LBOrderDetailFifthCell.h"


static NSString *normalCellID = @"normalCellID";
static NSString *firstCellID = @"firstCellID";
static NSString *secondCellID = @"secondCellID";
static NSString *thirdCellID = @"thirdCellID";
static NSString *fourthCellID = @"fourthCellID";
static NSString *fifthCellID = @"fifthCellID";


@interface LBOrderDetailView () <UITableViewDataSource,UITableViewDelegate>

@end


@implementation LBOrderDetailView

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self setupUI];
    }
    return self;
}

#pragma mark - Set up user interface
- (void)setupUI{
    self.backgroundColor = [UIColor whiteColor];
    
    UITableView *tabelView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.bounds.size.width, self.bounds.size.height - 49 - 44 - 22) style:UITableViewStyleGrouped];
    [self addSubview:tabelView];
    tabelView.dataSource = self;
    tabelView.delegate = self;
    tabelView.showsVerticalScrollIndicator = NO;
    tabelView.showsHorizontalScrollIndicator = NO;
    
    [tabelView registerClass:[UITableViewCell class] forCellReuseIdentifier:normalCellID];
    [tabelView registerNib:[UINib nibWithNibName:@"LBOrderDetailFirstCell" bundle:nil] forCellReuseIdentifier:firstCellID];
    [tabelView registerNib:[UINib nibWithNibName:@"LBOrderDetailSecondCell" bundle:nil] forCellReuseIdentifier:secondCellID];
    [tabelView registerNib:[UINib nibWithNibName:@"LBOrderDetailThirdCell" bundle:nil] forCellReuseIdentifier:thirdCellID];
    [tabelView registerNib:[UINib nibWithNibName:@"LBOrderDetailFourthCell" bundle:nil] forCellReuseIdentifier:fourthCellID];
    [tabelView registerNib:[UINib nibWithNibName:@"LBOrderDetailFifthCell" bundle:nil] forCellReuseIdentifier:fifthCellID];
}

#pragma mark - Table view data source
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 4;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section == 2) {
        return 7;
    }
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        LBOrderDetailFirstCell *cell = [tableView dequeueReusableCellWithIdentifier:firstCellID forIndexPath:indexPath];
        return cell;
    } else if (indexPath.section == 1) {
        LBOrderDetailSecondCell *cell = [tableView dequeueReusableCellWithIdentifier:secondCellID forIndexPath:indexPath];
        return cell;
    } else if (indexPath.section == 2 && indexPath.row > 0 && indexPath.row < 6) {
        LBOrderDetailThirdCell *cell = [tableView dequeueReusableCellWithIdentifier:thirdCellID forIndexPath:indexPath];
        return cell;
    } else if (indexPath.section == 2 && indexPath.row == 0){
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:normalCellID forIndexPath:indexPath];
        cell.textLabel.text = @"费用明细";
        cell.textLabel.font = [UIFont systemFontOfSize:11];
        cell.textLabel.textColor = [UIColor lightGrayColor];
        return cell;
    } else if (indexPath.section == 2 && indexPath.row == 6) {
        LBOrderDetailFourthCell *cell = [tableView dequeueReusableCellWithIdentifier:fourthCellID forIndexPath:indexPath];
        return cell;
    } else if (indexPath.section == 3) {
        LBOrderDetailFifthCell *cell = [tableView dequeueReusableCellWithIdentifier:fifthCellID forIndexPath:indexPath];
        return cell;
    }
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:normalCellID forIndexPath:indexPath];
    cell.backgroundColor = [UIColor redColor];
    return cell;
}

#pragma mark - Table view delegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        return 176;
    } else if (indexPath.section == 1) {
        return 100;
    } else if (indexPath.section == 2 && indexPath.row == 0){
        return 30;
    } else if (indexPath.section == 2 && indexPath.row == 6) {
        return 116;
    } else if (indexPath.section == 3) {
        return 114;
    }
    return 40;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 10;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0.1;
}

@end
