//
//  LBOrderDetailSecondCell.m
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/11.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBOrderDetailSecondCell.h"


@interface LBOrderDetailSecondCell ()
@property (weak, nonatomic) IBOutlet UILabel *consigneeLabel;
@property (weak, nonatomic) IBOutlet UILabel *receiptAddressLabel;
@property (weak, nonatomic) IBOutlet UILabel *dstributionShopLabel;
@property (weak, nonatomic) IBOutlet UILabel *phoneNumLabel;

@end


@implementation LBOrderDetailSecondCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
