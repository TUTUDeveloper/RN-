//
//  LBOrderDetailFifthCell.m
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/11.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBOrderDetailFifthCell.h"


@interface LBOrderDetailFifthCell ()
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *starsImageView;
@property (weak, nonatomic) IBOutlet UILabel *commetnLabel;

@end

@implementation LBOrderDetailFifthCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
