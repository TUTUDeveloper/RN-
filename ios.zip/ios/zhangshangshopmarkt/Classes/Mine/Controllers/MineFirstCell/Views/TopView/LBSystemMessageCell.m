//
//  LBSystemMessageCell.m
//  MyTop
//
//  Created by ITdongZi on 16/9/10.
//  Copyright © 2016年 IOS-yangxudong. All rights reserved.
//

#import "LBSystemMessageCell.h"

@interface LBSystemMessageCell ()

@property (weak, nonatomic) IBOutlet UILabel *contentLabel;

@end

@implementation LBSystemMessageCell

- (instancetype)initWithFrame:(CGRect)frame{
    
    if (self = [super initWithFrame:frame]) {
        [self setupUI];
    }
    return self;
}
- (void)setupUI{
    
}
- (void)setModel:(LBSystemMessageModel *)model{
    _model = model;
    self.contentLabel.numberOfLines = 2;
    self.contentLabel.text = model.content;
}
- (IBAction)xianshiAll:(UIButton *)sender {
    
    if (sender.tag == 10) {
        self.contentLabel.numberOfLines = 0;
        [self.delegate loadCell:self];
        
        sender.tag = 20;
    }
    else if (sender.tag == 20) {
        self.contentLabel.numberOfLines = 2;
        
        sender.tag = 10;
    }
    
    
    
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
