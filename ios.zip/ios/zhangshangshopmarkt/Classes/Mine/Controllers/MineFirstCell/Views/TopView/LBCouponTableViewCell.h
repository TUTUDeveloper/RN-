//
//  LBCouponTableViewCell.h
//  MyTop
//
//  Created by ITdongZi on 16/9/9.
//  Copyright © 2016年 IOS-yangxudong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LBCouponTableViewCell : UITableViewCell

@end
