//
//  LBMainMyOrderCell.m
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBMainMyOrderCell.h"
#import "LBMyOrderModel.h"


@interface LBMainMyOrderCell ()

@property (weak, nonatomic) IBOutlet UILabel *dateLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *imageViewList;
@property (weak, nonatomic) IBOutlet UIImageView *moreImageView;
@property (weak, nonatomic) IBOutlet UIImageView *detailImageView;
@property (weak, nonatomic) IBOutlet UILabel *priceLabel;
@property (weak, nonatomic) IBOutlet UILabel *countLabel;

@end


@implementation LBMainMyOrderCell

- (void)setMyOrderModel:(LBMyOrderModel *)myOrderModel{
    _myOrderModel = myOrderModel;
    
    self.dateLabel.text = myOrderModel.date;
    self.timeLabel.text = myOrderModel.time;
    self.priceLabel.text = myOrderModel.price;
    self.countLabel.text = [NSString stringWithFormat:@"共%@件商品",myOrderModel.count];
    
    //初始化imageView
    for (NSInteger i = 0; i < self.imageViewList.count; i ++) {
        UIImageView *imageView = self.imageViewList[i];
        imageView.image = [[UIImage alloc] init];
    }
    
    //为imageView赋值
    if (myOrderModel.count.integerValue > 4) {
        for (NSInteger i = 0; i < 4; i ++) {
            [self setupImageViewWithIndex:i];
            
            self.moreImageView.image = [UIImage imageNamed:@"gengduomore"];
        }
    } else {
        for (NSInteger i = 0; i < myOrderModel.count.integerValue; i ++) {
            [self setupImageViewWithIndex:i];
        }
    }
    if (myOrderModel.count.integerValue > 4) {
        self.moreImageView.image = [UIImage imageNamed:@"gengduomore"];
    }
}

/** 为imageView赋值 */
- (void)setupImageViewWithIndex:(NSInteger)index{
    UIImageView *imageView = self.imageViewList[index];
    switch (index) {
        case 0:
            imageView.image = [UIImage imageNamed:self.myOrderModel.image1];
            break;
        case 1:
            imageView.image = [UIImage imageNamed:self.myOrderModel.image2];
            break;
        case 2:
            imageView.image = [UIImage imageNamed:self.myOrderModel.image3];
            break;
        case 3:
            imageView.image = [UIImage imageNamed:self.myOrderModel.image4];
            break;
        default:
            break;
    }
}
- (IBAction)JumpToAboutOrderView:(UIButton *)sender {
    [self.delegate mainMyOrderCell:self didSelectedButton:sender];
}

@end
