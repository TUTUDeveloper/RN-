//
//  LBMainMyOrderCell.h
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>


@class LBMyOrderModel,LBMainMyOrderCell;


@protocol LBMainMyOrderCellDelegate <NSObject>

- (void)mainMyOrderCell:(LBMainMyOrderCell *)mainMyOrderCell didSelectedButton:(UIButton *)sender;

@end

@interface LBMainMyOrderCell : UITableViewCell

@property (strong,nonatomic) LBMyOrderModel *myOrderModel;
@property (weak,nonatomic) id <LBMainMyOrderCellDelegate> delegate;

@end
