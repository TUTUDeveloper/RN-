//
//  LBSystemMessageView.m
//  MyTop
//
//  Created by ITdongZi on 16/9/10.
//  Copyright © 2016年 IOS-yangxudong. All rights reserved.
//

#import "LBSystemMessageView.h"
#import "Masonry.h"
#import "LBSystemMessageCell.h"

static NSString *systemCellID = @"systemCellID";

@interface LBSystemMessageView ()<UITableViewDelegate,UITableViewDataSource,LBSystemMessageCellDelegate>
@property (weak,nonatomic) UITableView *sysTableView;
@end

@implementation LBSystemMessageView

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self setupUI];
        
    }
    return self;
}

- (void)setupUI{
    self.backgroundColor = [UIColor lightGrayColor];
    UITableView *systemTableView = [[UITableView alloc]initWithFrame:self.bounds style:UITableViewStylePlain];
    systemTableView.dataSource = self;
    systemTableView.delegate = self;
    //    systemTableView.rowHeight = 120;
    //1.设置预估行高
    systemTableView.estimatedRowHeight = 400;
    //2.设置tableView的行高为自动计算
    systemTableView.rowHeight = UITableViewAutomaticDimension;
    self.sysTableView = systemTableView;
    
    [self addSubview:systemTableView];
    [systemTableView registerNib:[UINib nibWithNibName:@"LBSystemMessageView" bundle:nil] forCellReuseIdentifier:systemCellID];
}
#pragma mark-UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 3;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    LBSystemMessageCell *cell = [tableView dequeueReusableCellWithIdentifier:systemCellID forIndexPath:indexPath];
    LBSystemMessageModel *model = [[LBSystemMessageModel alloc]init];
    model.content = @"鲁迅（1881年9月25日－1936年10月19日），原名周樟寿，后改名周树人，字豫山，后改豫才，“鲁迅”是他1918年发表《狂人日记》时所用的笔名，也是他影响最为广泛的笔名，浙江绍兴人。著名文学家、思想家，五四新文化运动的重要参与者，中国现代文学的奠基人。毛泽东曾评价：“鲁迅的方向，就是中华民族新文化的方向。";
    cell.delegate = self;
    cell.model = model;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
- (void)loadCell:(LBSystemMessageCell *)cell{
    //1.设置预估行高
    _sysTableView.estimatedRowHeight = 400;
    //2.设置tableView的行高为自动计算
    _sysTableView.rowHeight = UITableViewAutomaticDimension;
    
    [self.sysTableView reloadInputViews];
}


@end
