//
//  LBSystemMessageCell.h
//  MyTop
//
//  Created by ITdongZi on 16/9/10.
//  Copyright © 2016年 IOS-yangxudong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LBSystemMessageModel.h"
@class LBSystemMessageCell;
@protocol LBSystemMessageCellDelegate <NSObject>

- (void)loadCell:(LBSystemMessageCell *)cell;

@end

@interface LBSystemMessageCell : UITableViewCell
@property (strong,nonatomic) LBSystemMessageModel *model;
@property (weak,nonatomic) id<LBSystemMessageCellDelegate>delegate;
@end
