//
//  LBUserMessageView.m
//  MyTop
//
//  Created by ITdongZi on 16/9/10.
//  Copyright © 2016年 IOS-yangxudong. All rights reserved.
//

#import "LBUserMessageView.h"

@implementation LBUserMessageView

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self setupUI];
    }
    return self;
}
- (void)setupUI{
//    self.backgroundColor = [UIColor lightGrayColor];
    UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 120, 120)];
    imageView.center = self.center;
    imageView.image = [UIImage imageNamed:@"mymessage@3x"];
    [self addSubview:imageView];
    
    UILabel *label = [[UILabel alloc]init];
    label.text = @"~~~并没有什么消息~~~";
    [self addSubview:label];
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(imageView.mas_centerX);
        make.top.equalTo(imageView.mas_bottom).offset(10);
    }];
    
}


@end
