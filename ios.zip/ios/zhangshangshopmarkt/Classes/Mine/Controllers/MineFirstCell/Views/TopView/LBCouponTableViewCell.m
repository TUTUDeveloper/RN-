//
//  LBCouponTableViewCell.m
//  MyTop
//
//  Created by ITdongZi on 16/9/9.
//  Copyright © 2016年 IOS-yangxudong. All rights reserved.
//

#import "LBCouponTableViewCell.h"

@implementation LBCouponTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
