//
//  LBSystemMessageModel.m
//  MyTop
//
//  Created by ITdongZi on 16/9/10.
//  Copyright © 2016年 IOS-yangxudong. All rights reserved.
//

#import "LBSystemMessageModel.h"

@implementation LBSystemMessageModel

@end
