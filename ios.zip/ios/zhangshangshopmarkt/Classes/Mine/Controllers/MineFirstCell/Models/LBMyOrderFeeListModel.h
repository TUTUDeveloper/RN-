//
//  LBMyOrderFeeListModel.h
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/12.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface LBMyOrderFeeListModel : NSObject

/** 费送费 */
@property (copy,nonatomic) NSString *distributionFee;
/** 服务费 */
@property (copy,nonatomic) NSString *serviceFee;
/** 优惠券 */
@property (copy,nonatomic) NSString *couponFee;

+ (instancetype)myOrderFeeListModelWithDictionary:(NSDictionary *)dictionary;

@end
