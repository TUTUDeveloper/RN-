//
//  LBMyOrderFeeListModel.m
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/12.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBMyOrderFeeListModel.h"


@implementation LBMyOrderFeeListModel

+ (instancetype)myOrderFeeListModelWithDictionary:(NSDictionary *)dictionary{
    LBMyOrderFeeListModel *model = [[LBMyOrderFeeListModel alloc] init];
    [model setValuesForKeysWithDictionary:dictionary];
    return model;
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}

@end
