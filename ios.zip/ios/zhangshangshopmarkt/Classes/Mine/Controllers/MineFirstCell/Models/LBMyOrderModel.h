//
//  LBMyOrderModel.h
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/10.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LBMyOrderFeeListModel.h"
#import "LBMyOrderGoodsModel.h"


@interface LBMyOrderModel : NSObject

@property (copy,nonatomic) NSString *date;
@property (copy,nonatomic) NSString *time;
@property (copy,nonatomic) NSString *count;
@property (copy,nonatomic) NSString *price;
@property (copy,nonatomic) NSString *image1;
@property (copy,nonatomic) NSString *image2;
@property (copy,nonatomic) NSString *image3;
@property (copy,nonatomic) NSString *image4;

/** 订单号 */
@property (copy,nonatomic) NSString *order_no;
/** 收货人 */
@property (copy,nonatomic) NSString *accept_name;
/** 联系电话 */
@property (copy,nonatomic) NSString *telphone;
/** 收货地址 */
@property (copy,nonatomic) NSString *address;
/** 我的评价 */
@property (copy,nonatomic) NSString *comment;
/** 实付 */
@property (copy,nonatomic) NSString *real_amount;
/** 支付时间 */
@property (copy,nonatomic) NSString *pay_time;
/** 送达时间 */
@property (copy,nonatomic) NSString *send_time;
/** 下单时间 */
@property (copy,nonatomic) NSString *create_time;
/** 完成时间 */
@property (copy,nonatomic) NSString *completion_time;
/** 配送时间 */
@property (copy,nonatomic) NSString *accept_time;
/** 收货码 */
@property (copy,nonatomic) NSString *checknum;
/** 配送店铺 */
@property (copy,nonatomic) NSString *dealer_name;
/** 评价星级 */
@property (assign,nonatomic) NSInteger *star;
/** 购买数量 */
@property (assign,nonatomic) NSInteger *buy_num;
/** 其他费用 */
@property (strong,nonatomic) LBMyOrderFeeListModel *fee_list;
/** 商品列表 */
@property (strong,nonatomic) NSArray<LBMyOrderGoodsModel *> *order_goods;

+ (instancetype) myOrderModelWithDictionary:(NSDictionary *)dictionary;

@end
