//
//  LBMyOrderGoodsModel.h
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/12.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface LBMyOrderGoodsModel : NSObject

/** 单价 */
@property (copy,nonatomic) NSString *real_price;
/** 数量 */
@property (copy,nonatomic) NSString *goods_nums;
/** 名称 */
@property (copy,nonatomic) NSString *name;
/** 图片 */
@property (copy,nonatomic) NSString *img;

+ (instancetype)myOrderGoodsModelWithDictionary:(NSDictionary *)dictionary;

@end
