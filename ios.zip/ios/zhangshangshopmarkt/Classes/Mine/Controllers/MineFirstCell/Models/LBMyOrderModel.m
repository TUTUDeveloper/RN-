//
//  LBMyOrderModel.m
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/10.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBMyOrderModel.h"


@implementation LBMyOrderModel

+ (instancetype) myOrderModelWithDictionary:(NSDictionary *)dictionary{
    LBMyOrderModel *myOrderModel = [[LBMyOrderModel alloc] init];
    [myOrderModel setValuesForKeysWithDictionary:dictionary];
    return myOrderModel;
}

- (void)setValue:(id)value forKey:(NSString *)key{
    [super setValue:value forKey:key];
    
    if ([key isEqualToString:@"fee_list"]) {
        NSArray<NSDictionary *> *array = value;
        
        LBMyOrderFeeListModel *model = [[LBMyOrderFeeListModel alloc] init];
        model.distributionFee = array[0][@"text"];
        model.serviceFee = array[1][@"text"];
        model.couponFee = array[2][@"text"];
        
        [super setValue:model forKey:key];
    }
    
    if ([key isEqualToString:@"order_goods"]) {
        NSArray<NSDictionary *> *array = value;
        
        NSMutableArray<LBMyOrderGoodsModel *> *arrayM = [NSMutableArray arrayWithCapacity:array.count];
        
        [array enumerateObjectsUsingBlock:^(NSDictionary * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            LBMyOrderGoodsModel *model = [LBMyOrderGoodsModel myOrderGoodsModelWithDictionary:obj];
            [arrayM addObject:model];
        }];
        
        [super setValue:arrayM forKey:key];
    }
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}

@end
