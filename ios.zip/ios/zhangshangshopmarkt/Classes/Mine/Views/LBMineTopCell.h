//
//  LBMineTopCell.h
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/8.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>


@class LBMineTopCell;


@protocol LBMineTopCellDelegate <NSObject>

- (void)mineTopCell:(LBMineTopCell *)mineTopCell didClickButton:(UIButton *)sender;

@end


@interface LBMineTopCell : UITableViewCell

@property (weak,nonatomic) id <LBMineTopCellDelegate> delegate;

@end
