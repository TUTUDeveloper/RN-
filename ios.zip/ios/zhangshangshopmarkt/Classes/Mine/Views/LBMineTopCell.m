//
//  LBMineTopCell.m
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/8.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBMineTopCell.h"


@implementation LBMineTopCell

//我的订单点击事件
- (IBAction)MyOrderButton:(UIButton *)sender {
    [self.delegate mineTopCell:self didClickButton:sender];
}

//优惠券点击事件
- (IBAction)CouponButton:(UIButton *)sender {
    [self.delegate mineTopCell:self didClickButton:sender];
}

//我的消息点击事件
- (IBAction)MyMessageButton:(UIButton *)sender {
    [self.delegate mineTopCell:self didClickButton:sender];
}

@end
