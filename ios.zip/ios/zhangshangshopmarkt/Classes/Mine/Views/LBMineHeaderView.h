//
//  LBMineHeaderView.h
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/11.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>


@class LBMineHeaderView;


@protocol LBMineHeaderViewDelegate <NSObject>

- (void)mineHeaderView:(LBMineHeaderView *)mineHeaderView settingButtonClick:(UIButton *)sender;

@end

@interface LBMineHeaderView : UIView

@property (weak,nonatomic) id <LBMineHeaderViewDelegate> delegate;

@end
