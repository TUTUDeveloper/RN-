//
//  LBMineHeaderView.m
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/11.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBMineHeaderView.h"


@interface LBMineHeaderView ()

@property (weak, nonatomic) IBOutlet UIImageView *iconImageView;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;

@end


@implementation LBMineHeaderView

- (IBAction)settingButtonClick:(UIButton *)sender {
    [self.delegate mineHeaderView:self settingButtonClick:sender];
}

@end
