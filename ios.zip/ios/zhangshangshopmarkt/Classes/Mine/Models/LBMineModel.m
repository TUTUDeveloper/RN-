//
//  LBMineModel.m
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/8.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBMineModel.h"


@implementation LBMineModel

+ (instancetype)mineModelWithDictionary:(NSDictionary *)dictionary{
    LBMineModel *mineModel = [[LBMineModel alloc] init];
    [mineModel setValuesForKeysWithDictionary:dictionary];
    return mineModel;
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}

- (NSString *)description{
    return self.title;
}

@end
