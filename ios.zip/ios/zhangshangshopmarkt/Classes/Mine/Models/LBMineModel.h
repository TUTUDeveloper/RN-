//
//  LBMineModel.h
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/8.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface LBMineModel : NSObject

@property (copy,nonatomic) NSString *title;
@property (copy,nonatomic) NSString *icon;

+ (instancetype)mineModelWithDictionary:(NSDictionary *)dictionary;

@end
