//
//  LBCartController.h
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/7.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

@class shoppingCartModel;
@interface LBCartController :UIViewController

//接收购物车的商品数据
@property(nonatomic,strong)NSArray<shoppingCartModel *> * ModelGroup;

@property(nonatomic,strong)shoppingCartModel * modelCarEndModel;

@end
