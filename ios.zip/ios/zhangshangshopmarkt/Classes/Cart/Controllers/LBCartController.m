//
//  LBCartController.m
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/7.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBCartController.h"
#import "Masonry.h"
#import "SVProgressHUD.h"
#import "LBCarHeadView.h"
#import "LBCarTableViewCell.h"
#import "LBZhiFuTableViewController.h"
#import "shoppingCartManager.h"



static NSString *celled = @"celled";



@interface LBCartController ()<UITableViewDataSource,UITableViewDelegate,LBCarTableViewCellDelegate>

@end


@implementation LBCartController
{

    UILabel * _moneylabel;
    UITableView * _tableview;
  LBCarHeadView * _CarHeadview;
}
- (void)viewDidLoad {
    
    _moneylabel = [[UILabel alloc]init];
    
    [super viewDidLoad];
   self.title=@"购物车";

    [self loadData];
    [self setupUI];
    //隐藏tabbar
//    self.tabBarController.tabBar .hidden =YES;

//    UIBarButtonItem * item = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"fanhuiback"] style: UIBarButtonItemStylePlain target:self action:@selector(PopBack:)];
//    self.navigationItem.leftBarButtonItem = item;

}
////POP跳回去
//-(void)PopBack:(UINavigationController*)controller
//{
//  
//    
//    [self.navigationController  popViewControllerAnimated:YES];
//}
-(void)viewDidAppear:(BOOL)animated
{

    //MARK:设置最开始弹窗
    [SVProgressHUD  showWithStatus:@"正在加载网络数据"];
    
    [self performSelector:@selector(dismiss) withObject:nil afterDelay:1];

}

#pragma mark - Load data
- (void)loadData{
    self.ModelGroup = [[shoppingCartManager sharedShoppingCartManager] getShoppingCartTotalList];
}

#pragma mark - Set up user interface
- (void)setupUI
{
 
    
//    self.view.backgroundColor = [UIColor whiteColor];
    //MARK:判断购物车是否为空
    if ([[shoppingCartManager sharedShoppingCartManager] getShoppingCartTotalList].count==0)
    {
        self.view=[self getKongview];
        return;
    }
    

    //MARK:设置有数据的购物车视图
    UITableView * tableview = [[UITableView alloc]init];
    tableview.tableFooterView = [[UIView alloc] init];
    _tableview = tableview;
    [self.view addSubview:tableview];
    tableview.frame = CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height - 49 - 44 - 22);
    
    
    [tableview registerNib:[UINib nibWithNibName:@"LBCarTableViewCell" bundle:nil] forCellReuseIdentifier:celled];
//    [tableview mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.edges.equalTo(self.view);
//    }];

    
    LBCarHeadView * carHeadView = [[[NSBundle mainBundle]loadNibNamed:@"LBCarHeadView" owner:nil options:nil] lastObject];
    carHeadView.frame=CGRectMake(0, 0, self.view.bounds.size.width, 280);
    tableview.tableHeaderView = carHeadView;
  _CarHeadview = carHeadView;
  
    tableview.backgroundColor= [UIColor cz_colorWithHex:0XEBEBEB];
    tableview.delegate=self;
    tableview.dataSource=self;
    
//    MARK:footview
    
    
    
    
#pragma mark:tableview的footview
//    购物车底部uiview
    UIView * footview  = [[UIView alloc]init];
    [self.view addSubview:footview];
    footview.backgroundColor = [UIColor whiteColor];
    
    [footview mas_makeConstraints:^(MASConstraintMaker *make) {
       
        make.left.bottom.right.equalTo(self.view);
        
//        make.bottom.mas_equalTo(self.view).offset(-50);
        make.height.mas_equalTo(50);
    }];
//    footview.frame = CGRectMake(0,0 , self.view.bounds.size.width, 45);
    //价格label
   
    [_moneylabel setTextColor:[UIColor redColor]];
    
    
    
    CGFloat zongjia = [[shoppingCartManager sharedShoppingCartManager]getShoppingCartTotalPrice];
    
    _moneylabel.text = [NSString stringWithFormat:@"¥%.1f",zongjia];
    
    
    
    [footview addSubview:_moneylabel];
    
    [_moneylabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.equalTo(footview).offset(23);
        
    }];
    
    UIButton * ZhiFubutton = [[UIButton alloc]init];
    [ZhiFubutton  setTitle:@"选好了" forState:UIControlStateNormal];
    
    
    
    ZhiFubutton.backgroundColor = [UIColor cz_baseColor];
    
    [footview addSubview:ZhiFubutton];
    
    [ZhiFubutton mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.bottom.top.right.equalTo(footview);
    }];
    
//    tableview.tableFooterView = footview;
    [ZhiFubutton addTarget:self action:@selector(jumpZhiFu) forControlEvents:UIControlEventTouchUpInside];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapView:)];
    
//    tap.numberOfTapsRequired = 2;
//    //设置手指字数
//    tap.numberOfTouchesRequired = 2;
    
    //别忘了添加到testView上
    [_tableview addGestureRecognizer:tap];
    
}

-(void)tapView:(UITapGestureRecognizer *)sender{
    
    [_tableview endEditing:YES];
    
}
    
    
  
#pragma mark:按钮点击方法
-(void)jumpZhiFu
{
  if(_CarHeadview.NameTF.text.length==0||_CarHeadview.PhoneTF.text.length==0||_CarHeadview.AdressTF.text.length==0)
  {
  
    [SVProgressHUD showErrorWithStatus:@"请输入您的收货信息！"];
    
  }else
  {LBZhiFuTableViewController * zhifuTVC=[[LBZhiFuTableViewController alloc]init];
    
    [self.navigationController pushViewController:zhifuTVC animated:YES];
  }
  
  
  
  



}
#pragma mark:tableview的datasouse的方法
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
//    __block NSInteger num = 0;
//    [self.ModelGroup enumerateObjectsUsingBlock:^(shoppingCartModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
//        if (obj.orderCount != 0) {
//            num++;
//        }
//    }];
    return [[shoppingCartManager sharedShoppingCartManager] getShoppingCartTotalList].count;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    
    shoppingCartModel *model = [[shoppingCartManager sharedShoppingCartManager] getShoppingCartTotalList][indexPath.row];
//    for (shoppingCartModel *obj in self.ModelGroup) {
//        if (obj.orderCount != 0) {
    
            
            LBCarTableViewCell * cell = [tableView  dequeueReusableCellWithIdentifier:celled forIndexPath:indexPath];
    
  
            cell.model = model;
            //设置代理
            cell.delegate=self;
            

        return cell;
//    }
}



//MARK:实现代理方法
-(void)LBCarTableViewCell:(LBCarTableViewCell *)CarTableViewCell Delegatewithzongjia:(CGFloat)zongjia{
//    NSLog(@"%@",[[shoppingCartManager sharedShoppingCartManager] getShoppingCartTotalList]);
    
   [_tableview reloadData];
_moneylabel.text = [NSString stringWithFormat:@"¥%.1f",zongjia];
    if ([[shoppingCartManager sharedShoppingCartManager] getShoppingCartTotalList].count==0) {
        [self dismissViewControllerAnimated:YES completion:nil];
    }
 
    

}
//延迟时间
-(void)dismiss
{
    [SVProgressHUD  dismiss];
}
//MARK:空购物车的视图
-(UIView*)getKongview
{
    
//    self.view.backgroundColor= [UIColor  whiteColor];
    //购物车
    UIImageView * imageview = [[UIImageView alloc]initWithImage:[UIImage  imageNamed:@"v1_kongcar"]];
    [self.view addSubview:imageview]; 
    
    [imageview mas_makeConstraints:^(MASConstraintMaker *make)
     {
         make.top.equalTo(self.view).offset(100);
         make.centerX.equalTo(self.view);
         
     }];
    [imageview sizeToFit];
    //label
    UILabel * label = [[UILabel alloc]init];
    label.text = @"亲爱的用户，你的购物车空空如也！快去挑点好吃的吧.";
    label.textColor = [UIColor redColor];
    label.numberOfLines = 0;
    [self.view addSubview:label];
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(self.view);
        make.width.mas_equalTo(300);
    }];
    
    //button
    UIButton * button = [[UIButton alloc]init];
    [self.view addSubview:button];
    [button setTitle:@"逛街了" forState:UIControlStateNormal ];
    [button setTitleColor:[UIColor yellowColor] forState:UIControlStateSelected];
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(label.mas_bottom).offset(30);
        
        make.centerX.equalTo(self.view);
    }];
    
    [button addTarget:self action:@selector(clickBotton) forControlEvents:UIControlEventTouchUpInside];
    
    return self.view;

}
#pragma mark:button点击事件
-(void)clickBotton
{

    [self.navigationController dismissViewControllerAnimated:YES completion:nil];


}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}



@end
