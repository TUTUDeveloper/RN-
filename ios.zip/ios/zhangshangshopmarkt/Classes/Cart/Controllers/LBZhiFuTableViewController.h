//
//  LBZhiFuTableViewController.h
//  LoveBeen
//
//  Created by mac on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>
@class shoppingCartModel;
@interface LBZhiFuTableViewController : UIViewController
//接收购物车的商品数据
@property(nonatomic,strong)NSArray * ModelGroup;

@property(nonatomic,strong)shoppingCartModel * modelZhifuModel;
@end
