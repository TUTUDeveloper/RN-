          //
//  LBZhiFuTableViewController.m
//  LoveBeen
//
//  Created by mac on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBZhiFuTableViewController.h"
#import "LBCaiPinModelTableViewCell.h"
#import "LBENDTableViewCell.h"
#import "SVProgressHUD.h"
#import "shoppingCartManager.h"


@interface LBZhiFuTableViewController ()<UITableViewDataSource,UITableViewDelegate>

@end

@implementation LBZhiFuTableViewController
{

    NSArray<UIButton*> * _bUttonGroup;
    
    UIButton * _SelectedButton;
}
- (instancetype)init
{
    
    
    if (self= [super init])
    {
        [self setupui];
    }
    return self;
}


#pragma mark:---搭建支付界面tableview的footview
-(void)setupui
{
    UIView * footview  = [[UIView alloc]init];
    [self.view addSubview:footview];
    footview.backgroundColor = [UIColor whiteColor];
    
    [footview mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.equalTo(self.view);
        make.height.mas_equalTo(60);
    }];
//    footview.frame = CGRectMake(0, 0, self.view.bounds.size.width, 45);
    //需要支付的费用label
    UILabel * moneylabel = [[UILabel alloc]init];
    [moneylabel setTextColor:[UIColor redColor]];
    
    CGFloat zongjia=   [[shoppingCartManager  sharedShoppingCartManager]getShoppingCartTotalPrice];
    
    [moneylabel  setText:[NSString stringWithFormat:@"¥%.1f",zongjia]];
    
    [footview addSubview:moneylabel];
    
    [moneylabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.equalTo(footview).offset(23);
        
    }];
    
    UIButton * ZhiFubutton = [[UIButton alloc]init];
    [ZhiFubutton  setTitle:@"支付" forState:UIControlStateNormal];
    
    [ZhiFubutton addTarget:self action:@selector(zhifu) forControlEvents:UIControlEventTouchUpInside];
    
    ZhiFubutton.backgroundColor = [UIColor cz_baseColor];
    
    [footview addSubview:ZhiFubutton];
    
    [ZhiFubutton mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.width.mas_equalTo(60);
        make.bottom.top.right.equalTo(footview);
    }];
    
//    self.tableView.tableFooterView = footview;
    
    
    
}

//设置支付点击状态,保证只有一个显示选中
-(void)clickbutton:(UIButton*)sender
{
    
    
    
    _SelectedButton .selected = NO;
    
    
    sender.selected =YES;
    _SelectedButton = sender;
    
    
    
}
- (void)viewDidLoad {
    
    UITableView * tableview = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height - 49 - 44 - 22) style:UITableViewStyleGrouped];
    [self.view addSubview:tableview];
//    注册cell
    [tableview registerClass:[UITableViewCell  class] forCellReuseIdentifier:@"celled"];
     [tableview  registerClass:[UITableViewCell  class] forCellReuseIdentifier:@"celled1"];
    [tableview  registerNib:[UINib  nibWithNibName:@"LBCaiPinModelTableViewCell" bundle:nil] forCellReuseIdentifier:@"celled2"];
    
    [tableview registerNib:[UINib  nibWithNibName:@"LBENDTableViewCell" bundle:nil] forCellReuseIdentifier:@"celled3"];
    
    
    
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor lightGrayColor];
   self.title=@"支付";
  tableview.dataSource=self;
    tableview.delegate=self;
    
//    self.tableView.style =
//    MARK:创建单例模型数组
    _ModelGroup = [[shoppingCartManager sharedShoppingCartManager]getShoppingCartTotalList];
    
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

    return 4;

}



-(NSInteger )tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSInteger num;
    switch (section) {
        case 0:
            num=1;
            break;
        case 1:
            num=4;
            break;
        case 2:
//            num=3;
            num = _ModelGroup.count;
            break;
        case 3:
            num=1;
            break;
        default:
            break;
    }

    return num;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
//    第一组
    if (indexPath.section==0)
    {
    UITableViewCell *cell = [tableView  dequeueReusableCellWithIdentifier:@"celled" forIndexPath:indexPath];
  
   
        cell.imageView.image = [UIImage imageNamed:@"v2_submit_Icon"];
    cell.textLabel.text =@"1张优惠券";
        [cell.textLabel setTextColor:[UIColor  redColor]];
        
        cell .accessoryType =UITableViewCellAccessoryDisclosureIndicator;
        UIButton * button = [[UIButton alloc]init];
        [cell.contentView addSubview:button];
        
        [button mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(cell.contentView).offset(-5);
            
            make.right.equalTo(cell.contentView).offset(-10);
        }];
        
        button.titleLabel.font = [UIFont  systemFontOfSize:16];
        [button setTitle:@"查看" forState:UIControlStateNormal];
        [button setTitleColor:[UIColor  blackColor] forState:UIControlStateNormal];
        
     return cell;
    }
    //第二组
    
  
    else if (indexPath.section==1)
    {
          NSMutableArray * arryM= [NSMutableArray arrayWithCapacity:4];
        
        UITableViewCell *cell = [tableView  dequeueReusableCellWithIdentifier:@"celled1" forIndexPath:indexPath];
        if (indexPath.row==0)
        {
            cell.imageView.image= [UIImage imageNamed:@"tengxunpay"];
            cell.textLabel.text =@"微信支付";
            
            UIButton * NoselectedButton = [[UIButton alloc]init];
//            NoselectedButton . imageView.image = [UIImage imageNamed:@"noneselected"];
            
            [NoselectedButton setImage:[UIImage imageNamed:@"noneselected"] forState:UIControlStateNormal];
            [NoselectedButton  setImage:[UIImage imageNamed:@"selctedpay"] forState:UIControlStateSelected];
            
//            [NoselectedButton addTarget:self action:@selector(clickbutton:) forControlEvents:UIControlEventTouchUpInside];
            
            [NoselectedButton  sizeToFit];
            [cell.contentView addSubview:NoselectedButton];
            [NoselectedButton  mas_makeConstraints:^(MASConstraintMaker *make) {
               
                make.bottom.right.equalTo(cell.contentView).offset(-8);
            }];
            
            [arryM addObject:NoselectedButton];
        }
        else if (indexPath.row==1)
        {
            cell.imageView.image= [UIImage imageNamed:@"icon_qq"];
            cell.textLabel.text =@"QQ钱包";
            
            UIButton * NoselectedButton = [[UIButton alloc]init];
            [NoselectedButton setImage:[UIImage imageNamed:@"noneselected"] forState:UIControlStateNormal];
            
//             [NoselectedButton addTarget:self action:@selector(clickbutton:) forControlEvents:UIControlEventTouchUpInside];
//            UIControlStateHighlighted  = 1 << 0,                  // used when UIControl isHighlighted is set
//            UIControlStateDisabled     = 1 << 1,
//            UIControlStateSelected
            [NoselectedButton  setImage:[UIImage imageNamed:@"selctedpay"] forState:UIControlStateSelected];
            [NoselectedButton  sizeToFit];
            [cell.contentView addSubview:NoselectedButton];
            [NoselectedButton  mas_makeConstraints:^(MASConstraintMaker *make) {
                
                make.bottom.right.equalTo(cell.contentView).offset(-8);
            }];

        [arryM addObject:NoselectedButton];
        
        }else if (indexPath.row==2)
        {
            cell.imageView.image= [UIImage imageNamed:@"alipayimg"];
            cell.textLabel.text =@"支付宝支付";
            
            UIButton * NoselectedButton = [[UIButton alloc]init];
            [NoselectedButton setImage:[UIImage imageNamed:@"noneselected"] forState:UIControlStateNormal];
            [NoselectedButton  setImage:[UIImage imageNamed:@"selctedpay"] forState: UIControlStateSelected];
            
//             [NoselectedButton addTarget:self action:@selector(clickbutton:) forControlEvents:UIControlEventTouchUpInside];
            [NoselectedButton  sizeToFit];
            [cell.contentView addSubview:NoselectedButton];
            [NoselectedButton  mas_makeConstraints:^(MASConstraintMaker *make) {
                
                make.bottom.right.equalTo(cell.contentView).offset(-8);
            }];
            [arryM addObject:NoselectedButton];
            
            
        }else if (indexPath.row==3)
        {
            cell.imageView.image= [UIImage imageNamed:@"huodao"];
            cell.textLabel.text =@"货到付款";
            
            UIButton * NoselectedButton = [[UIButton alloc]init];
            [NoselectedButton setImage:[UIImage imageNamed:@"noneselected"] forState:UIControlStateNormal];
            [NoselectedButton  setImage:[UIImage imageNamed:@"selctedpay"] forState:UIControlStateSelected];
            
//             [NoselectedButton addTarget:self action:@selector(clickbutton:) forControlEvents:UIControlEventTouchUpInside];
            [NoselectedButton  sizeToFit];
            [cell.contentView addSubview:NoselectedButton];
            [NoselectedButton  mas_makeConstraints:^(MASConstraintMaker *make) {
                
                make.bottom.right.equalTo(cell.contentView).offset(-8);
            }];
            
            
            [arryM addObject:NoselectedButton];
        }
        _bUttonGroup =arryM.copy;
        
        [_bUttonGroup  enumerateObjectsUsingBlock:^(UIButton* obj, NSUInteger idx, BOOL * _Nonnull stop) {
            obj.tag = idx;
           
            [obj addTarget:self action:@selector(clickbutton:) forControlEvents:UIControlEventTouchUpInside];
            
        }];
        return cell;
    }
//    第三组
    else if (indexPath.section==2)
    {
        LBCaiPinModelTableViewCell * cell = [tableView  dequeueReusableCellWithIdentifier:@"celled2" forIndexPath:indexPath];
        
        shoppingCartModel * model = _ModelGroup[indexPath.row];
        
        cell.model2 =model;
        return cell;
    }
    
    
    
    //第四组
    else
    {
         LBENDTableViewCell *cell = [tableView  dequeueReusableCellWithIdentifier:@"celled3" forIndexPath:indexPath];
    
        shoppingCartModel * model = _ModelGroup[indexPath.row];
        
        cell.model3 =model;
    
        return cell;
    }
    
}

//组头高度
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    NSIndexPath * indexpath = [[NSIndexPath alloc]initWithIndex:section];
    if (indexpath.section==0) {
        return 1;
    }

    return 10;
}
//MARK:组头内容
-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if (section==0) {
        return @"";
    }
    else if (section==1)
    {
    
    return @"选择支付方式";
    }
    else if (section==2)
    {
        
        return @"精选商品";
    }
    else if (section==3)
    {
        
        return @"费用明细";
    }

    return nil;
}
//组尾高度
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    if (section ==2) {
        return 30;
    } else {
        return 15;
    }


}

//MARK：组尾内容
-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{

    if (section==2)
    {
        UIView * footview = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 60)];
        UILabel * zongJIAlabel = [[UILabel  alloc]init];
        [footview addSubview:zongJIAlabel];
        

        
        
     CGFloat zongjia=   [[shoppingCartManager  sharedShoppingCartManager]getShoppingCartTotalPrice];
        
                [zongJIAlabel  setText:[NSString stringWithFormat:@"¥%.1f",zongjia]];
        
        [zongJIAlabel setTextColor:[UIColor  redColor]];
        [zongJIAlabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.right.equalTo(footview).offset(-10);
        }];
        
        
        
        return footview;
    }else
    {

        return nil;
    }
}

//行高
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{

    if (indexPath.section==3)
    {
        return 170;
    }


    return 45;
}


-(void)zhifu
{
    if (_SelectedButton.selected==NO) {
        
        
        [SVProgressHUD  showErrorWithStatus:@"请选择支付方式"];
    }
    
    else
    {
        
      [self.navigationController dismissViewControllerAnimated:YES completion:nil];
        
       
        //MARK:设置支付成功弹窗
       
//        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"支付成功！" preferredStyle:(UIAlertControllerStyleAlert)];
//        UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"确认" style:(UIAlertActionStyleDefault) handler:nil];
//        [alert addAction:cancel];
//        [self presentViewController:alert animated:YES completion:^{
        
//            [self.navigationController popToRootViewControllerAnimated:YES];
        
            [self performSelector:@selector(tanchuSV) withObject:self afterDelay:2];
        
//        }];
        
        
        
    }
    
}
-(void)tanchuSV
{
    
    
   
//    [self dismissViewControllerAnimated:YES completion:^{
    
//    }];
    
    
    
    [SVProgressHUD  showSuccessWithStatus:@"购买成功！我们将很快进行派送，请保持电话畅通！"];
    [[shoppingCartManager  sharedShoppingCartManager]removeAll];
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}


@end
