//
//  LBCarTableViewCell.m
//  LoveBeen
//
//  Created by mac on 16/9/8.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBCarTableViewCell.h"
#import "SVProgressHUD.h"
#import "shoppingCartModel.h"
#import "shoppingCartManager.h"

@interface LBCarTableViewCell()
//商品名字
@property (weak, nonatomic) IBOutlet UILabel *ModelNameLabel;
//商品单价
@property (weak, nonatomic) IBOutlet UILabel *Money;
//商品数量
@property (weak, nonatomic) IBOutlet UILabel *CountLbel;


@end;
@implementation LBCarTableViewCell


//减少
- (IBAction)Reduce:(UIButton *)sender
{
    if (_model.orderCount!=0)
    {
        [[shoppingCartManager sharedShoppingCartManager]reduceToShoppingCartWithGoodsName:_ModelNameLabel.text];
        _CountLbel.text = [NSString stringWithFormat:@"%zd",_model.orderCount];
        
        
        CGFloat zongjia = [[shoppingCartManager sharedShoppingCartManager]getShoppingCartTotalPrice];
        
        if ([self.delegate respondsToSelector:@selector(LBCarTableViewCell:Delegatewithzongjia:)])
        {
            [self.delegate  LBCarTableViewCell:self Delegatewithzongjia:zongjia ];
        }
 
    }
    

}

//增加
- (IBAction)Increse:(UIButton *)sender
{
    if (_model.orderCount<_model.stock)
        
    {
        
        [[shoppingCartManager sharedShoppingCartManager]addToShoppingCartWithGoodsName:_ModelNameLabel.text price:_model.price stock:_model.stock];
        _CountLbel.text = [NSString stringWithFormat:@"%zd",_model.orderCount];
        
        
        CGFloat zongjia = [[shoppingCartManager sharedShoppingCartManager]getShoppingCartTotalPrice];
        
        if ([self.delegate respondsToSelector:@selector(LBCarTableViewCell:Delegatewithzongjia:)])
        {
            [self.delegate  LBCarTableViewCell:self Delegatewithzongjia:zongjia];
        }

        
    }
    else
    {
        //MARK:设置没库存弹窗
        [SVProgressHUD  showImage:[UIImage imageNamed:@"beentishiSV"] status:@"大爷，奴家今天不接客了，看看别的吧。"];
        
        [self performSelector:@selector(dismiss) withObject:nil afterDelay:2];

    
    
    }
    
  
}

-(void)dismiss
{

    [SVProgressHUD  dismiss];

}

#pragma mark:重写属性
-(void)setModel:(shoppingCartModel *)model
{
    _model = model ;
    
    
    
    if([model.name hasPrefix:@"爱鲜蜂·"])
    {
        _ModelNameLabel .text  = [model.name substringFromIndex:4];
    }else
    {
        _ModelNameLabel .text = model.name;
        
    }
    
    
    
    _Money.text = [NSString stringWithFormat:@"%.1f",model.price];
    
    _CountLbel.text = [NSString stringWithFormat:@"%zd",model.orderCount];




}





@end
