//
//  LBCarTableViewCell.h
//  LoveBeen
//
//  Created by mac on 16/9/8.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>
@class shoppingCartModel,LBCarTableViewCell;

@protocol LBCarTableViewCellDelegate <NSObject>
-(void)LBCarTableViewCell:(LBCarTableViewCell *)CarTableViewCell Delegatewithzongjia:(CGFloat)zongjia;


@end


@interface LBCarTableViewCell : UITableViewCell

@property(nonatomic,strong)shoppingCartModel * model;

@property(nonatomic,strong)id<LBCarTableViewCellDelegate>delegate;
@end
