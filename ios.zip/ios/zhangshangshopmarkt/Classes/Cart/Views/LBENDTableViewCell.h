//
//  LBENDTableViewCell.h
//  LoveBeen
//
//  Created by mac on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>
@class shoppingCartModel;
@interface LBENDTableViewCell : UITableViewCell
@property(nonatomic,strong)shoppingCartModel * model3;
@end
