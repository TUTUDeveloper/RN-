//
//  LBENDTableViewCell.m
//  LoveBeen
//
//  Created by mac on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBENDTableViewCell.h"
#import "shoppingCartModel.h"
#import "shoppingCartManager.h"

@interface LBENDTableViewCell()

//结算的钱
@property (weak, nonatomic) IBOutlet UILabel *MoneyLabel;






@end;


@implementation LBENDTableViewCell
#pragma mark:重写model属性
-(void)setModel3:(shoppingCartModel *)model3
{
    _model3 = model3 ;
    
    CGFloat zongjia = [[shoppingCartManager sharedShoppingCartManager]getShoppingCartTotalPrice];
    
    _MoneyLabel.text = [NSString stringWithFormat:@"¥%.1f",zongjia];
    
    
    
}









@end
