//
//  LBCaiPinModelTableViewCell.m
//  LoveBeen
//
//  Created by mac on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBCaiPinModelTableViewCell.h"
#import "shoppingCartModel.h"
@interface LBCaiPinModelTableViewCell()
@property (weak, nonatomic) IBOutlet UILabel *NameLabel;

@property (weak, nonatomic) IBOutlet UILabel *DanJiaLabel;


@property (weak, nonatomic) IBOutlet UILabel *CountLabel;




@end;
@implementation LBCaiPinModelTableViewCell


#pragma mark:重写model属性
-(void)setModel2:(shoppingCartModel *)model2
{
    _model2 = model2;
    
  
    
    if([model2.name hasPrefix:@"爱鲜蜂·"])
    {
         _NameLabel .text = [model2.name substringFromIndex:4];
    }else
    {
          _NameLabel .text = model2.name;
        
    }
    
    
    
    _DanJiaLabel .text = [NSString stringWithFormat:@"%.1f",model2.price];
    _CountLabel.text = [NSString stringWithFormat:@"%zd",model2.orderCount];

}




- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
