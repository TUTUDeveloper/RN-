//
//  LBCarHeadView.h
//  LoveBeen
//
//  Created by mac on 16/9/8.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LBCarHeadView : UIView
@property (weak, nonatomic) IBOutlet UITextField *NameTF;
@property (weak, nonatomic) IBOutlet UITextField *PhoneTF;
@property (weak, nonatomic) IBOutlet UITextField *AdressTF;

@end
