//
//  LoginViewController.m
//  卖药的
//
//  Created by belo on 2017/5/15.
//  Copyright © 2017年 apple. All rights reserved.
//

#import "LoginViewController.h"
#import "LBMainController.h"
#import "GetMiMaViewController.h"
#import "RegisViewController.h"
#import "SVProgressHUD.h"
@interface LoginViewController ()
@property (weak, nonatomic) IBOutlet UITextField *PasswordLB;
@property (weak, nonatomic) IBOutlet UITextField *Phonetextfield;
@property (strong, nonatomic) IBOutlet UIView *BaseV;


@property(nonatomic,copy)NSString *uuidns;
@property(nonatomic,copy)NSString *rongToken;
@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    NSUserDefaults *userDef = [NSUserDefaults standardUserDefaults];
    NSString *user = [userDef objectForKey:@"user"];
    NSString *password = [userDef objectForKey:@"password"];
    self.Phonetextfield.text = user;
    self.PasswordLB.text = password;
    
 
    
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
  [self.BaseV endEditing:YES];

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)Login:(UIButton *)sender {
 
    if ([self.Phonetextfield.text isEqualToString:@"18337111369"]&&[self.PasswordLB.text isEqualToString:@"123456"]) {
        
        NSUserDefaults *userDef = [NSUserDefaults standardUserDefaults];
        [userDef setObject:_Phonetextfield.text forKey:@"user"];
        [userDef setObject:_PasswordLB.text forKey:@"password"];
        
        [userDef setBool:YES forKey:@"islogin"];
        
        [userDef synchronize];
        
        LBMainController *mainController = [[LBMainController alloc] init];
        
        mainController.selectedIndex = 3;
        
        [self presentViewController:mainController animated:NO completion:nil];
    } else {
         [SVProgressHUD  showWithStatus:@"正在加载网络数据"];
    }
    
    
    
  
}
- (IBAction)Regisn:(UIButton *)sender {
    RegisViewController *vc = [[RegisViewController alloc]initWithNibName:@"RegisViewController" bundle:nil];
    
     [self presentViewController:vc animated:YES completion:nil];
}
- (IBAction)outlogin:(UIButton *)sender {
    
    
//    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
//    MainTabbarController *firstController = [storyBoard instantiateViewControllerWithIdentifier:@"mainid"];
 LBMainController *mainController = [[LBMainController alloc] init];
    
    mainController.selectedIndex = 0;
    
    [self presentViewController:mainController animated:NO completion:nil];
}

- (IBAction)MISSPASSword:(UIButton *)sender {
    
    GetMiMaViewController *vc = [[GetMiMaViewController alloc]initWithNibName:@"GetMiMaViewController" bundle:nil];
    [self presentViewController:vc animated:YES completion:nil];
}
@end
