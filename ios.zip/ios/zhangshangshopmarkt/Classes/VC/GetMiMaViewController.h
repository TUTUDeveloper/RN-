//
//  GetMiMaViewController.h
//  GuoJin001
//
//  Created by seasar on 16/10/27.
//  Copyright © 2016年 seasar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GetMiMaViewController : UIViewController

@end
