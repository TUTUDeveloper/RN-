//
//  RegisViewController.m
//  卖药的
//
//  Created by belo on 2017/5/18.
//  Copyright © 2017年 apple. All rights reserved.
//

#import "RegisViewController.h"

@interface RegisViewController ()
@property (weak, nonatomic) IBOutlet UITextField *NameTF;
@property (weak, nonatomic) IBOutlet UITextField *PhoneTF;
@property (weak, nonatomic) IBOutlet UITextField *CodeTF;
@property (weak, nonatomic) IBOutlet UITextField *PassWordTF;
@property (weak, nonatomic) IBOutlet UIButton *GetCodeBTN;





@property(nonatomic,strong)NSMutableArray *bUttonGroup;
@property(nonatomic,strong)UIButton *SelectedButton;

@property(nonatomic,copy)NSString * regiscode;
@end

@implementation RegisViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.GetCodeBTN .layer.cornerRadius = 15;
    self.GetCodeBTN.layer.masksToBounds =YES;
    
   
}

-(void)clickbutton:(UIButton*)sender
{
    
    _SelectedButton .selected = NO;
    
    
    sender.selected =YES;
    _SelectedButton = sender;
    //    _SelectedButton.tag = sender.tag;
    
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)BackBTN:(UIButton *)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)GetCodeBTN:(UIButton *)sender {
    
    if (_PhoneTF.text.length == 11) {
        [self timeout];
      
        
    NSDictionary *dic = @{@"account":_PhoneTF.text};
        //这里发请求
        
       
       UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message: @"发送成功，请注意查收" preferredStyle:(UIAlertControllerStyleAlert)];
       UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"返回" style:(UIAlertActionStyleCancel) handler:nil];
       [alert addAction:cancel];
       [self presentViewController:alert animated:YES completion:nil];
       

      
       
    }
else {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"请输入手机号" preferredStyle:(UIAlertControllerStyleAlert)];
        UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"返回" style:(UIAlertActionStyleCancel) handler:nil];
        [alert addAction:cancel];
        [self presentViewController:alert animated:YES completion:nil];
    
    }

}


- (IBAction)TIJiao:(UIButton *)sender {
   
    
    if ([_regiscode isEqualToString:_CodeTF.text]&&_NameTF.text.length!=0) {
       

    }else
    {
   
    
    }
    
    
    
    
}

- (IBAction)SelectedSexBTN:(UIButton *)sender {
}
-(void)timeout{
    //发送短信倒计时;
    
    __block int timeout=119; //倒计时时间
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_source_t _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0,queue);
    dispatch_source_set_timer(_timer,dispatch_walltime(NULL, 0),1.0*NSEC_PER_SEC, 0); //每秒执行
    
    dispatch_source_set_event_handler(_timer, ^{
        if(timeout<=0){ //倒计时结束，关闭
            dispatch_source_cancel(_timer);
            dispatch_async(dispatch_get_main_queue(), ^{
                //设置界面的按钮显示 根据自己需求设置（倒计时结束后调用）
                [_GetCodeBTN setTitle:@"重新发送" forState:UIControlStateNormal];
                //设置不可点击
                _GetCodeBTN.userInteractionEnabled = YES;
                _GetCodeBTN.backgroundColor = [UIColor orangeColor];
            });
        }else{
            //  int minutes = timeout / 60;    //这里注释掉了，这个是用来测试多于60秒时计算分钟的。
            int seconds = timeout % 120;
            NSString *strTime = [NSString stringWithFormat:@"%d", seconds];
            dispatch_async(dispatch_get_main_queue(), ^{
                //设置界面的按钮显示 根据自己需求设置
                //                NSLog(@"____%@",strTime);
                _GetCodeBTN.titleLabel.font    = [UIFont systemFontOfSize: 12];//调整button字体大小；
                [_GetCodeBTN setTitle:[NSString stringWithFormat:@"重新发送(%@)",strTime] forState:UIControlStateNormal];
                //设置可点击
                _GetCodeBTN.userInteractionEnabled = NO;
                _GetCodeBTN.backgroundColor = [UIColor lightGrayColor];
            });
            timeout--;
        }
    });
    
    dispatch_resume(_timer);
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.PhoneTF resignFirstResponder];
    [self.CodeTF resignFirstResponder];
    [self.PassWordTF resignFirstResponder];
    [self.NameTF resignFirstResponder];
}
@end
