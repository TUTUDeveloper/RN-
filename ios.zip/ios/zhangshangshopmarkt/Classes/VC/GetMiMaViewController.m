//
//  GetMiMaViewController.m
//  GuoJin001
//
//  Created by seasar on 16/10/27.
//  Copyright © 2016年 seasar. All rights reserved.
//

#import "GetMiMaViewController.h"

@interface GetMiMaViewController ()
@property (weak, nonatomic) IBOutlet UIButton *backBtn;
@property (weak, nonatomic) IBOutlet UITextField *telephoneTF;//手机号输入框
@property (weak, nonatomic) IBOutlet UITextField *codeTF;//验证码输入框
@property (weak, nonatomic) IBOutlet UIButton *codeBtn;//获取验证码按钮
@property (weak, nonatomic) IBOutlet UITextField *NewPasswordTF;//新密码输入框
@property (weak, nonatomic) IBOutlet UITextField *affPasswordTF;//确认新密码
@property (weak, nonatomic) IBOutlet UIButton *affBtn;//确认修改按钮




@property(nonatomic,copy)NSString * forgitCode;

@end

@implementation GetMiMaViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   

    // Do any additional setup after loading the view from its nib.
    self.codeBtn.clipsToBounds = YES;
    self.codeBtn.layer.cornerRadius = 15;
    
    self.affBtn.clipsToBounds = YES;
    self.affBtn.layer.cornerRadius = 15;
    
    self.backBtn.clipsToBounds = YES;
    self.backBtn.layer.cornerRadius = 15;
    
    self.NewPasswordTF.secureTextEntry = YES;
    self.affPasswordTF.secureTextEntry = YES;
}
#pragma mark获取验证码的相应方法
- (IBAction)getCode:(id)sender {
         if (_telephoneTF.text.length == 11) {
        [self timeout];
    

             
         }
         else {
             UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"请输入手机号" preferredStyle:(UIAlertControllerStyleAlert)];
             UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"返回" style:(UIAlertActionStyleCancel) handler:nil];
             [alert addAction:cancel];
             [self presentViewController:alert animated:YES completion:nil];
             
         }
}
#pragma mark确认修改的响应方法
- (IBAction)affClick:(id)sender {
    
    if (_telephoneTF.text.length != 11) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"请输入手机号" preferredStyle:(UIAlertControllerStyleAlert)];
        UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"返回" style:(UIAlertActionStyleCancel) handler:nil];
        [alert addAction:cancel];
        [self presentViewController:alert animated:YES completion:nil];
    }else
    {
       
      
//        int channelid =[_telephoneTF.text intValue];
//        NSNumber *num =[NSNumber numberWithInt:channelid];
        
        if ([_forgitCode isEqualToString:_codeTF.text]&&[_NewPasswordTF.text isEqualToString:_affPasswordTF.text]) {
            
            
                UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"提示" message:@"重置密码成功！" preferredStyle:(UIAlertControllerStyleAlert)];
                UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"返回" style:(UIAlertActionStyleCancel) handler:nil];
                [alert addAction:cancel];
                [self presentViewController:alert animated:YES completion:nil];
                
             
                
           
        }
        else
        {
     
        
        }
       

        
    }
}
#pragma mark返回的响应方式
- (IBAction)backClick:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)timeout{
    //发送短信倒计时;
    
    __block int timeout=119; //倒计时时间
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_source_t _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0,queue);
    dispatch_source_set_timer(_timer,dispatch_walltime(NULL, 0),1.0*NSEC_PER_SEC, 0); //每秒执行
    
    dispatch_source_set_event_handler(_timer, ^{
        if(timeout<=0){ //倒计时结束，关闭
            dispatch_source_cancel(_timer);
            dispatch_async(dispatch_get_main_queue(), ^{
                //设置界面的按钮显示 根据自己需求设置（倒计时结束后调用）
                [_codeBtn setTitle:@"重新发送" forState:UIControlStateNormal];
                //设置不可点击
                _codeBtn.userInteractionEnabled = YES;
                _codeBtn.backgroundColor = [UIColor orangeColor];
            });
        }else{
            //  int minutes = timeout / 60;    //这里注释掉了，这个是用来测试多于60秒时计算分钟的。
            int seconds = timeout % 120;
            NSString *strTime = [NSString stringWithFormat:@"%d", seconds];
            dispatch_async(dispatch_get_main_queue(), ^{
                //设置界面的按钮显示 根据自己需求设置
                //                NSLog(@"____%@",strTime);
                _codeBtn.titleLabel.font    = [UIFont systemFontOfSize: 12];//调整button字体大小；
                [_codeBtn setTitle:[NSString stringWithFormat:@"重新发送(%@)",strTime] forState:UIControlStateNormal];
                //设置可点击
                _codeBtn.userInteractionEnabled = NO;
                _codeBtn.backgroundColor = [UIColor lightGrayColor];
            });
            timeout--;
        }
    });
    
    dispatch_resume(_timer);
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.telephoneTF resignFirstResponder];
    [self.codeTF resignFirstResponder];
    [self.NewPasswordTF resignFirstResponder];
    [self.affPasswordTF resignFirstResponder];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillDisappear:(BOOL)animated{
   
}


@end
