//
//  LBNewFeatureView.m
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/12.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBNewFeatureView.h"
#import "Masonry.h"

@interface LBNewFeatureView () <UIScrollViewDelegate>

@property (strong,nonatomic) UIScrollView *scrollView;
@property (strong,nonatomic) UIPageControl *pageControl;

@end

@implementation LBNewFeatureView

- (void)setPictures:(NSArray *)pictures{
    _pictures = pictures;
    for (NSInteger i = 0; i < _pictures.count; i ++) {
        UIImageView *picture = [[UIImageView alloc]init];
        picture.image = _pictures[i];
        picture.frame = CGRectMake(i * self.frame.size.width, 0, self.frame.size.width, self.frame.size.height);
        [self.scrollView insertSubview:picture atIndex:0];
    }
    self.scrollView.contentSize = CGSizeMake((_pictures.count + 1) * self.frame.size.width, self.frame.size.height);
    self.pageControl.numberOfPages = _pictures.count;
}

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self setupUI];
    }
    return self;
}

- (void)setupUI{
    UIScrollView *scrollView = [[UIScrollView alloc]init];
    scrollView.frame = self.bounds;
    scrollView.showsVerticalScrollIndicator = NO;
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.bounces = NO;
    scrollView.pagingEnabled = YES;
    scrollView.delegate = self;
    [self addSubview:scrollView];
    self.scrollView = scrollView;
    
    UIPageControl *pageControl = [[UIPageControl alloc]init];
    pageControl.pageIndicatorTintColor = [UIColor blueColor];
    pageControl.currentPageIndicatorTintColor = [UIColor redColor];
    [self addSubview:pageControl];
    self.pageControl = pageControl;
    
    [pageControl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self);
        make.bottom.equalTo(self).offset(-40);
    }];
}

#pragma mark - UIScrollViewDelegateMethod
- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    CGFloat offsetX = scrollView.contentOffset.x;
    CGFloat page = offsetX / self.frame.size.width;
    page += 0.5;
    self.pageControl.currentPage = (NSInteger)page;
    self.pageControl.hidden = ((NSInteger)page == self.pictures.count);
}
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    CGFloat offsetX = scrollView.contentOffset.x;
    CGFloat page = offsetX / self.frame.size.width;
    if ((NSInteger)page == self.pictures.count) {
        [self removeFromSuperview];
    }
}

@end
