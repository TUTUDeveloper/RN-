//
//  LBAnimateTabBar.m
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBAnimateTabBar.h"


@implementation LBAnimateTabBar

- (void)layoutSubviews{
    [super layoutSubviews];
    
    for (UIControl *tabBarButton in self.subviews) {
        if ([tabBarButton isKindOfClass:NSClassFromString(@"UITabBarButton")]) {
            [tabBarButton addTarget:self action:@selector(tabBarButtonClick:) forControlEvents:UIControlEventTouchUpInside];
            
        }
    }
}

- (void)tabBarButtonClick:(UIControl *)tabBarButton{
    for (UIView *imageView in tabBarButton.subviews) {
        if ([imageView isKindOfClass:NSClassFromString(@"UITabBarSwappableImageView")])
        {
            CAKeyframeAnimation *animation = [CAKeyframeAnimation animation];
            animation.keyPath = @"transform.scale";
            animation.values = @[@1.0,@1.3,@0.9,@1.15,@0.95,@1.02,@1.0];
            animation.duration = 1;
            animation.calculationMode = kCAAnimationCubic;
            [imageView.layer addAnimation:animation forKey:nil];
        }
    }
}

@end
