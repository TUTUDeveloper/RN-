//
//  LBAnimateTabBar.h
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/9.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface LBAnimateTabBar : UITabBar

@end
