//
//  StartShopViewController.m
//  been
//
//  Created by hehe on 16/11/22.
//  Copyright © 2016年 axiba. All rights reserved.
//

#import "ShopViewController.h"
#import "ShopFrashView.h"
#import "LBMainController.h"
@interface ShopViewController ()

@end

@implementation ShopViewController

- (void)viewDidLoad {
    [super viewDidLoad];

  
  NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
  
  NSArray * allLanguages = [defaults objectForKey:@"AppleLanguages"];
  
  NSString * preferredLang = [allLanguages objectAtIndex:0];
  
  if([preferredLang isEqualToString:@"zh-Hant-CN"] || [preferredLang isEqualToString:@"zh-Hans-CN"]){
    
    self.view.backgroundColor = UIColorFromHex(0xececec);
    ShopFrashView * view = [[ShopFrashView alloc]initWithFrame:CGRectMake(0, 0, kMainScreenWidth, kMainScreenHeight)];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(doGameOtherNotification:) name:@"GameOther" object:nil];
    [self.view addSubview:view];
    
  }else{
    
    [self AFNMonitor];
    
  }

}
-(void)doGameOtherNotification:(NSNotification *)notification{
  
  
  [self.view.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
  
  [self AFNMonitor];
}

-(void)AFNMonitor
{
  [[AFNetworkReachabilityManager sharedManager] startMonitoring];
  [[AFNetworkReachabilityManager sharedManager ] setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
    
    if(status ==AFNetworkReachabilityStatusReachableViaWWAN || status == AFNetworkReachabilityStatusReachableViaWiFi)
    {
      AppDelegate *delegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];

      LBMainController *mainController = [[LBMainController alloc] init];

      delegate.window.rootViewController =mainController;
      
      [delegate.window makeKeyAndVisible];
      
      
    }else
    {
      NSLog(@"没有网");
      UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"网络失去连接" message:nil delegate:self cancelButtonTitle:@"取消" otherButtonTitles:nil, nil];
      alert.delegate = self;
      [alert show];
    }
  }];

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
