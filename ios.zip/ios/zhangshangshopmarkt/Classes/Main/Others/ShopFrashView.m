//
//  ShopFrashView.m
//  AwesomeProject
//
//  Created by mac on 17/11/24.
//  Copyright © 2017年 Facebook. All rights reserved.
//

#import "ShopFrashView.h"
#import <React/RCTRootView.h>
#import <React/RCTBundleURLProvider.h>
#import <RCTHotUpdate/RCTHotUpdate.h>
@implementation ShopFrashView
-(instancetype)initWithFrame:(CGRect)frame
  {
    if (self=[super initWithFrame:frame]) {
       NSURL *jsCodeLocation;
      

      
     
      
#ifdef DEBUG
//      jsCodeLocation = [[RCTBundleURLProvider sharedSettings] jsBundleURLForBundleRoot:@"index" fallbackResource:nil];
      
    jsCodeLocation = [[NSBundle mainBundle] URLForResource:@"pushy" withExtension:@"jsbundle"];
#else
      jsCodeLocation=[RCTHotUpdate bundleURL];
#endif
      

      
      RCTRootView *rootView = [[RCTRootView alloc] initWithBundleURL:jsCodeLocation
                                moduleName:@"zhangshangshopmarkt"
                                                   initialProperties:nil
                                                       launchOptions:nil];
      
      [self addSubview:rootView];
      rootView.frame =self.bounds;
      
      
      
    }
  
    return self;
  }

@end
