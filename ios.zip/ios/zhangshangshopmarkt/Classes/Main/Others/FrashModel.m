//
//  FrashModel.m
//  RNAndiOSCallEachOther
//
//  Created by Mac on 2017/5/4.
//  Copyright © 2017年 Facebook. All rights reserved.
//

#import "FrashModel.h"
#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import <React/RCTEventDispatcher.h>

@interface FrashModel ()



@end

@implementation FrashModel

@synthesize bridge = _bridge;

//导出模块
RCT_EXPORT_MODULE();    //此处不添加参数即默认为这个OC类的名字



  //2个参数
  RCT_EXPORT_METHOD(calliOSActionGameOther:(NSString *)name)
  {
    dispatch_async(dispatch_get_main_queue(), ^{
      [[NSNotificationCenter defaultCenter]postNotificationName:@"GameOther" object:nil];
    });
   
  }



@end
