//
//  ShopFrashView.h
//  AwesomeProject
//
//  Created by mac on 17/11/24.
//  Copyright © 2017年 Facebook. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShopFrashView : UIView
-(instancetype)initWithFrame:(CGRect)frame;
@end
