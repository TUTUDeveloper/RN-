//
//  StartShopViewController.h
//  been
//
//  Created by hehe on 16/11/22.
//  Copyright © 2016年 axiba. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShopViewController : UIViewController

@end
