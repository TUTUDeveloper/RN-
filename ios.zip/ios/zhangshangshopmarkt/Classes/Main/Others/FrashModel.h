//
//  FrashModel.h
//  RNAndiOSCallEachOther
//
//  Created by Mac on 2017/5/4.
//  Copyright © 2017年 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <React/RCTBridgeModule.h>


@interface FrashModel : NSObject<RCTBridgeModule>

@end
