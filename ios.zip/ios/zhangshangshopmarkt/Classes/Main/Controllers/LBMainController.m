//
//  LBMainController.m
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/7.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBMainController.h"
#import "LBNavigationController.h"
#import "LBAnimateTabBar.h"
#import "LBCartController.h"
#import "LBNewFeatureView.h"
#import "shoppingCartManager.h"
#import "LoginViewController.h"

@interface LBMainController () <UITabBarControllerDelegate>

@end


@implementation LBMainController {
    LBNavigationController *_cartNavigationController;
    NSArray<UIImage *> *_picture;
    BOOL _hasNewFeature;
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    UITabBarItem *tabBarItem = [[[self.tabBarController tabBar] items] objectAtIndex:2];
    [tabBarItem setBadgeValue:[NSString stringWithFormat:@"%zd", [[shoppingCartManager sharedShoppingCartManager] getShoppingCartTotalCount]]];
    if ([[shoppingCartManager sharedShoppingCartManager] getShoppingCartTotalCount] == 0) {
        tabBarItem.badgeValue = nil;
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    [self loadData];
    [self setupAnimateTabBar];
    [self setupUI];
}

#pragma mark - Load data
//- (void)loadData{
//    NSMutableArray<UIImage *> *arrayM =[NSMutableArray array];
//    for (NSInteger i = 0; i < 3; i ++) {
//        UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"guide_page_%zd",i + 1]];
//        [arrayM addObject:image];
//    }
//    _picture = [arrayM copy];
//    _hasNewFeature = YES;
//}

#pragma mark - Set up animate tab bar
- (void)setupAnimateTabBar{
    LBAnimateTabBar *animateTabBar = [[LBAnimateTabBar alloc] init];
    [self setValue:animateTabBar forKey:@"tabBar"];
}

#pragma mark - Set up user interface
- (void)setupUI{
    self.view.backgroundColor = [UIColor whiteColor];
    
    if (_hasNewFeature) {
        LBNewFeatureView *newFeatureView = [[LBNewFeatureView alloc]initWithFrame:self.view.bounds];
        newFeatureView.pictures = _picture;
        [self.view addSubview:newFeatureView];
    }
    
    LBNavigationController *homeNavigationController = [self navigationControllerWithClassName:@"LBHomeController" title:@"首页" imageName:@"home"];
    LBNavigationController *marketNavigationController = [self navigationControllerWithClassName:@"LBMarketController" title:@"掌上超市" imageName:@"market"];
    LBNavigationController *cartNavigationController = [self navigationControllerWithClassName:@"LBShoppingCartController" title:@"购物车" imageName:@"cart"];
    LBNavigationController *mineNavigationController = [self navigationControllerWithClassName:@"LBMineController" title:@"我的" imageName:@"mine"];
    self.viewControllers = @[homeNavigationController,marketNavigationController,cartNavigationController,mineNavigationController];
    
    self.delegate = self;
    _cartNavigationController = cartNavigationController;
}

/** 根据视图控制器类名创建带导航控制器的视图控制器对象 */
- (LBNavigationController *)navigationControllerWithClassName:(NSString *)ClassName title:(NSString *)title imageName:(NSString *)imageName{
    Class cls = NSClassFromString(ClassName);
    UIViewController *viewController = [[cls alloc] init];
    viewController.tabBarItem.title = title;
    viewController.tabBarItem.image = [[UIImage imageNamed:imageName] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    viewController.tabBarItem.selectedImage = [[UIImage imageNamed:[NSString stringWithFormat:@"%@_selected",imageName]] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    LBNavigationController *navigationController = [[LBNavigationController alloc] initWithRootViewController:viewController];
    return navigationController;
}

/** 获得当前正在显示的控制器 */
- (UIViewController *)getCurrentVC
{
    UIViewController *result = nil;
    
    UIWindow * window = [[UIApplication sharedApplication] keyWindow];
    if (window.windowLevel != UIWindowLevelNormal)
    {
        NSArray *windows = [[UIApplication sharedApplication] windows];
        for(UIWindow * tmpWin in windows){
            if (tmpWin.windowLevel == UIWindowLevelNormal){
                window = tmpWin;
                break;
            }
        }
    }
    
    UIView *frontView = [[window subviews] objectAtIndex:0];
    id nextResponder = [frontView nextResponder];
    
    if ([nextResponder isKindOfClass:[UIViewController class]])
        result = nextResponder;
    else
        result = window.rootViewController;
    
    return result;
}

#pragma mark - Tab bar controller delegate
- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController{
    if (viewController == _cartNavigationController) {
        
        LBCartController *viewController = [[LBCartController alloc] init];
        viewController.view.backgroundColor = [UIColor cz_colorWithHex:0XEBEBEB];
        
        LBNavigationController *navigationController = [[LBNavigationController alloc] initWithRootViewController:viewController];
        navigationController.navigationBar.translucent = NO;
        navigationController.navigationBar.barTintColor = [UIColor whiteColor];
        
        
        UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"fanhuiback"] style:UIBarButtonItemStylePlain target:self action:@selector(clickToDismiss:)];
        [leftItem setTintColor:[UIColor lightGrayColor]];
        viewController.navigationItem.leftBarButtonItem = leftItem;
        
        
        [self presentViewController:navigationController animated:NO completion:nil];

        return NO;
    }
    
    
    NSUserDefaults *useDef = [NSUserDefaults standardUserDefaults];
    
    if ([useDef boolForKey:@"islogin"]!=YES) {
        //这里拿到你想要的tabBarItem,这里的方法有很多,还有通过tag值,这里看你的需要了
        
        
        if ([viewController.tabBarItem.title isEqualToString:@"我的"] ) {
            LoginViewController *vc = [LoginViewController new];
            [self presentViewController:vc animated:YES completion:nil];
            //这里的NO是关键,如果是这个tabBarItem,就不要让他点击进去
            return NO;
        }
        
       
    }
 
    return YES;
}

- (void)clickToDismiss:(UITabBarItem *)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
