//
//  LBNavigationController.m
//  LoveBeen
//
//  Created by 吕成翘 on 16/9/7.
//  Copyright © 2016年 Apress. All rights reserved.
//

#import "LBNavigationController.h"
#import "shoppingCartManager.h"


@interface LBNavigationController ()

@end


@implementation LBNavigationController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    UITabBarItem *tabBarItem = [[[self.tabBarController tabBar] items] objectAtIndex:2];
    [tabBarItem setBadgeValue:[NSString stringWithFormat:@"%zd", [[shoppingCartManager sharedShoppingCartManager] getShoppingCartTotalCount]]];
    if ([[shoppingCartManager sharedShoppingCartManager] getShoppingCartTotalCount] == 0) {
        tabBarItem.badgeValue = nil;
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setupUI];
}

//解决push到子控制器时tabbar不隐藏的问题
- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated{
    if (self.viewControllers.count > 0) {
        viewController.hidesBottomBarWhenPushed = YES;
    }
    [super pushViewController:viewController animated:animated];
}

#pragma mark - Set up user interface
- (void)setupUI{
    self.view.backgroundColor = [UIColor whiteColor];
    
    //取消navigationBar下分界线
//    [self.navigationBar setBackgroundImage:[[UIImage alloc] init] forBarMetrics:UIBarMetricsDefault];
//    [self.navigationBar setShadowImage:[[UIImage alloc] init]];
    self.navigationBar.translucent = NO;
    //设置navigationBar的颜色
    self.navigationBar.barTintColor = [UIColor cz_baseColor];
    //设置navigationBar的标题颜色s
    [self.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor blackColor]}];
}

@end
