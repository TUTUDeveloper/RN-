//
//  AppDelegate.h

//
//  Created by axiba on 16/7/2.
//  Copyright © 2016年 axiba. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "CustomTabBarViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic,nonnull) UIWindow *window;
//@property (nonatomic, strong,nonnull) CustomTabBarViewController *customTabBar;
@property (nonnull,copy) NSString *UUID;
@property (nonnull,copy) NSString *WANIPAdress;
@property (nonnull,strong) NSString *networkStatus;
@property (nonnull,strong)NSString *loginToken;
@property (nonatomic,assign) float netVersion;
@property (nonnull,copy) NSString *versionUrl;
@property (nonnull,copy)NSString *grouptype;
@property (nonatomic,assign) BOOL gengxin;
@property (nonatomic,assign) BOOL isGoAppstoreUpdate;
@property (nonatomic,strong) NSDictionary *pushIfoDic;
@property (nonatomic,assign)BOOL isAnima;
@property (nonatomic,assign) NSInteger enabled;

@property (nonnull,strong) NSString *IP;
- (void)affirmGogin;
- (void)goMainTabbarVC;
@end

