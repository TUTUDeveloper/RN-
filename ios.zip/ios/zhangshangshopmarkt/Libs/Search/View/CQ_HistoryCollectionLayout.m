//
//  CQ_HistoryCollectionLayout.m
//  Bee
//
//  Created by 神威 on 16/9/9.
//  Copyright © 2016年 ys. All rights reserved.
//

#import "CQ_HistoryCollectionLayout.h"

@implementation CQ_HistoryCollectionLayout
- (instancetype)init{
    if (self = [super init]) {
        [self setup];
    }
    return self;
}
- (void)setup{
    //设置collectionVioew组与组之间的间距
    self.sectionInset = UIEdgeInsetsMake(10, 10, 20, 10);
    self.minimumInteritemSpacing = 10;
    
    self.minimumLineSpacing = 20;
    
    self.itemSize = CGSizeMake(100,100);
   
    self.headerReferenceSize = CGSizeMake(30, 50);
    self.footerReferenceSize = CGSizeMake(50, 30);
}
@end
