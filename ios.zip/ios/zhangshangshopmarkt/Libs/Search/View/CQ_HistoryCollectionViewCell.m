//
//  CQ_HistoryCollectionViewCell.m
//  Bee
//
//  Created by 神威 on 16/9/9.
//  Copyright © 2016年 ys. All rights reserved.
//

#import "CQ_HistoryCollectionViewCell.h"
CGFloat heightForCell = 35;
@interface CQ_HistoryCollectionViewCell()
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@end
@implementation CQ_HistoryCollectionViewCell

- (void)awakeFromNib{
    
    self.clipsToBounds = YES;
    self.layer.cornerRadius = heightForCell / 2;
}

- (CGSize)sizeForCell{
    
    //宽度加heightForCell是为了实现两边的圆角
    return CGSizeMake([_titleLabel sizeThatFits:CGSizeMake(MAXFLOAT, MAXFLOAT)].width + heightForCell, heightForCell);
}


- (void)setKeyword:(NSString *)keyword{
    
    _keyword = keyword;
    _titleLabel.text = _keyword;
    [self layoutIfNeeded];
    [self updateConstraintsIfNeeded];
    
}

#pragma mark - 历史点击事件
- (IBAction)historyButton:(UIButton *)sender {
      self.searchBlock(self.titleLabel.text);
}

@end
