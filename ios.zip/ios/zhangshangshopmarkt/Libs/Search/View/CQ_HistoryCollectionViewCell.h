//
//  CQ_HistoryCollectionViewCell.h
//  Bee
//
//  Created by 神威 on 16/9/9.
//  Copyright © 2016年 ys. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CQ_HistoryCollectionViewCell : UICollectionViewCell
@property (copy , nonatomic)NSString *keyword;
- (CGSize)sizeForCell;
//收缩框的block
@property (nonatomic,copy) void(^searchBlock)(NSString *title);
@end
