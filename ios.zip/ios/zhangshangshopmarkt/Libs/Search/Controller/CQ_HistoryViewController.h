//
//  CQ_HistoryViewController.h
//  Bee
//
//  Created by 神威 on 16/9/9.
//  Copyright © 2016年 ys. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CQ_HistoryViewController : UIViewController

@end
