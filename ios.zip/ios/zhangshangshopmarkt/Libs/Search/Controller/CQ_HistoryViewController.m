//
//  CQ_HistoryViewController.m
//  Bee
//
//  Created by 神威 on 16/9/9.
//  Copyright © 2016年 ys. All rights reserved.
//
#import "CQ_HistoryViewController.h"
#import "CQ_HistoryCollectionLayout.h"
#import "CQ_HistoryCollectionViewCell.h"
#import "Masonry.h"
#import "LBMarketProductDetailsController.h"
#import "LBHomeSellModel.h"

static NSString *HistoryViewCell = @"HistoryViewCell";
@interface CQ_HistoryViewController ()<UICollectionViewDelegateFlowLayout,UICollectionViewDelegate,UICollectionViewDataSource,UISearchBarDelegate>
@property (strong , nonatomic) CQ_HistoryCollectionViewCell *cell;
@end

@implementation CQ_HistoryViewController{
    
    NSMutableArray *_data;
    NSArray *_sellList;
    UICollectionView *_collectionView;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self setupUI];
    [self loadData];
    
}

#pragma mark - 历史记录
- (void)setupUI{
    
    
    [self setNavigationbar];
    
    CQ_HistoryCollectionLayout *historyLayout = [[CQ_HistoryCollectionLayout alloc]init];
    
    UICollectionView *historyConllectView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 60, self.view.bounds.size.width, self.view.bounds.size.height) collectionViewLayout:historyLayout];
    
    //设置背景颜色
    historyConllectView.backgroundColor = [UIColor whiteColor];
    _collectionView = historyConllectView;
    [self.view addSubview:historyConllectView];
    //指定数据源
    historyConllectView.delegate  = self;
    historyConllectView.dataSource = self;
    
    _data = [NSMutableArray arrayWithArray:@[@"年货",@"酸奶",@"水",@"车厘子",@"洽洽瓜子",@"维他",@"香烟",@"周黑鸭",@"草莓",@"星巴克",@"卤味"]];
    [historyConllectView registerNib:[UINib nibWithNibName:@"CQ_HistoryCell" bundle:nil] forCellWithReuseIdentifier:HistoryViewCell];
    
    [historyConllectView registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"header"];
    [historyConllectView registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:@"footer"];
}

#pragma mark - 创建Navigationbar和搜索框

- (void)setNavigationbar
{
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    UINavigationBar *navigationBar = [[UINavigationBar alloc] initWithFrame:CGRectMake(0, 0, screenRect.size.width, 60)];
    
    [self.view addSubview: navigationBar];
    
    //创建搜索栏
    UISearchBar *searchBar = [[UISearchBar alloc] init];
    
    [searchBar setTranslucent:YES];
    searchBar.placeholder = @"请输入需要查询的商品";
    searchBar.delegate = self;
    self.navigationItem.titleView = searchBar;
}
#pragma mark- 数据源方法
- (void)loadData
{
    NSMutableDictionary *param = [NSMutableDictionary dictionary];
    [param setValue:@"2" forKey:@"call"];
    [DSHTTPClient postUrlString:@"firstSell.json.php" withParam:param withSuccessBlock:^(id data) {
        NSArray * sellArr = data[@"data"];
        NSMutableArray * arrM = [NSMutableArray arrayWithCapacity:sellArr.count];
        [sellArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            LBHomeSellModel * model = [LBHomeSellModel modelwithdict:obj];
            [arrM addObject:model];
        }];
        _sellList = arrM.copy;
        //        [_collectionView reloadData];
    } withFailedBlock:^(NSError *error) {
        NSLog(@"%@",error);
    } withErrorBlock:^(NSString *message) {
        NSLog(@"%@",message);
    }];
}

#pragma mark - 数据源方法

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return _data.count;
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    CQ_HistoryCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:HistoryViewCell forIndexPath:indexPath];
    //实现block
    cell.searchBlock = ^(NSString *title){
        
        // 2.创建详情vc对象
        LBMarketProductDetailsController *detailController =[[LBMarketProductDetailsController alloc] init];
        // 1.获取选中的商品
        LBMarketProductsModel *selectProduct = _sellList[1];
        // 2.创建详情vc对象
        detailController.productModel = selectProduct;
        // 3.跳转
        [self.navigationController pushViewController:detailController animated:YES];
    };
    cell.keyword = _data[indexPath.row];
    return cell;
}

//设置圆形cell
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    if (_cell == nil) {
        _cell = [[NSBundle mainBundle]loadNibNamed:@"CQ_HistoryCell" owner:nil options:nil][0];
    }
    _cell.keyword = _data[indexPath.row];
    return [_cell sizeForCell];
}


#pragma mark - 设置首尾字头

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath{
    UICollectionReusableView *reuseView;
    if (kind == UICollectionElementKindSectionHeader) {
        reuseView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"header" forIndexPath:indexPath];
        
        UILabel *label = [[UILabel alloc]init];
        [reuseView addSubview:label];
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(reuseView).offset(20);
            make.top.equalTo(reuseView).offset(10);
        }];
        label.text = @"热门搜索";
        label.textColor = [UIColor grayColor];
        label.font = [UIFont fontWithName:@"Arial-BoldMT" size:14];
        
        
        
    }else{
        reuseView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:@"footer" forIndexPath:indexPath];
    }
    return reuseView;
}


- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    NSLog(@"---%@",searchBar.text);
    // 2.创建详情vc对象
    LBMarketProductDetailsController *detailController =[[LBMarketProductDetailsController alloc] init];
    // 1.获取选中的商品
    LBMarketProductsModel *selectProduct = _sellList[1];
    // 2.创建详情vc对象
    detailController.productModel = selectProduct;
    // 3.跳转
    [self.navigationController pushViewController:detailController animated:YES];
}

@end
