SCanQRCodeViewController *scan = [[SCanQRCodeViewController alloc] init];
[self.navigationController pushViewController:scan animated:YES];
